// db.js (Prisma 7 + SQLite adapter)
require("dotenv").config();

const { PrismaClient } = require("@prisma/client");
const { PrismaBetterSqlite3 } = require("@prisma/adapter-better-sqlite3");

const url = (process.env.DATABASE_URL || "file:./dev.db").toString().trim();
const adapter = new PrismaBetterSqlite3({ url });

const prisma = new PrismaClient({ adapter });

module.exports = prisma;