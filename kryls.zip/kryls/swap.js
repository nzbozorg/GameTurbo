document.addEventListener("DOMContentLoaded", async () => {
  // ---------------- ParaSwap / Polygon ----------------
  const CHAIN_ID = 137; // Polygon Mainnet
  const PARASWAP_API = "https://apiv5.paraswap.io";

  const DEFAULT_TOKENS = [
    {
      symbol: "MATIC",
      address: "0xEeeeeEeeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
      decimals: 18,
      logo: "https://cryptologos.cc/logos/polygon-matic-logo.png",
    },
    {
      symbol: "USDT",
      address: "0xc2132D6b03198963962A658554170549E9841350",
      decimals: 6,
      logo: "https://cryptologos.cc/logos/tether-usdt-logo.png",
    },
    {
      symbol: "USDC",
      address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
      decimals: 6,
      logo: "https://cryptologos.cc/logos/usd-coin-usdc-logo.png",
    },
    {
      symbol: "WETH",
      address: "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619",
      decimals: 18,
      logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
    },
    {
      symbol: "DAI",
      address: "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063",
      decimals: 18,
      logo: "https://cryptologos.cc/logos/multi-collateral-dai-dai-logo.png",
    },
  ];

  let provider, signer, userAddress;
  let fromToken = DEFAULT_TOKENS[0]; // MATIC
  let toToken = DEFAULT_TOKENS[1]; // USDT
  let isSelectingFrom = true;

  const btnConnect = document.getElementById("connectWalletBtn");
  const btnSwap = document.getElementById("swapActionBtn");
  const inputFrom = document.getElementById("amountFrom");
  const inputTo = document.getElementById("amountTo");
  const priceRate = document.getElementById("priceRate");
  const gasEst = document.getElementById("gasEst");
  const modal = document.getElementById("tokenModal");
  const tokenListContainer = document.getElementById("tokenListContainer");

  // اگر از ایندکس وصل شده بود، مستقیم سعی کن ولت را استفاده کنی
  if (localStorage.getItem("userWallet")) {
    await connectWallet(true);
  } else if (btnConnect) {
    btnSwap.innerText = "Connect Wallet";
    btnSwap.classList.add("btn-primary");
    btnSwap.disabled = false;
    btnSwap.addEventListener("click", connectWallet);
  }

  // رویداد سواپ
  if (btnSwap) {
    btnSwap.addEventListener("click", async () => {
      if (!userAddress) return connectWallet();
      if (!window.latestPriceRoute) return;
      await executeSwap();
    });
  }

  // ---------------- اتصال ولت ----------------
  async function connectWallet(silent = false) {
    if (!window.ethereum) {
      alert("Install MetaMask!");
      return;
    }

    try {
      provider = new ethers.providers.Web3Provider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      userAddress = accounts[0];
      signer = provider.getSigner();

      const network = await provider.getNetwork();
      if (network.chainId !== CHAIN_ID) {
        try {
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: "0x89" }], // 137
          });
          window.location.reload();
          return;
        } catch (e) {
          if (!silent) {
            alert("Please switch to Polygon Network in MetaMask.");
          }
          return;
        }
      }

      const shortAddr = userAddress.slice(0, 6) + "..." + userAddress.slice(-4);
      if (btnConnect) {
        btnConnect.innerText = shortAddr;
        btnConnect.style.border = "1px solid #00ff99";
        btnConnect.style.color = "#00ff99";
      }

      if (btnSwap) {
        btnSwap.innerText = "Enter Amount";
        btnSwap.classList.add("btn-primary");
        btnSwap.disabled = false;
      }

      // دیگر لازم نیست روی connectWallet ست بماند
      btnSwap.removeEventListener("click", connectWallet);

      await updateBalances();
    } catch (e) {
      console.error(e);
      if (!silent) alert("Wallet connection failed.");
    }
  }

  // ---------------- لیست توکن‌ها ----------------
  function renderTokenList() {
    if (!tokenListContainer) return;
    tokenListContainer.innerHTML = "";

    DEFAULT_TOKENS.forEach((token) => {
      const div = document.createElement("div");
      div.className = "token-item";
      div.innerHTML = `
        <div class="token-info">
          <img src="${token.logo}" class="token-icon" />
          <div>
            <div class="token-symbol">${token.symbol}</div>
            <div class="token-address">
              ${token.address.slice(0, 6)}...${token.address.slice(-4)}
            </div>
          </div>
        </div>
      `;
      div.onclick = () => selectToken(token);
      tokenListContainer.appendChild(div);
    });
  }

  function selectToken(token) {
    if (isSelectingFrom) {
      fromToken = token;
      document.getElementById("symbolFrom").innerText = token.symbol;
      document.getElementById("imgFrom").src = token.logo;
    } else {
      toToken = token;
      document.getElementById("symbolTo").innerText = token.symbol;
      document.getElementById("imgTo").src = token.logo;
    }
    modal.classList.remove("active");
    updateBalances();
    getRate();
  }

  document.getElementById("selectTokenFrom").onclick = () => {
    isSelectingFrom = true;
    modal.classList.add("active");
    renderTokenList();
  };

  document.getElementById("selectTokenTo").onclick = () => {
    isSelectingFrom = false;
    modal.classList.add("active");
    renderTokenList();
  };

  document.getElementById("switchTokensBtn").onclick = () => {
    const temp = fromToken;
    fromToken = toToken;
    toToken = temp;

    document.getElementById("symbolFrom").innerText = fromToken.symbol;
    document.getElementById("imgFrom").src = fromToken.logo;
    document.getElementById("symbolTo").innerText = toToken.symbol;
    document.getElementById("imgTo").src = toToken.logo;

    const val = inputFrom.value;
    inputFrom.value = inputTo.value;
    inputTo.value = val;

    updateBalances();
    getRate();
  };

  // ---------------- بالانس و نرخ ----------------
  async function updateBalances() {
    if (!userAddress || !provider) return;

    try {
      let balance;
      if (fromToken.address === "0xEeeeeEeeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE") {
        balance = await provider.getBalance(userAddress);
      } else {
        const contract = new ethers.Contract(
          fromToken.address,
          ["function balanceOf(address) view returns (uint256)"],
          provider
        );
        balance = await contract.balanceOf(userAddress);
      }
      const fmt = ethers.utils.formatUnits(balance, fromToken.decimals);
      document.getElementById("balFrom").innerText = parseFloat(fmt).toFixed(4);
    } catch (e) {
      console.error(e);
    }
  }

  let debounceTimer;
  inputFrom.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(getRate, 500);
  });

  async function getRate() {
    const amount = inputFrom.value;
    if (!amount || Number(amount) <= 0) {
      inputTo.value = "";
      priceRate.innerText = "Enter amount";
      if (btnSwap) btnSwap.innerText = "Enter Amount";
      return;
    }

    priceRate.innerText = "Fetching...";
    if (btnSwap) {
      btnSwap.innerText = "Finding Best Route...";
      btnSwap.disabled = true;
    }

    try {
      const amountWei = ethers.utils.parseUnits(
        amount.toString(),
        fromToken.decimals
      );

      const url = `${PARASWAP_API}/prices?srcToken=${fromToken.address}&destToken=${toToken.address}&amount=${amountWei.toString()}&srcDecimals=${fromToken.decimals}&destDecimals=${toToken.decimals}&side=SELL&network=${CHAIN_ID}`;

      const res = await axios.get(url);
      const data = res.data.priceRoute;
      if (!data) throw new Error("No route found");

      const destAmount = ethers.utils.formatUnits(
        data.destAmount,
        toToken.decimals
      );
      inputTo.value = parseFloat(destAmount).toFixed(6);

      priceRate.innerText = `1 ${fromToken.symbol} ≈ ${(
        destAmount / amount
      ).toFixed(4)} ${toToken.symbol}`;
      gasEst.innerText = data.gasCostUSD || "~";

      if (btnSwap) {
        btnSwap.innerText = "Swap via ParaSwap";
        btnSwap.disabled = false;
      }

      window.latestPriceRoute = data;
    } catch (e) {
      console.error(e);
      priceRate.innerText = "Error fetching rate";
      if (btnSwap) {
        btnSwap.innerText = "Route Not Found";
        btnSwap.disabled = false;
      }
    }
  }

  // ---------------- اجرای سواپ ----------------
  async function executeSwap() {
    const priceRoute = window.latestPriceRoute;
    if (!priceRoute || !signer) return;

    const srcAmount = priceRoute.srcAmount;

    try {
      btnSwap.innerText = "Processing...";
      btnSwap.disabled = true;

      // Approve برای توکن‌های غیر MATIC
      if (
        fromToken.address !== "0xEeeeeEeeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"
      ) {
        const tokenContract = new ethers.Contract(
          fromToken.address,
          [
            "function approve(address spender, uint256 amount) public returns (bool)",
            "function allowance(address owner, address spender) public view returns (uint256)",
          ],
          signer
        );

        const paraSwapSpender = priceRoute.tokenTransferProxy;
        const allowance = await tokenContract.allowance(
          userAddress,
          paraSwapSpender
        );

        if (allowance.lt(srcAmount)) {
          btnSwap.innerText = "Approving...";
          const txApprove = await tokenContract.approve(
            paraSwapSpender,
            srcAmount
          );
          await txApprove.wait();
        }
      }

      const txURL = `${PARASWAP_API}/transactions/${CHAIN_ID}?ignoreChecks=true`;
      const txBody = {
        srcToken: fromToken.address,
        destToken: toToken.address,
        srcAmount: priceRoute.srcAmount,
        destAmount: priceRoute.destAmount,
        priceRoute,
        userAddress,
        slippage: 100, // 1%
      };

      const txRes = await axios.post(txURL, txBody);
      const txParams = txRes.data;

      btnSwap.innerText = "Confirm in Wallet...";
      const tx = await signer.sendTransaction(txParams);

      btnSwap.innerText = "Swapping...";
      await tx.wait();

      alert(`Swap Successful! Hash: ${tx.hash}`);
      btnSwap.innerText = "Swap Again";
      await updateBalances();
      inputFrom.value = "";
      inputTo.value = "";
      priceRate.innerText = "Enter amount";
    } catch (e) {
      console.error(e);
      alert(
        `Swap Failed: ${
          e?.reason || e?.message || "Unknown error"
        }`
      );
      btnSwap.innerText = "Try Again";
    } finally {
      btnSwap.disabled = false;
    }
  }
});
