// crypto-utils.js
// KRYLS Recoverable End-to-End Encryption (E2EE) - Web Crypto API
// مطابق ToS: پیام‌ها client-side با AES-256-GCM رمز می‌شوند.
// کلید AES پروژه فقط در مرورگر ساخته می‌شود و برای بازیابی/داوری، با RSA-OAEP برای
// کاربران (برای recovery)، ادمین و اوراکل wrap شده و فقط نسخه‌ی wrapped روی سرور ذخیره می‌شود.
// سرور هیچ‌وقت plaintext پیام‌ها یا کلید AES را نمی‌بیند.

const KrylsCrypto = {
    // ========== تبدیل‌های پایه ==========
    str2ab(str) {
        return new TextEncoder().encode(str);
    },

    ab2str(buf) {
        return new TextDecoder().decode(buf);
    },

    buf2base64(buf) {
        return btoa(String.fromCharCode(...new Uint8Array(buf)));
    },

    base642buf(base64) {
        return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0)).buffer;
    },

    // ========== AES-GCM (رمزنگاری پیام‌ها) ==========
    async generateChatKey() {
        return await crypto.subtle.generateKey(
            { name: "AES-GCM", length: 256 },
            true,
            ["encrypt", "decrypt", "wrapKey", "unwrapKey"]
        );
    },

    async encryptMessage(plainText, aesKey) {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv },
            aesKey,
            this.str2ab(plainText)
        );
        return {
            cipher: this.buf2base64(encrypted),
            iv: this.buf2base64(iv)
        };
    },

    async decryptMessage(cipherBase64, ivBase64, aesKey) {
        try {
            const decrypted = await crypto.subtle.decrypt(
                { name: "AES-GCM", iv: this.base642buf(ivBase64) },
                aesKey,
                this.base642buf(cipherBase64)
            );
            return this.ab2str(decrypted);
        } catch (e) {
            console.error("Decrypt failed:", e);
            return "[پیام رمزنگاری شده - کلید در دسترس نیست]";
        }
    },

    // ========== Sealed Message Format (V2) ==========
    // sealed = { v:2, ct, iv, aad }  که aad = base64(projectId|sender|receiver)
    async sealMessageV2(plainText, aesKey, projectId, sender, receiver) {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const aadText = `${projectId}|${String(sender).toLowerCase()}|${String(receiver).toLowerCase()}`;
        const aad = this.str2ab(aadText);

        const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv, additionalData: aad, tagLength: 128 },
            aesKey,
            this.str2ab(plainText)
        );

        return {
            v: 2,
            ct: this.buf2base64(encrypted),
            iv: this.buf2base64(iv),
            aad: this.buf2base64(aad)
        };
    },

    async openSealedMessageV2(sealed, aesKey) {
        try {
            const decrypted = await crypto.subtle.decrypt(
                {
                    name: "AES-GCM",
                    iv: this.base642buf(sealed.iv),
                    additionalData: this.base642buf(sealed.aad),
                    tagLength: 128
                },
                aesKey,
                this.base642buf(sealed.ct)
            );
            return this.ab2str(decrypted);
        } catch (e) {
            console.error("Open sealed message failed:", e);
            return "[خطا در رمزگشایی]";
        }
    },

    // ========== RSA-OAEP wrap/unwrap ==========
    async importPublicKey(pem) {
        const pemHeader = "-----BEGIN PUBLIC KEY-----";
        const pemFooter = "-----END PUBLIC KEY-----";
        let pemContents = pem.replace(pemHeader, "").replace(pemFooter, "");
        pemContents = pemContents.replace(/\s/g, "");
        const binaryDer = this.base642buf(pemContents);

        return await crypto.subtle.importKey(
            "spki",
            binaryDer,
            { name: "RSA-OAEP", hash: "SHA-256" },
            true,
            ["wrapKey"]
        );
    },

    async importPrivateKey(pem) {
        const pemHeader = "-----BEGIN PRIVATE KEY-----";
        const pemFooter = "-----END PRIVATE KEY-----";
        let pemContents = pem.replace(pemHeader, "").replace(pemFooter, "");
        pemContents = pemContents.replace(/\s/g, "");
        const binaryDer = this.base642buf(pemContents);

        return await crypto.subtle.importKey(
            "pkcs8",
            binaryDer,
            { name: "RSA-OAEP", hash: "SHA-256" },
            true,
            ["unwrapKey"]
        );
    },

    async wrapKeyForEntity(aesKey, publicKeyPem) {
        const pubKey = await this.importPublicKey(publicKeyPem);
        const wrapped = await crypto.subtle.wrapKey(
            "raw",
            aesKey,
            pubKey,
            { name: "RSA-OAEP", hash: "SHA-256" }
        );
        return this.buf2base64(wrapped);
    },

    async unwrapKeyWithPrivate(wrappedKeyBase64, privateKeyPem) {
        const privKey = await this.importPrivateKey(privateKeyPem);
        return await crypto.subtle.unwrapKey(
            "raw",
            this.base642buf(wrappedKeyBase64),
            privKey,
            { name: "RSA-OAEP", hash: "SHA-256" },
            { name: "AES-GCM", length: 256 },
            true,
            ["decrypt"]
        );
    },

    // ========== User RSA keypair for recovery (client-only) ==========
    _userPrivKeyStorage(wallet) {
        return `kryls_user_rsa_priv_${String(wallet || "").toLowerCase()}`;
    },
    _userPubKeyStorage(wallet) {
        return `kryls_user_rsa_pub_${String(wallet || "").toLowerCase()}`;
    },

    async ensureUserRSAKeyPair(wallet) {
        const w = String(wallet || "").toLowerCase();
        if (!w) throw new Error("Missing wallet for user keypair");

        const pubB64 = localStorage.getItem(this._userPubKeyStorage(w));
        const privB64 = localStorage.getItem(this._userPrivKeyStorage(w));

        if (pubB64 && privB64) {
            return { publicKeyB64: pubB64, privateKeyB64: privB64 };
        }

        const keyPair = await crypto.subtle.generateKey(
            {
                name: "RSA-OAEP",
                modulusLength: 2048,
                publicExponent: new Uint8Array([1, 0, 1]),
                hash: "SHA-256"
            },
            true,
            ["wrapKey", "unwrapKey"]
        );

        const pubSpki = await crypto.subtle.exportKey("spki", keyPair.publicKey);
        const privPkcs8 = await crypto.subtle.exportKey("pkcs8", keyPair.privateKey);

        const newPubB64 = this.buf2base64(pubSpki);
        const newPrivB64 = this.buf2base64(privPkcs8);

        localStorage.setItem(this._userPubKeyStorage(w), newPubB64);
        localStorage.setItem(this._userPrivKeyStorage(w), newPrivB64);

        return { publicKeyB64: newPubB64, privateKeyB64: newPrivB64 };
    },

    getUserPublicKeyB64(wallet) {
        const w = String(wallet || "").toLowerCase();
        return localStorage.getItem(this._userPubKeyStorage(w)) || null;
    },

    getUserPrivateKeyB64(wallet) {
        const w = String(wallet || "").toLowerCase();
        return localStorage.getItem(this._userPrivKeyStorage(w)) || null;
    },

    formatPublicKeyPEM(b64) {
        const header = "-----BEGIN PUBLIC KEY-----\n";
        const footer = "-----END PUBLIC KEY-----";
        const body = this.formatBase64Lines(b64, 64);
        return header + body + "\n" + footer;
    },

    formatPrivateKeyPEM(b64) {
        const header = "-----BEGIN PRIVATE KEY-----\n";
        const footer = "-----END PRIVATE KEY-----";
        const body = this.formatBase64Lines(b64, 64);
        return header + body + "\n" + footer;
    },

    formatBase64Lines(b64, lineLength) {
        const lines = [];
        for (let i = 0; i < b64.length; i += lineLength) {
            lines.push(b64.slice(i, i + lineLength));
        }
        return lines.join("\n");
    },

    // ========== Local AES storage (per project) ==========
    saveKeyToStorage(projectId, rawKey) {
        try {
            localStorage.setItem(`chat_key_${projectId}`, this.buf2base64(rawKey));
            return true;
        } catch (e) {
            console.error("Save key failed:", e);
            return false;
        }
    },

    loadKeyFromStorage(projectId) {
        try {
            const b64 = localStorage.getItem(`chat_key_${projectId}`);
            if (!b64) return null;
            return this.base642buf(b64);
        } catch (e) {
            console.error("Load key failed:", e);
            return null;
        }
    },

    removeKeyFromStorage(projectId) {
        try {
            localStorage.removeItem(`chat_key_${projectId}`);
        } catch (e) {
            console.error("Remove key failed:", e);
        }
    }
};

if (typeof window !== "undefined") {
    window.KrylsCrypto = KrylsCrypto;
}
