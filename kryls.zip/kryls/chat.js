document.addEventListener("DOMContentLoaded", async () => {
const API_URL = `http://${window.location.hostname}:5000`;
const rawWallet = localStorage.getItem("userWallet");
const userWallet = rawWallet ? rawWallet.toLowerCase() : null;
if (!userWallet) {
    alert("Please login to view messages.");
    window.location.href = "index.html";
    return;
}

// ----------------- DOM -----------------
const contactsList         = document.getElementById("contactsList");
const messagesArea         = document.getElementById("messagesArea");
const messageInput         = document.getElementById("messageInput");
const sendBtn              = document.getElementById("sendMessageBtn");
const chatStatus           = document.getElementById("chatStatus");
const currentChatName      = document.getElementById("currentChatName");
const currentChatAvatar    = document.getElementById("currentChatAvatar");
const projectSummaryLine   = document.getElementById("projectSummaryLine");
const projectTermsLine     = document.getElementById("projectTermsLine");
const projectFlags         = document.getElementById("projectFlags");
const requestsPanel        = document.getElementById("requestsPanel");
const requestsList         = document.getElementById("requestsList");
const requestsCount        = document.getElementById("requestsCount");
const requestsToggleRow    = document.getElementById("requestsToggleRow");
const toggleRequestsBtn    = document.getElementById("toggleRequestsBtn");
const e2eeStatus           = document.getElementById("e2eeStatus");

// header wallet UI
const connectBtn           = document.getElementById("connectWalletBtn");
const profileIcon          = document.getElementById("userProfileIcon");
const headerAvatar         = document.getElementById("headerAvatar");

// chat header actions
const approveRequestBtn    = document.getElementById("approveRequestBtn");
const rejectRequestBtn     = document.getElementById("rejectRequestBtn");
const changeTermsBtn       = document.getElementById("changeTermsBtn");
const submitDeliveryBtn    = document.getElementById("submitDeliveryBtn");
const acceptDeliveryBtn    = document.getElementById("acceptDeliveryBtn");
const openDisputeBtn       = document.getElementById("openDisputeBtn");
const resolveDisputeBtn    = document.getElementById("resolveDisputeBtn");

// modals
const termsModal           = document.getElementById("termsModal");
const closeTermsModalBtn   = document.getElementById("closeTermsModalBtn");
const submitTermsBtn       = document.getElementById("submitTermsBtn");
const termsPriceInput      = document.getElementById("termsPriceInput");
const termsDeliveryDateInput = document.getElementById("termsDeliveryDateInput");
const termsDeliveryDaysInput = document.getElementById("termsDeliveryDaysInput");
const termsPendingBar      = document.getElementById("termsPendingBar");
const deliveryModal        = document.getElementById("deliveryModal");
const closeDeliveryModalBtn= document.getElementById("closeDeliveryModalBtn");
const deliveryContentInput = document.getElementById("deliveryContentInput");
const submitDeliveryConfirmBtn = document.getElementById("submitDeliveryConfirmBtn");
const disputeModal         = document.getElementById("disputeModal");
const closeDisputeModalBtn = document.getElementById("closeDisputeModalBtn");
const disputeReasonInput   = document.getElementById("disputeReasonInput");
const oracleSelect         = document.getElementById("oracleSelect");
const openDisputeConfirmBtn= document.getElementById("openDisputeConfirmBtn");

// chat header info popup
const chatInfoBtn = document.getElementById('chatInfoBtn');
const projectInfoModal = document.getElementById('projectInfoModal');
const closeProjectInfoModalBtn = document.getElementById('closeProjectInfoModalBtn');
const projectInfoBody = document.getElementById('projectInfoBody');

// ----------------- E2EE State -----------------
let e2eeEnabled = true;
let chatKeys = new Map(); // projectId -> AES key
let adminPubKeyB64 = null;
let oraclePubKeys = new Map(); // oracleWallet -> pubKeyB64

// ----------------- Helpers -----------------
const short = (a) => (a ? `${a.slice(0, 6)}...${a.slice(-4)}` : "");
const isAddr = (s) => /^0x[a-fA-F0-9]{40}$/.test(String(s).trim());
const qs = new URLSearchParams(window.location.search);
const preselectProjectId = qs.get("projectId") || null;

function escapeHTML(str) {
    return String(str)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function formatTime(ts) {
    try {
        const d = ts ? new Date(ts) : new Date();
        return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch {
        return "...";
    }
}

function formatDateLabel(ts) {
    try {
        const d = ts ? new Date(ts) : new Date();
        const today = new Date();
        const diffDays = Math.floor(
            (today.setHours(0, 0, 0, 0) - new Date(d).setHours(0, 0, 0, 0)) /
            (1000 * 60 * 60 * 24)
        );
        if (diffDays === 0) return "Today";
        if (diffDays === 1) return "Yesterday";
        return d.toLocaleDateString();
    } catch {
        return "";
    }
}

function isNearBottom(el, thresholdPx = 140) {
    return el.scrollHeight - el.scrollTop - el.clientHeight < thresholdPx;
}

function setStatus(text, ok = true) {
    if (!chatStatus) return;
    const t = String(text || '');
    chatStatus.textContent = t;
    chatStatus.classList.remove('online', 'offline');
    if (/online/i.test(t)) chatStatus.classList.add('online');
    if (/offline/i.test(t)) chatStatus.classList.add('offline');
    if (!ok) {
        chatStatus.classList.add('offline');
    }
}

function setE2EEStatus(enabled, keyLoaded = false) {
    if (!e2eeStatus) return;
    if (!enabled) {
        e2eeStatus.textContent = "E2EE: OFF";
        e2eeStatus.classList.remove('online', 'offline');
        e2eeStatus.classList.add('offline');
        return;
    }
    if (keyLoaded) {
        e2eeStatus.textContent = "E2EE: ✅";
        e2eeStatus.classList.remove('offline');
        e2eeStatus.classList.add('online');
    } else {
        e2eeStatus.textContent = "E2EE: 🔒";
        e2eeStatus.classList.remove('online', 'offline');
    }
}

function openModal(el) {
    if (!el) return;
    el.classList.add("active");
}

function closeModal(el) {
    if (!el) return;
    el.classList.remove("active");
}


// ----------------- Escrow Progress Modal (Approve Escrow) -----------------
let escrowProgressModalEl = null;

function ensureEscrowProgressModal() {
    if (escrowProgressModalEl) return escrowProgressModalEl;

    const overlay = document.createElement("div");
    overlay.id = "escrowProgressModal";
    overlay.className = "modal-overlay";

    overlay.innerHTML = `
      <div class="modal-content" style="max-width:650px;">
        <div class="modal-header">
          <h3>Creating Escrow</h3>
          <button class="close-btn" type="button" aria-label="Close">&times;</button>
        </div>

        <div style="display:grid; gap:12px;">
          <div id="escrowProgressSubtitle" style="opacity:.9; color: rgba(255,255,255,.75);">
            Preparing…
          </div>

          <div id="escrowProgressList" style="display:grid; gap:10px;"></div>

          <div id="escrowProgressFooter" style="display:flex; justify-content:flex-end; gap:10px; margin-top:6px;">
            <button id="escrowProgressDoneBtn" class="btn btn-primary" type="button" style="display:none;">
              Done ✓
            </button>
          </div>
        </div>
      </div>
    `;

    // Close handlers
    const closeBtn = overlay.querySelector(".close-btn");
    closeBtn.addEventListener("click", () => closeModal(overlay));
    overlay.addEventListener("click", (e) => {
        if (e.target === overlay) closeModal(overlay);
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && overlay.classList.contains("active")) {
            closeModal(overlay);
        }
    });

    const doneBtn = overlay.querySelector("#escrowProgressDoneBtn");
    doneBtn.addEventListener("click", () => closeModal(overlay));

    document.body.appendChild(overlay);
    escrowProgressModalEl = overlay;
    return overlay;
}

function showEscrowProgressModal(title = "Creating Escrow") {
    const overlay = ensureEscrowProgressModal();
    const h3 = overlay.querySelector(".modal-header h3");
    if (h3) h3.textContent = title;

    const list = overlay.querySelector("#escrowProgressList");
    const sub = overlay.querySelector("#escrowProgressSubtitle");
    const doneBtn = overlay.querySelector("#escrowProgressDoneBtn");

    if (list) list.innerHTML = "";
    if (sub) sub.textContent = "Starting…";
    if (doneBtn) doneBtn.style.display = "none";

    openModal(overlay);
}

function escrowStepAdd(label) {
    const overlay = ensureEscrowProgressModal();
    const list = overlay.querySelector("#escrowProgressList");
    if (!list) return null;

    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.alignItems = "center";
    row.style.justifyContent = "space-between";
    row.style.gap = "12px";
    row.style.padding = "12px 14px";
    row.style.borderRadius = "16px";
    row.style.border = "1px solid rgba(255,255,255,0.10)";
    row.style.background = "rgba(0,0,0,0.30)";

    row.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:4px; min-width:0;">
        <div style="font-weight:800; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
          ${escapeHTML(label)}
        </div>
        <div class="k-step-sub" style="font-size:.85rem; opacity:.75;">Pending…</div>
      </div>

      <div class="k-step-icon" style="font-size:1.15rem; min-width:32px; text-align:right; opacity:.9;">
        ⏳
      </div>
    `;

    list.appendChild(row);
    return row;
}

function escrowStepUpdate(stepEl, state, subtext) {
    if (!stepEl) return;
    const icon = stepEl.querySelector(".k-step-icon");
    const sub = stepEl.querySelector(".k-step-sub");

    if (sub) sub.textContent = subtext || "";

    // state: "pending" | "doing" | "ok" | "fail"
    if (state === "pending") {
        stepEl.style.borderColor = "rgba(255,255,255,0.10)";
        stepEl.style.background = "rgba(0,0,0,0.30)";
        if (icon) icon.textContent = "⏳";
    } else if (state === "doing") {
        stepEl.style.borderColor = "rgba(0,240,255,0.25)";
        stepEl.style.background = "rgba(0,240,255,0.06)";
        if (icon) icon.textContent = "⏳";
    } else if (state === "ok") {
        stepEl.style.borderColor = "rgba(0,255,153,0.28)";
        stepEl.style.background = "rgba(0,255,153,0.06)";
        if (icon) icon.textContent = "✅";
    } else if (state === "fail") {
        stepEl.style.borderColor = "rgba(255,92,122,0.32)";
        stepEl.style.background = "rgba(255,92,122,0.06)";
        if (icon) icon.textContent = "❌";
    }
}

function escrowProgressSubtitle(text) {
    const overlay = ensureEscrowProgressModal();
    const sub = overlay.querySelector("#escrowProgressSubtitle");
    if (sub) sub.textContent = text || "";
}

function escrowProgressDone(ok = true) {
    const overlay = ensureEscrowProgressModal();
    const doneBtn = overlay.querySelector("#escrowProgressDoneBtn");
    if (doneBtn) doneBtn.style.display = "inline-flex";

    escrowProgressSubtitle(ok ? "Escrow created successfully." : "Failed. See steps above.");
}


function humanTerms(project) {
    const basePrice =
        project?.agreedPrice ??
        project?.price ??
        project?.budget ??
        project?.totalCommitment;
    const dd = (project?.deliveryDate || "").toString().trim();
    const days = (project?.deliveryDays || "").toString().trim();
    const deliveryText = dd || days ? `${days || dd}` : "";
    const priceText = basePrice ? basePrice.toString() : "";
    const parts = [];
    if (priceText) parts.push(`Price ${priceText}`);
    if (deliveryText) parts.push(`Delivery ${deliveryText}`);
    return parts.length ? `Terms: ${parts.join(" - ")}` : "";
}

async function apiJSON(url, opts) {
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => null);
    if (!data || data.success === false) {
        throw new Error(data?.message || "API error");
    }
    return data;
}

async function apiPOST(url, body) {
    return apiJSON(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
    });
}

// ----------------- E2EE Functions -----------------
async function loadAdminPublicKey() {
    try {
        const data = await apiJSON(`${API_URL}/api/keys/admin-pubkey`);
        adminPubKeyB64 = data.adminPubKeyB64 || null;
        console.log("Admin pubkey loaded: ", !!adminPubKeyB64);
    } catch (e) {
        console.error("Load admin pubkey failed: ", e);
    }
}

async function loadOraclePublicKey(oracleWallet) {
    // در این پیاده‌سازی ساده، از کلید عمومی ثابت استفاده می‌کنیم
    // در پیاده‌سازی واقعی، باید از سرور دریافت شود
    return adminPubKeyB64; // برای تست، همان کلید ادمین
}

async function getOrCreateChatKey(projectId) {
    // اول از کش چک کن
    if (chatKeys.has(projectId)) {
        return chatKeys.get(projectId);
    }
    
    // بعد از localStorage چک کن
    const rawKey = KrylsCrypto.loadKeyFromStorage(projectId);
    if (rawKey) {
        try {
            const aesKey = await crypto.subtle.importKey(
                "raw",
                rawKey,
                { name: "AES-GCM", length: 256 },
                true,
                ["encrypt", "decrypt"]
            );
            chatKeys.set(projectId, aesKey);
            setE2EEStatus(true, true);
            
            // ✅ فقط اگر wrappedForAdmin وجود نداشت، wrap کن
            try {
                const wrappedKeys = await apiJSON(`${API_URL}/api/keys/get/${projectId}`);
                if (!wrappedKeys?.data?.wrappedForAdmin) {
                    await wrapAndStoreChatKey(projectId, aesKey);
                }
            } catch (e) {
                console.warn("Check wrapped key failed, but continuing...", e);
            }
            
            return aesKey;
        } catch (e) {
            console.error("Import stored key failed: ", e);
        }
    }
    
    // اگر کلید نبود، بساز و ذخیره کن
    try {
        const newKey = await KrylsCrypto.generateChatKey();
        const raw = await crypto.subtle.exportKey("raw", newKey);
        KrylsCrypto.saveKeyToStorage(projectId, raw);
        chatKeys.set(projectId, newKey);
        setE2EEStatus(true, true);
        
        // ✅ فقط برای کلید جدید wrap کن
        await wrapAndStoreChatKey(projectId, newKey);
        
        return newKey;
    } catch (e) {
        console.error("Generate new key failed: ", e);
        // اگر همه چیز شکست خورد، حداقل یک کلید خالی برگردون
        return null;
    }
}

async function wrapAndStoreChatKey(projectId, aesKey) {
    try {
        // دریافت کلید عمومی ادمین
        if (!adminPubKeyB64) {
            await loadAdminPublicKey();
        }
        
        if (!adminPubKeyB64) {
            console.warn("⚠️ Admin pubkey not available, skipping wrap");
            return;
        }

        // ✅ اینجا را حذف کن (چک نکن که قبلاً wrap شده یا نه):
        // این خط را پاک کن:
        // const existing = await apiJSON(`${API_URL}/api/keys/get/${projectId}`);
        // if (existing?.data?.wrappedForAdmin) return;

        // Wrap برای ادمین - همیشه انجام بشه
        const wrappedAdmin = await KrylsCrypto.wrapKeyForEntity(
            aesKey,
            KrylsCrypto.formatPublicKeyPEM(adminPubKeyB64)
        );

        // Wrap برای اوراکل
        const oracleWallet = "0x1111111111111111111111111111111111111111";
        const oraclePubKey = await loadOraclePublicKey(oracleWallet);
        
        let wrappedOracle = null;
        if (oraclePubKey) {
            wrappedOracle = await KrylsCrypto.wrapKeyForEntity(
                aesKey,
                KrylsCrypto.formatPublicKeyPEM(oraclePubKey)
            );
        }

        // ذخیره در سرور - اگر وجود داشت، آپدیت میشه
        await apiPOST(`${API_URL}/api/keys/store`, {
            projectId,
            wrappedForAdmin: wrappedAdmin,
            wrappedForOracle: wrappedOracle,
            oracleWallet: oracleWallet
        });

        console.log("✅ Chat key wrapped and stored for project:", projectId);
    } catch (e) {
        console.error("❌ Wrap chat key failed:", e);
    }
}

async function decryptMessageIfNeeded(message) {
    if (!message.isEncrypted) {
        return message.text;
    }

    try {
        const aesKey = await getOrCreateChatKey(message.projectId);
        const decrypted = await KrylsCrypto.decryptMessage(
            message.text,
            message.iv,
            aesKey
        );
        return decrypted;
    } catch (e) {
        console.error("Decrypt message failed: ", e);
        return "[پیام رمزنگاری شده - کلید در دسترس نیست]";
    }
}

// ----------------- Header UI -----------------
if (connectBtn) {
    connectBtn.innerText = short(userWallet);
    connectBtn.style.border = "1px solid #00f0ff";
    connectBtn.style.color = "#00f0ff";
    connectBtn.style.background = "rgba(0,240,255,0.1)";
}

if (profileIcon) {
    profileIcon.style.display = "block";
    profileIcon.onclick = () => {
        window.location.href = "dashboard.html";
    };
}

if (headerAvatar) {
    headerAvatar.src = `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(userWallet)}`;
}

// ----------------- State -----------------
let myProfile = null;
let conversations = [];
let current = null;
let cacheMessages = [];
let projectsById = new Map();
let lastPresenceText = "Live";
let cachedOracles = null;
let lastTermsProposal = null;
let lastDelivery = null;
let lastDispute = null;
let requestsCollapsed = localStorage.getItem("requestsCollapsed") === "1";

// ----------------- Wallet helpers -----------------
function getProvider() {
    if (!window.ethereum) return null;
    return new ethers.providers.Web3Provider(window.ethereum, "any");
}

async function ensureSepolia(provider) {
    const net = await provider.getNetwork();
    if (net.chainId === 11155111) return true;
    try {
        await provider.send("wallet_switchEthereumChain", [
            { chainId: "0xaa36a7" },
        ]);
        return true;
    } catch (e) {
        alert("Please switch MetaMask/Wallet to Sepolia (11155111).");
        throw e;
    }
}

// ----------------- Contract constants (for escrow) -----------------
const ESCROW_ADDRESS = "0xFd2F7895c9D851288e8Afb3e86fb9Bd4A9153BBb"; // Sepolia
const TOKEN_ADDRESSES = {
    USDT: "0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0",
    USDC: "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238",
    DAI: "0xFF34B3d4Aee8ddCd6F9AFFFB6Fe49bD371b8a357"
};

const ESCROW_ABI = [
    "function createProject(address freelancer,address token,uint256 totalCommitment,uint8 paymentType,uint256[] calldata milestoneAmounts,string[] calldata milestoneDescriptions,bool isWeb3Service,uint8 serviceCategory,uint8 roleCategory,bool issueCertificate,address arbitrator,bool deferDeposit,bool enableXMTP) external returns (uint256 projectId)",
    "function isRegisteredClient(address user) external view returns (bool)",
    "function registerClient(address token) external",
];

const ERC20_ABI = [
    "function approve(address spender,uint256 amount) public returns (bool)",
    "function allowance(address owner,address spender) public view returns (uint256)",
    "function balanceOf(address owner) view returns (uint256)",
    "function decimals() view returns (uint8)"
];

// ----------------- Presence -----------------
async function pingPresence() {
    try {
        await apiPOST(`${API_URL}/api/presence/ping`, { wallet: userWallet });
    } catch {
        /* silent */
    }
}

async function updatePresenceForPeer(peerWallet) {
    const peer = peerWallet?.toLowerCase();
    if (!peer || !isAddr(peer)) return;
    
    try {
        const data = await apiJSON(`${API_URL}/api/presence/status?wallets=${encodeURIComponent(userWallet)},${encodeURIComponent(peer)}`, {
            cache: 'no-store'
        });
        const meOn = !!data?.status?.[userWallet]?.online;
        const peerOn = !!data?.status?.[peer]?.online;
        
        let text = peerOn ? 'Online' : 'Offline';
        const finalText = `${text}`;
        if (finalText !== lastPresenceText) {
            lastPresenceText = finalText;
            setStatus(finalText, true);
        }
        
        if (!meOn) await pingPresence(); 
    } catch (e) {
        setStatus('Live', true);
    }
}

// ----------------- Load profile -----------------
async function loadMyProfile() {
    const data = await apiJSON(`${API_URL}/api/profile/${userWallet}`);
    myProfile = data.user || null;
    if (!myProfile || !myProfile.role) {
        alert("Please select a role (Freelancer / Client) first.");
        window.location.href = "dashboard.html";
        return null;
    }
    return myProfile;
}

// ----------------- Data loaders -----------------
async function loadProjectsIndex() {
    const [client, freelancer] = await Promise.allSettled([
        apiJSON(`${API_URL}/api/client-projects/${userWallet}`),
        apiJSON(`${API_URL}/api/freelancer-active/${userWallet}`),
    ]);
    const items = [];
    if (client.status === "fulfilled" && Array.isArray(client.value.projects)) {
        items.push(...client.value.projects);
    }
    if (
        freelancer.status === "fulfilled" &&
        Array.isArray(freelancer.value.projects)
    ) {
        items.push(...freelancer.value.projects);
    }
    
    if (preselectProjectId) {
        try {
            const p = await apiJSON(
                `${API_URL}/api/project/${encodeURIComponent(preselectProjectId)}`
            );
            if (p && p.project) items.push(p.project);
        } catch {
            /* ignore */
        }
    }
    
    items.forEach((p) => {
        projectsById.set(String(p.id), p);
    });
}

async function loadRequests() {
    const [incoming, mine] = await Promise.allSettled([
        apiJSON(`${API_URL}/api/requests/incoming/${userWallet}`),
        apiJSON(`${API_URL}/api/requests/mine/${userWallet}`),
    ]);
    const incomingArr =
        incoming.status === "fulfilled" && Array.isArray(incoming.value.requests)
            ? incoming.value.requests
            : [];
    const mineArr =
        mine.status === "fulfilled" && Array.isArray(mine.value.requests)
            ? mine.value.requests
            : [];
    
    return [incomingArr, mineArr];
}

async function loadMessages() {
    const data = await apiJSON(
        `${API_URL}/api/messages/${userWallet}`,
        {
            cache: "no-store",
        }
    );
    cacheMessages = Array.isArray(data.messages) ? data.messages : [];
}

// ----------------- Build conversations -----------------
function upsertConversation(projectId, peer, title, role, owner, freelancer) {
    const key = `${projectId}:${peer}`;
    let c = conversations.find((x) => x.key === key);
    if (!c) {
        c = {
            key,
            projectId,
            peer,
            title,
            role,
            owner,
            freelancer,
            requestStatus: null,
            requestId: null,
            lastMessage: "",
            lastMessageAt: 0,
        };
        conversations.push(c);
    } else {
        if (title) c.title = title;
        c.role = role || c.role;
        c.owner = owner || c.owner;
        c.freelancer = freelancer || c.freelancer;
    }
    return c;
}

async function buildLastMessageSummary() {
    for (const c of conversations) {
        const pid = String(c.projectId);
        const peer = c.peer.toLowerCase();
        const msgs = cacheMessages.filter((m) => {
            const mpid = String(m.projectId);
            const s = m.sender.toLowerCase();
            const r = m.receiver.toLowerCase();
            if (mpid !== pid) return false;
            return (
                (s === userWallet && r === peer) ||
                (s === peer && r === userWallet)
            );
        });
        if (!msgs.length) {
            c.lastMessage = "";
            c.lastMessageAt = 0;
        } else {
            const last = msgs[msgs.length - 1];
            // رمزگشایی پیام آخر برای نمایش
            c.lastMessage = await decryptMessageIfNeeded(last);
            c.lastMessageAt = new Date(last.timestamp || last.createdAt || Date.now()).getTime();
        }
    }
    
    conversations.sort(
        (a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0)
    );
}

function buildConversationsFromState(requestsIncoming, requestsMine) {
    conversations = [];
    // owner side – incoming requests
    requestsIncoming.forEach((r) => {
        const p = r.project || projectsById.get(String(r.projectId));
        if (!p) return;
        const projectId = String(r.projectId);
        const owner = (p.owner || r.owner || "").toLowerCase();
        const freelancer = (r.freelancer || "").toLowerCase();
        const title = `${p.title || "Project"} #${projectId}`;
        const c = upsertConversation(
            projectId,
            freelancer,
            title,
            "owner",
            owner,
            freelancer
        );
        c.requestStatus = r.status || "Pending";
        c.requestId = r.id;
    });
    // freelancer side – my sent requests
    requestsMine.forEach((r) => {
        const p = r.project || projectsById.get(String(r.projectId));
        if (!p) return;
        const projectId = String(r.projectId);
        const owner = (p.owner || r.owner || "").toLowerCase();
        const freelancer = (r.freelancer || "").toLowerCase();
        const title = `${p.title || "Project"} #${projectId}`;
        const c = upsertConversation(
            projectId,
            owner,
            title,
            "freelancer",
            owner,
            freelancer
        );
        c.requestStatus = r.status || "Pending";
        c.requestId = r.id;
    });
    
    // active projects – In Progress
    projectsById.forEach((p) => {
        const pid = String(p.id);
        const status = (p.status || "Open").toString();
        if (status === "In Progress") {
            if (
                (p.assignedFreelancer || "").toLowerCase() === userWallet
            ) {
                upsertConversation(
                    pid,
                    (p.owner || "").toLowerCase(),
                    `${p.title || "Project"} #${pid}`,
                    "freelancer",
                    (p.owner || "").toLowerCase(),
                    userWallet
                );
            } else if ((p.owner || "").toLowerCase() === userWallet) {
                upsertConversation(
                    pid,
                    (p.assignedFreelancer || "").toLowerCase(),
                    `${p.title || "Project"} #${pid}`,
                    "owner",
                    (p.owner || "").toLowerCase(),
                    (p.assignedFreelancer || "").toLowerCase()
                );
            }
        }
    });
}

// ----------------- Render conversations list -----------------
async function renderConversationsList() {
    if (!contactsList) return;
    contactsList.innerHTML = "";  // ✅ اول لیست رو پاک کن
    if (!conversations.length) {
        contactsList.innerHTML = '<div style="padding:14px;color:#8aa">No conversations yet.</div>';
        return;
    }
    
    await buildLastMessageSummary();
    
    conversations.forEach((c) => {
        const p = projectsById.get(String(c.projectId)) || {};
        const item = document.createElement("div");
        item.className = "contact-item";
        if (current && current.key === c.key) {
            item.classList.add("active");
        }
        
        const seed = c.peer || "peer";
        const status = (p.status || "Open").toString();
        const subtitle = `${short(c.peer)} · ${escapeHTML(status)}`;
        const badge = c.requestStatus
            ? ` <span style="opacity:0.85;font-size:0.75rem;margin-left:6px;">${escapeHTML(c.requestStatus)}</span>`
            : " ";
        const lastLine = c.lastMessage
            ? escapeHTML(c.lastMessage.length > 60 ? c.lastMessage.slice(0, 60) + "…" : c.lastMessage)
            : "No messages yet";
        
        item.innerHTML = `
            <img src="https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(seed)}" alt=" ">
            <div class="contact-info">
                <h4 style="margin:0">${escapeHTML(c.title)}${badge}</h4>
                <p style="margin:0;opacity:0.8;font-size:0.8rem;">${subtitle}</p>
                <p style="margin:2px 0 0;font-size:0.8rem;color:#b0e0e6;opacity:0.9;">${lastLine}</p>
            </div>
        `;
        
        // ✅ Event listener رو اضافه کن
        item.addEventListener("click", async (e) => {
            e.stopPropagation();
            await selectConversation(c.key);
        });
        
        contactsList.appendChild(item);
    });
}

// ----------------- Requests panel -----------------
function renderRequestsPanel(requestsIncoming) {
    if (!requestsPanel || !requestsList || !requestsCount) return;
    const show = Array.isArray(requestsIncoming) && requestsIncoming.length > 0;
    requestsPanel.style.display = show ? 'block' : 'none';
    if (requestsToggleRow) requestsToggleRow.style.display = show ? 'block' : 'none';
    if (!show) return;
    
    if (requestsCollapsed) {
        requestsPanel.classList.add('collapsed');
        if (toggleRequestsBtn) toggleRequestsBtn.textContent = 'Requests ▾';
    } else {
        requestsPanel.classList.remove('collapsed');
        if (toggleRequestsBtn) toggleRequestsBtn.textContent = 'Requests ▴';
    }
    
    requestsCount.textContent = String(requestsIncoming.length);
    requestsList.innerHTML = '';
    
    requestsIncoming.forEach((r) => {
        const p = r.project || projectsById.get(String(r.projectId));
        const projectTitle = p?.title || `Project ${String(r.projectId)}`;
        const freelancer = (r.freelancer || '').toLowerCase();
        const statusText = (r.status || 'Pending').toString();
        const isPending = statusText.toLowerCase() === 'pending';
        
        const box = document.createElement('div');
        box.className = 'request-item';
        
        const actionButtons = isPending
            ? `
                <button class="mini-btn" data-approve="${escapeHTML(r.id)}">Approve Escrow</button>
                <button class="mini-btn" data-reject="${escapeHTML(r.id)}" style="border-color: rgba(255,92,122,0.45); background: rgba(255,92,122,0.10); color: #ff5c7a;">Reject</button>
            `
            : `
                <button class="mini-btn" data-open="${escapeHTML(r.id)}">Open Chat</button>
                <button class="mini-btn" data-hide="${escapeHTML(r.id)}" style="border-color: rgba(255,255,255,0.18); background: rgba(255,255,255,0.06); color: #cfe;">Hide</button>
            `;
        
        box.innerHTML = `
            <div style="display:flex; justify-content:space-between; gap:10px; align-items:center;">
                <div>
                    <b>${escapeHTML(projectTitle)}</b>
                    <small>From ${escapeHTML(short(freelancer))} • Status ${escapeHTML(statusText)}</small>
                </div>
            </div>
            <div>
                <small>${escapeHTML(r.coverLetter || '')}</small>
            </div>
            <div class="request-actions" data-actions-for="${escapeHTML(r.id)}">
                ${actionButtons}
            </div>
        `;
        
        function mountOpenHide() {
            const openBtn = box.querySelector(`[data-open="${CSS.escape(r.id)}"]`);
            if (openBtn) {
                openBtn.addEventListener('click', () => {
                    const c = conversations.find((x) => x.requestId === r.id);
                    if (c) selectConversation(c.key);
                });
            }
            
            const hideBtn = box.querySelector(`[data-hide="${CSS.escape(r.id)}"]`);
            if (hideBtn) {
                hideBtn.addEventListener('click', async () => {
                    try {
                        await apiPOST(`${API_URL}/api/requests/hide`, { wallet: userWallet, requestId: r.id });
                        box.remove();
                        const left = requestsList.querySelectorAll('.request-item').length;
                        requestsCount.textContent = String(left);
                        if (!left) {
                            requestsPanel.style.display = 'none';
                            if (requestsToggleRow) requestsToggleRow.style.display = 'none';
                        }
                    } catch (e) {
                        console.error(e);
                        alert(e?.message || 'Hide failed');
                    }
                });
            }
        }
        
        function swapToOpenHide() {
            const actions = box.querySelector(`[data-actions-for="${CSS.escape(r.id)}"]`);
            if (!actions) return;
            actions.innerHTML = `
                <button class="mini-btn" data-open="${escapeHTML(r.id)}">Open Chat</button>
                <button class="mini-btn" data-hide="${escapeHTML(r.id)}" style="border-color: rgba(255,255,255,0.18); background: rgba(255,255,255,0.06); color: #cfe;">Hide</button>
            `;
            mountOpenHide();
        }
        
        const approveBtn = box.querySelector(`[data-approve="${CSS.escape(r.id)}"]`);
        if (approveBtn) {
            approveBtn.addEventListener('click', async () => {
                try {
                    approveBtn.disabled = true;
                    const rejectBtn = box.querySelector(`[data-reject="${CSS.escape(r.id)}"]`);
                    if (rejectBtn) rejectBtn.disabled = true;
                    await approveRequestOnChain(r);
                    swapToOpenHide();
                } catch (e) {
                    console.error(e);
                    approveBtn.disabled = false;
                    const rejectBtn = box.querySelector(`[data-reject="${CSS.escape(r.id)}"]`);
                    if (rejectBtn) rejectBtn.disabled = false;
                    alert(e?.message || e?.reason || 'Approve failed');
                }
            });
        }
        
        const rejectBtn = box.querySelector(`[data-reject="${CSS.escape(r.id)}"]`);
        if (rejectBtn) {
            rejectBtn.addEventListener('click', async () => {
                try {
                    rejectBtn.disabled = true;
                    const approveBtn2 = box.querySelector(`[data-approve="${CSS.escape(r.id)}"]`);
                    if (approveBtn2) approveBtn2.disabled = true;
                    await rejectRequestOffChain(r);
                    swapToOpenHide();
                } catch (e) {
                    console.error(e);
                    rejectBtn.disabled = false;
                    const approveBtn2 = box.querySelector(`[data-approve="${CSS.escape(r.id)}"]`);
                    if (approveBtn2) approveBtn2.disabled = false;
                    alert(e?.message || 'Reject failed');
                }
            });
        }
        
        if (!isPending) mountOpenHide();
        
        requestsList.appendChild(box);
    });
}

// ----------------- Select conversation -----------------
function renderProjectFlags(project) {
    if (!projectFlags) return;
    const isWeb3 = !!project?.isWeb3Service;
    if (!isWeb3) {
        projectFlags.style.display = "none";
        projectFlags.innerHTML = "";
        return;
    }
    projectFlags.style.display = "inline-flex";
    projectFlags.innerHTML = `<span class="k-badge">Web3 Chat MVP</span>`;
}

function updateHeaderActionButtonsForCurrent() {
    if (!approveRequestBtn || !rejectRequestBtn) return;
    approveRequestBtn.style.display = "none";
    rejectRequestBtn.style.display = "none";
    if (!current) return;
    if (current.role === "owner" && current.requestStatus === "Pending" && current.requestId) {
        approveRequestBtn.style.display = "inline-flex";
        rejectRequestBtn.style.display = "inline-flex";
        
        approveRequestBtn.onclick = async () => {
            try {
                const incoming = await apiJSON(
                    `${API_URL}/api/requests/incoming/${userWallet}?cache=no-store`
                );
                const reqObj = incoming.requests.find(
                    (x) => x.id === current.requestId
                );
                if (!reqObj) throw new Error("Request not found.");
                await approveRequestOnChain(reqObj);
            } catch (e) {
                console.error(e);
                alert(e?.message || "Approve failed");
            }
        };
        
        rejectRequestBtn.onclick = async () => {
            try {
                const incoming = await apiJSON(
                    `${API_URL}/api/requests/incoming/${userWallet}?cache=no-store`
                );
                const reqObj = incoming.requests.find(
                    (x) => x.id === current.requestId
                );
                if (!reqObj) throw new Error("Request not found.");
                await rejectRequestOffChain(reqObj);
            } catch (e) {
                console.error(e);
                alert(e?.message || "Reject failed");
            }
        };
    }
}

function updateProjectSummaryLine(project) {
    if (!projectSummaryLine) return;
    if (!project) {
        projectSummaryLine.textContent = "Select a project from the left to start chatting.";
        return;
    }
    const budget = project.budget ?? project.totalCommitment ?? 0;
    const tokenSym =
        project.tokenSymbol || project.tokensymbol || project.currency || "USDT";
    const status = project.status || "Open";
    projectSummaryLine.textContent = `Budget: ${budget} ${tokenSym} · Status: ${status}`;
}

async function selectConversation(key) {
    current = conversations.find((x) => x.key === key) || null;
    await renderConversationsList();  // ✅ await اضافه شد
    if (!current) {
        messagesArea.innerHTML = '<div style="padding:14px;color:#8aa">Select a conversation.</div>';
        updateProjectSummaryLine(null);
        return;
    }
    
    const p = projectsById.get(String(current.projectId)) || {};
    
    if (currentChatName) {
        currentChatName.textContent = `${p.title || "Project"} Chat`;
    }
    
    if (currentChatAvatar) {
        currentChatAvatar.src = `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(current.peer)}`;
    }
    
    renderProjectFlags(p);
    updateProjectSummaryLine(p);
    try { if (typeof toggleChatInfoMenu === "function") toggleChatInfoMenu(false); } catch {}
    updateHeaderActionButtonsForCurrent();
    updatePresenceForPeer(current.peer.toLowerCase());
    
    // ✅ این دوتا رو با await فراخوانی کن
    await renderMessagesForCurrent();
    await refreshMetaForCurrent();
    
    // بارگذاری کلید چت برای این پروژه
    if (e2eeEnabled) {
        await getOrCreateChatKey(current.projectId);
    }
}

// ----------------- Render messages -----------------
async function renderMessagesForCurrent() {
    if (!messagesArea) return;
    if (!current) {
        messagesArea.innerHTML =
            '<div style="padding:20px;color:#8aa;text-align:center;">Select a conversation.</div>';
        return;
    }
    const keepAtBottom = isNearBottom(messagesArea);
    messagesArea.innerHTML = "";
    const pid = String(current.projectId);
    const peer = current.peer.toLowerCase();
    
    const msgs = cacheMessages.filter((m) => {
        const mpid = String(m.projectId);
        const s = m.sender.toLowerCase();
        const r = m.receiver.toLowerCase();
        if (mpid !== pid) return false;
        return (
            (s === userWallet && r === peer) || (s === peer && r === userWallet)
        );
    });
    
    msgs.sort(
        (a, b) =>
            new Date(a.timestamp || a.createdAt || 0) -
            new Date(b.timestamp || b.createdAt || 0)
    );
    
    let lastDateLabel = "";
    
    for (const m of msgs) {
        const ts = m.timestamp || m.createdAt || Date.now();
        const dateLabel = formatDateLabel(ts);
        if (dateLabel && dateLabel !== lastDateLabel) {
            const sep = document.createElement("div");
            sep.style.textAlign = "center";
            sep.style.margin = "10px 0";
            sep.style.fontSize = "0.75rem";
            sep.style.opacity = "0.7";
            sep.textContent = dateLabel;
            messagesArea.appendChild(sep);
            lastDateLabel = dateLabel;
        }
        
        const type = m.sender.toLowerCase() === userWallet ? "sent" : "received";
        
        const wrapper = document.createElement("div");
        wrapper.style.display = "flex";
        wrapper.style.alignItems = "flex-end";
        wrapper.style.gap = "8px";
        wrapper.style.maxWidth = "80%";
        wrapper.style.marginLeft = type === "sent" ? "auto" : "0";
        
        if (type === "received") {
            const avatar = document.createElement("img");
            avatar.src = `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(
                current.peer
            )}`;
            avatar.style.width = "28px";
            avatar.style.height = "28px";
            avatar.style.borderRadius = "50%";
            avatar.style.flexShrink = "0";
            wrapper.appendChild(avatar);
        }
        
        const div = document.createElement("div");
        div.className = `message ${type}`;
        
        // رمزگشایی پیام اگر رمزنگاری شده باشد
        let displayText = m.text;
        if (m.isEncrypted) {
            displayText = await decryptMessageIfNeeded(m);
        }
        
        div.innerHTML = `<p>${escapeHTML(displayText)
            .replaceAll("\n", "<br>")}</p><span class="time">${escapeHTML(
                formatTime(ts)
            )}</span>`;
        wrapper.appendChild(div);
        messagesArea.appendChild(wrapper);
    }
    
    if (!msgs.length) {
        messagesArea.innerHTML =
            '<div style="padding:14px;color:#8aa">No messages yet. Say hi 👋</div>';
    }
    
    if (keepAtBottom) {
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }
}

// ----------------- Send message (E2EE) -----------------
async function sendMessage() {
    try {
        if (!current) return alert("Select a conversation first.");
        const text = (messageInput?.value || "").toString().trim();
        if (!text) return;
        const peer = current.peer.toLowerCase();
        if (!isAddr(peer)) return alert("Invalid peer address.");
        if (messageInput) messageInput.value = "";
        
        // رمزنگاری پیام اگر E2EE فعال باشد
        let payload = {
            projectId: current.projectId,
            sender: userWallet,
            receiver: peer,
            text: text,
        };
        
        if (e2eeEnabled) {
            try {
                const aesKey = await getOrCreateChatKey(current.projectId);
                const encrypted = await KrylsCrypto.encryptMessage(text, aesKey);
                
                // ✅ این قسمت جدید را اضافه کن:
                // SEAL MESSAGE برای admin/oracle recovery
                const sealed = await KrylsCrypto.sealMessageV2(
                    text,
                    aesKey,
                    current.projectId,
                    userWallet,
                    peer
                );
                
                payload = {
                    projectId: current.projectId,
                    sender: userWallet,
                    receiver: peer,
                    text: encrypted.cipher,
                    iv: encrypted.iv,
                    isEncrypted: true,
                    sealed: sealed  // ✅ این خط مهم است!
                };
            } catch (e) {
                console.error("Encrypt failed, sending plain: ", e);
            }
        }
        
        await apiPOST(`${API_URL}/api/send-message`, payload);
        await refreshAll(true);
    } catch (e) {
        console.error(e);
        alert(e?.message || "Send failed");
    }
}

// ----------------- Reject request off-chain -----------------
async function rejectRequestOffChain(reqObj) {
    const project =
        reqObj.project || projectsById.get(String(reqObj.projectId)) || null;
    if (!project) throw new Error("Project not found.");
    if ((project.owner || "").toLowerCase() !== userWallet) {
        throw new Error("Only project owner can reject.");
    }
    if (reqObj.status !== "Pending") {
        throw new Error("This request is not pending.");
    }
    const ok = confirm("Reject this freelancer request?");
    if (!ok) return;
    await apiPOST(`${API_URL}/api/requests/reject`, {
        ownerWallet: userWallet,
        requestId: reqObj.id,
        projectId: reqObj.projectId,
        freelancer: (reqObj.freelancer || "").toLowerCase(),
    });
    
    alert("Rejected.");
    await refreshAll(true);
}

// ---------- helpers for categories to avoid out-of-bounds ----------
function toUint8Safe(v, fallback = 0) {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback;
    if (n < 0 || n > 255) return fallback;
    return n;
}

function clamp(n, min, max) {
    n = Number(n);
    if (!Number.isFinite(n)) return min;
    return Math.min(max, Math.max(min, n));
}

function normalizeCategoriesForEscrow(project) {
    const isWeb3 = !!project.isWeb3Service;
    // کانترکت: Web3ServiceCategory: 0..11 ، DigitalServiceCategory: 0..3
    // Web3RoleCategory: 0..16 ، DigitalRoleCategory: 0..7
    const serviceMax = isWeb3 ? 11 : 3;
    const roleMax = isWeb3 ? 16 : 7;
    let s = toUint8Safe(project.serviceCategory, 0);
    let r = toUint8Safe(project.roleCategory, 0);
    s = clamp(s, 0, serviceMax);
    r = clamp(r, 0, roleMax);
    return { serviceCategory: s, roleCategory: r, isWeb3 };
}

// --------- Helper: Decode escrow revert reason (safe fallback) ----------
function decodeEscrowRevert(err) {
  try {
    // ethers v5/v6 typical shapes
    const message =
      err?.reason ||
      err?.error?.reason ||
      err?.error?.message ||
      err?.shortMessage ||
      err?.message ||
      "";

    if (typeof message === "string" && message.trim()) {
      return message.replace(/^execution reverted:\s*/i, "").trim();
    }

    const data =
      err?.error?.data ||
      err?.data ||
      err?.info?.error?.data ||
      err?.receipt?.revertReason ||
      null;

    // Try decode Error(string): selector 0x08c379a0
    if (typeof data === "string" && data.startsWith("0x08c379a0")) {
      const hex = data.slice(10); // after selector
      const lenHex = hex.slice(64, 128);
      const len = parseInt(lenHex, 16);
      const strHex = hex.slice(128, 128 + len * 2);

      let out = "";
      for (let i = 0; i < strHex.length; i += 2) {
        out += String.fromCharCode(parseInt(strHex.slice(i, i + 2), 16));
      }
      return out.trim() || "Transaction reverted";
    }

    // Try panic(uint256): selector 0x4e487b71
    if (typeof data === "string" && data.startsWith("0x4e487b71")) {
      return "EVM Panic (assert/overflow/etc.)";
    }

    // Custom errors (Solidity >=0.8.4) return the error selector (4 bytes) + encoded args.
    // If we can't decode it, at least show the selector.
    if (typeof data === "string" && /^0x[0-9a-fA-F]{8}$/.test(data)) {
      return `Custom error (${data})`;
    }
    if (typeof data === "string" && /^0x[0-9a-fA-F]{8}/.test(data)) {
      const sel = data.slice(0, 10);
      return `Custom error (${sel})`;
    }

    return "Transaction reverted";
  } catch (_) {
    return "Transaction reverted";
  }
}


// ----------------- Approve request on-chain -----------------
async function approveRequestOnChain(reqObj) {
    // Basic validation first (avoid opening modal on obvious errors)
    const project =
        reqObj.project || projectsById.get(String(reqObj.projectId)) || null;
    if (!project) throw new Error("Project not found.");
    if ((project.owner || "").toLowerCase() !== userWallet) {
        throw new Error("Only project owner can approve.");
    }
    const freelancer = (reqObj.freelancer || "").toLowerCase();
    if (!isAddr(freelancer)) throw new Error("Invalid freelancer.");
    if (freelancer === userWallet) {
        throw new Error("Owner cannot be freelancer.");
    }

    // Progress popup (same site theme)
    showEscrowProgressModal("Approve & Create Escrow");
    const st1 = escrowStepAdd("Connect wallet & switch network (Sepolia)");
    const st2 = escrowStepAdd("Resolve token & prepare parameters");
    const st3 = escrowStepAdd("Approve token (if needed)");
    const st4 = escrowStepAdd("Register client (if needed)");
    const st5 = escrowStepAdd("Create escrow on-chain");
    const st6 = escrowStepAdd("Confirm request in backend");

    escrowStepUpdate(st1, "doing", "Waiting for wallet…");
    escrowProgressSubtitle("Starting escrow approval…");

    try {
        const provider = getProvider();
        if (!provider) throw new Error("MetaMask not found.");

        await provider.send("eth_requestAccounts", []);
        await ensureSepolia(provider);

        const signer = provider.getSigner();
        const me = (await signer.getAddress()).toLowerCase();
        if (me !== userWallet) {
            throw new Error("Connected wallet mismatch.");
        }
        escrowStepUpdate(st1, "ok", "Wallet connected & network OK");

        // Prepare escrow contract early (we need it to detect registration requirement)
        const escrow = new ethers.Contract(ESCROW_ADDRESS, ESCROW_ABI, signer);

        // token resolve
        escrowStepUpdate(st2, "doing", "Resolving token…");
        const token = resolveProjectToken(project);
        if (!isAddr(token)) throw new Error("Token address not resolved.");
        if (!isSupportedTokenAddress(token)) {
            throw new Error(
                "Escrow whitelist – only USDT/USDC/DAI on Sepolia are allowed."
            );
        }

        const erc20 = new ethers.Contract(token, ERC20_ABI, signer);
        const decimals = await erc20.decimals();

        const paymentTypeHuman = Number.isFinite(project.paymentType)
            ? project.paymentType
            : 0;
        const paymentType = paymentTypeHuman;

        // Total commitment (human) from DB (fallbacks kept for legacy)
        const totalCommitmentHuman =
            project.totalCommitment ?? project.budget ?? 0;

        let totalCommitment = ethers.utils.parseUnits(
            totalCommitmentHuman.toString(),
            decimals
        );

        // Milestones (if any)
        const msAmountsHuman = Array.isArray(project.milestoneAmounts)
            ? project.milestoneAmounts
            : [];
        const msDescs = Array.isArray(project.milestoneDescriptions)
            ? project.milestoneDescriptions
            : [];

        let milestoneAmounts = msAmountsHuman.map((a) =>
            ethers.utils.parseUnits((a || 0).toString(), decimals)
        );
        let milestoneDescriptions = msDescs.map((d) => d?.toString() || "");

        // ---------------- Normalize terms to satisfy contract invariants ----------------
        const ZERO = ethers.constants.Zero;

        // Enforce commitment > 0 early
        if (totalCommitment.lte(ZERO)) {
            throw new Error("Total commitment must be greater than 0.");
        }

        // Normalize milestone arrays depending on paymentType
        if (paymentType === 1) {
            if (!milestoneAmounts.length) {
                throw new Error(
                    "Payment type is Milestones but no milestones found. Please edit the project and add milestones."
                );
            }

            // Align descriptions length with amounts length
            if (milestoneDescriptions.length < milestoneAmounts.length) {
                while (milestoneDescriptions.length < milestoneAmounts.length) {
                    milestoneDescriptions.push("");
                }
            } else if (milestoneDescriptions.length > milestoneAmounts.length) {
                milestoneDescriptions = milestoneDescriptions.slice(
                    0,
                    milestoneAmounts.length
                );
            }


            // Each milestone must be > 0
            for (let i = 0; i < milestoneAmounts.length; i++) {
                if (milestoneAmounts[i].lte(ZERO)) {
                    throw new Error(`Milestone #${i + 1} amount must be greater than 0.`);
                }
            }

            // Sum milestones; many escrow contracts require sum(milestones) == totalCommitment
            const msSum = milestoneAmounts.reduce(
                (acc, x) => acc.add(x),
                ZERO
            );

            if (msSum.lte(ZERO)) {
                throw new Error("Milestone amounts are invalid (sum = 0).");
            }

            // If the stored totalCommitment mismatches milestone sum, prefer milestone sum for on-chain correctness.
            // (This prevents createProject revert when DB budget/milestones diverged.)
            if (!msSum.eq(totalCommitment)) {
                totalCommitment = msSum;
            }
        } else {
            // Non-milestone payment types should not pass milestone arrays.
            milestoneAmounts = [];
            milestoneDescriptions = [];
        }

        escrowStepUpdate(st2, "ok", "Token resolved & parameters ready");

        // ------------- REGISTRATION REQUIREMENT (view call) -------------
        // We must account for the registration fee spending from the SAME allowance,
        // otherwise createProject can revert (insufficient allowance after registerClient()).
        let isClient = false;
        try {
            isClient = await escrow.isRegisteredClient(me);
        } catch {
            // If view call fails for any reason, assume not registered and proceed with registration flow.
            isClient = false;
        }

        const regFee = ethers.utils.parseUnits("30", decimals);
        const requiredSpend = isClient
            ? totalCommitment
            : totalCommitment.add(regFee);

        // ------------- Balance pre-check (avoids opaque CALL_EXCEPTION) -------------
        try {
            const bal = await erc20.balanceOf(me);
            if (bal.lt(requiredSpend)) {
                const needHuman = ethers.utils.formatUnits(requiredSpend, decimals);
                const balHuman = ethers.utils.formatUnits(bal, decimals);
                throw new Error(
                    `Insufficient token balance. Need ${needHuman}, you have ${balHuman}.`
                );
            }
        } catch (e) {
            // If balanceOf fails, ignore; otherwise bubble up our explicit error.
            if (e?.message?.startsWith?.("Insufficient token balance")) throw e;
        }

        // ------------- Allowance / Approval -------------
        escrowStepUpdate(st3, "doing", "Checking allowance…");

        const approveAmount = requiredSpend;
        const allowance = await erc20.allowance(me, ESCROW_ADDRESS);

        async function approveWithResetIfNeeded(amount) {
            try {
                const tx = await erc20.approve(ESCROW_ADDRESS, amount);
                await tx.wait(1);
                return;
            } catch (e) {
                // Some tokens (notably USDT variants) require setting allowance to 0 before changing it.
                try {
                    const tx0 = await erc20.approve(ESCROW_ADDRESS, 0);
                    await tx0.wait(1);
                    const tx2 = await erc20.approve(ESCROW_ADDRESS, amount);
                    await tx2.wait(1);
                    return;
                } catch (_) {
                    throw e;
                }
            }
        }

        if (allowance.lt(approveAmount)) {
            escrowStepUpdate(
                st3,
                "doing",
                isClient
                    ? "Approving token for escrow… (confirm in wallet)"
                    : "Approving token for escrow + registration… (confirm in wallet)"
            );

            setStatus(
                isClient
                    ? "Approving token for escrow…"
                    : "Approving token for escrow + registration…",
                true
            );

            await approveWithResetIfNeeded(approveAmount);
            escrowStepUpdate(st3, "ok", "Token approved");
        } else {
            escrowStepUpdate(st3, "ok", "Allowance already sufficient");
        }

        // ------------- Register client (if needed) -------------
        escrowStepUpdate(st4, "doing", "Checking registration…");
        if (!isClient) {
            escrowStepUpdate(
                st4,
                "doing",
                "Registering client… (confirm in wallet)"
            );
            setStatus("Registering client…", true);

            const regTx = await escrow.registerClient(token);
            await regTx.wait(1);

            // Safety: after reg fee is taken, ensure we still have allowance >= totalCommitment
            try {
                const allowAfter = await erc20.allowance(me, ESCROW_ADDRESS);
                if (allowAfter.lt(totalCommitment)) {
                    setStatus("Restoring escrow allowance after registration…", true);
                    await approveWithResetIfNeeded(totalCommitment);
                }
            } catch {
                // ignore
            }

            escrowStepUpdate(st4, "ok", "Client registered");
            setStatus("Client registered, creating escrow…", true);
        } else {
            escrowStepUpdate(st4, "ok", "Client already registered");
        }

        const arbitrator = ethers.constants.AddressZero;

        // جلوگیری از value out-of-bounds برای enumها
        const { serviceCategory, roleCategory, isWeb3 } =
            normalizeCategoriesForEscrow(project);

        escrowStepUpdate(st5, "doing", "Creating escrow… (confirm in wallet)");
        setStatus("Creating escrow on-chain…", true);

        let onChainId = null;
        try {
            onChainId = await escrow.callStatic.createProject(
                freelancer,
                token,
                totalCommitment,
                paymentType,
                milestoneAmounts,
                milestoneDescriptions,
                isWeb3,
                serviceCategory,
                roleCategory,
                !!project.issueCertificate,
                arbitrator,
                false,
                false // enableXMTP (backend MVP)
            );
        } catch (e) {
            const decoded = decodeEscrowRevert(e);
            throw new Error(
                decoded || e?.reason || e?.message || "createProject reverted"
            );
        }

        const tx2 = await escrow.createProject(
            freelancer,
            token,
            totalCommitment,
            paymentType,
            milestoneAmounts,
            milestoneDescriptions,
            isWeb3,
            serviceCategory,
            roleCategory,
            !!project.issueCertificate,
            arbitrator,
            false,
            false
        );
        const receipt = await tx2.wait(1);
        escrowStepUpdate(st5, "ok", "On-chain escrow created");

        escrowStepUpdate(st6, "doing", "Saving confirmation in backend…");
        await apiPOST(`${API_URL}/api/requests/confirm`, {
            ownerWallet: userWallet,
            requestId: reqObj.id,
            projectId: reqObj.projectId,
            freelancer,
            txHash: receipt.transactionHash,
            onChainId: onChainId ? onChainId.toString() : null,
        });
        escrowStepUpdate(st6, "ok", "Backend confirmed");

        escrowProgressDone(true);
        await refreshAll(true);
    } catch (e) {
        // Mark the last step that was "doing" as failed (best-effort)
        try {
            // find any step still in "doing" state by icon
            const steps = [st1, st2, st3, st4, st5, st6];
            for (const s of steps) {
                const icon = s?.querySelector?.(".k-step-icon")?.textContent || "";
                if (icon.includes("⏳")) {
                    escrowStepUpdate(s, "fail", "Failed");
                }
            }
        } catch (_) {}

        escrowProgressSubtitle("An error occurred.");
        escrowProgressDone(false);
        throw e;
    }
}

// ----------------- Token resolve – Sepolia supported -----------------
function resolveProjectToken(project) {
    const direct = (project?.token || "").toString().trim();
    if (isAddr(direct)) return direct;
    const directSym = direct.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (directSym && TOKEN_ADDRESSES[directSym]) {
        return TOKEN_ADDRESSES[directSym];
    }
    const sym = (project?.tokenSymbol || "")
        .toString()
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "");
    if (sym && TOKEN_ADDRESSES[sym]) {
        return TOKEN_ADDRESSES[sym];
    }
    const altSym = (project?.currency || project?.cpToken || "")
        .toString()
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "");
    if (altSym && TOKEN_ADDRESSES[altSym]) {
        return TOKEN_ADDRESSES[altSym];
    }
    return null;
}

function isSupportedTokenAddress(tokenAddr) {
    const t = tokenAddr.toString().toLowerCase();
    return Object.values(TOKEN_ADDRESSES).some(
        (x) => x.toLowerCase() === t
    );
}

// ----------------- Terms / Delivery / Dispute helpers -----------------
async function loadOracles() {
    try {
        const data = await apiJSON(`${API_URL}/api/oracles`);
        cachedOracles = Array.isArray(data.oracles) ? data.oracles : [];
    } catch {
        cachedOracles = [];
    }
}

function fillOracleSelect() {
    if (!oracleSelect) return;
    oracleSelect.innerHTML = "";
    const list = Array.isArray(cachedOracles) ? cachedOracles : [];
    if (!list.length) {
        const opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "No oracles configured";
        oracleSelect.appendChild(opt);
        return;
    }
    list.forEach((o) => {
        const opt = document.createElement("option");
        opt.value = o.wallet.toString();
        opt.textContent = `${o.name} ${o.wallet.slice(0, 6)}…${o.wallet.slice(-4)}`;
        oracleSelect.appendChild(opt);
    });
}

async function fetchPendingTerms(projectId) {
    try {
        const data = await apiJSON(
            `${API_URL}/api/terms/pending/${encodeURIComponent(projectId)}`
        );
        return data.proposal || null;
    } catch {
        return null;
    }
}

async function fetchLatestDelivery(projectId) {
    try {
        const data = await apiJSON(
            `${API_URL}/api/delivery/latest/${encodeURIComponent(projectId)}`
        );
        return data.delivery || null;
    } catch {
        return null;
    }
}

async function fetchLatestDispute(projectId) {
    try {
        const data = await apiJSON(
            `${API_URL}/api/dispute/latest/${encodeURIComponent(projectId)}`
        );
        return data.dispute || null;
    } catch {
        return null;
    }
}

function updateProjectTermsLine(project) {
    if (!projectTermsLine) return;
    if (!project) {
        projectTermsLine.textContent = "";
        return;
    }
    const extra =
        project.status === "Completed"
            ? " · Completed (chat auto-delete 24h)"
            : project.status === "Disputed"
                ? " · Disputed"
                : "";
    projectTermsLine.textContent = humanTerms(project) + extra;
}

async function proposeTermsChange() {
    if (!current) return;
    const price = (termsPriceInput?.value || "").toString().trim();
    const deliveryDate = (termsDeliveryDateInput?.value || "").toString().trim();
    const deliveryDays = (termsDeliveryDaysInput?.value || "").toString().trim();
    await apiPOST(`${API_URL}/api/terms/propose`, {
        projectId: current.projectId,
        wallet: userWallet,
        price,
        deliveryDate,
        deliveryDays,
    });
    alert("Terms proposal sent.");
    closeModal(termsModal);
    await refreshAll(true);
}

async function acceptOrRejectPendingTerms(action) {
    if (!current || !lastTermsProposal) return;
    await apiPOST(`${API_URL}/api/terms/respond`, {
        projectId: current.projectId,
        wallet: userWallet,
        proposalId: lastTermsProposal.id,
        action,
    });
    alert(action === "accept" ? "Terms accepted." : "Terms rejected.");
    await refreshAll(true);
}

async function submitDelivery() {
    if (!current) return;
    const content = (deliveryContentInput?.value || "").toString().trim();
    if (!content) return alert("Please enter delivery details.");
    await apiPOST(`${API_URL}/api/delivery/submit`, {
        projectId: current.projectId,
        freelancerWallet: userWallet,
        content,
    });
    alert("Delivery submitted.");
    closeModal(deliveryModal);
    await refreshAll(true);
}

async function acceptDelivery() {
    if (!current || !lastDelivery) return alert("No delivery found.");
    await apiPOST(`${API_URL}/api/delivery/accept`, {
        projectId: current.projectId,
        ownerWallet: userWallet,
        deliveryId: lastDelivery.id,
    });
    alert("Delivery accepted. Chat will auto-delete after 24h.");
    await refreshAll(true);
}

async function openDispute() {
    if (!current || !lastDelivery) return alert("No delivery found to dispute.");
    const reason = (disputeReasonInput?.value || "").toString().trim();
    const oracleWallet = (oracleSelect?.value || "").toString().trim();
    await apiPOST(`${API_URL}/api/delivery/dispute`, {
        projectId: current.projectId,
        wallet: userWallet,
        deliveryId: lastDelivery.id,
        reason,
        oracleWallet,
    });
    alert("Dispute opened.");
    closeModal(disputeModal);
    await refreshAll(true);
}

async function oracleResolveDispute() {
    if (!current || !lastDispute) return alert("No dispute found.");
    const decision =
        prompt("Decision? (release/refund/split)", "release") || "";
    const d = decision.toString().toLowerCase();
    if (!d) return;
    const notes = (prompt("Notes (optional)", "") || "").toString();
    await apiPOST(`${API_URL}/api/dispute/resolve`, {
        disputeId: lastDispute.id,
        oracleWallet: userWallet,
        decision: d,
        notes,
    });
    alert("Dispute resolved.");
    await refreshAll(true);
}

async function refreshMetaForCurrent() {
    if (!current) return;
    const p = projectsById.get(String(current.projectId)) || {};
    updateProjectTermsLine(p);
    lastTermsProposal = await fetchPendingTerms(current.projectId);
    lastDelivery = await fetchLatestDelivery(current.projectId);
    lastDispute = await fetchLatestDispute(current.projectId);
    // pending terms bar
    if (termsPendingBar) {
        termsPendingBar.style.display = "none";
        termsPendingBar.innerHTML = "";
        if (lastTermsProposal && lastTermsProposal.status === "Pending") {
            const proposer = (lastTermsProposal.proposer || "").toLowerCase();
            const isMine = proposer === userWallet;
            const dd = (lastTermsProposal.deliveryDate || "").toString().trim();
            const days = (lastTermsProposal.deliveryDays || "")
                .toString()
                .trim();
            const deliveryText = dd || days ? `${days || dd}` : "";
            const priceText = (lastTermsProposal.price || "").toString();
            const base = `
                <div class="k-banner">
                    <b>Pending terms proposal</b>
                    <div style="margin-top:6px;">
                        Price: ${escapeHTML(priceText)} · Delivery: ${escapeHTML(
                deliveryText
            )}
                    </div>
                </div>
            `;
            
            if (!isMine) {
                termsPendingBar.style.display = "block";
                termsPendingBar.innerHTML = `
                    ${base}
                    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;">
                        <button class="mini-btn" id="acceptPendingTermsBtn">Accept</button>
                        <button class="mini-btn" id="rejectPendingTermsBtn" style="border-color:rgba(255,92,122,0.45);background:rgba(255,92,122,0.10);color:#ff5c7a;">Reject</button>
                    </div>
                `;
                const a = document.getElementById("acceptPendingTermsBtn");
                const r = document.getElementById("rejectPendingTermsBtn");
                if (a) a.onclick = () => acceptOrRejectPendingTerms("accept");
                if (r) r.onclick = () => acceptOrRejectPendingTerms("reject");
            } else {
                termsPendingBar.style.display = "block";
                termsPendingBar.innerHTML = `
                    ${base}
                    <div style="margin-top:10px;opacity:0.9;">Waiting for the other party</div>
                `;
            }
        }
    }
    updateActionButtonsForCurrentProject(p);
}

function updateActionButtonsForCurrentProject(project) {
    if (changeTermsBtn) changeTermsBtn.style.display = "none";
    if (submitDeliveryBtn) submitDeliveryBtn.style.display = "none";
    if (acceptDeliveryBtn) acceptDeliveryBtn.style.display = "none";
    if (openDisputeBtn) openDisputeBtn.style.display = "none";
    if (resolveDisputeBtn) resolveDisputeBtn.style.display = "none";
    if (!project || !current) return;
    const status = (project.status || "").toString();
    
    // Terms change allowed in In Progress / Disputed
    if (status === "In Progress" || status === "Disputed") {
        if (changeTermsBtn) changeTermsBtn.style.display = "inline-flex";
    }
    
    // Delivery flow
    if (current.role === "freelancer" && status === "In Progress") {
        if (submitDeliveryBtn) submitDeliveryBtn.style.display = "inline-flex";
    }
    
    if (current.role === "owner" && status === "In Progress") {
        if (lastDelivery && lastDelivery.status === "Submitted") {
            if (acceptDeliveryBtn) acceptDeliveryBtn.style.display = "inline-flex";
            if (openDisputeBtn) openDisputeBtn.style.display = "inline-flex";
        }
    }
    
    // Oracle resolve
    if (status === "Disputed" && lastDispute && lastDispute.status === "Open") {
        const oracle = (lastDispute.oracle || "").toLowerCase();
        if (oracle && oracle === userWallet) {
            if (resolveDisputeBtn)
                resolveDisputeBtn.style.display = "inline-flex";
        }
    }
}

// ----------------- Refresh loop -----------------
async function refreshAll(force = false) {
    try {
        await pingPresence();
        setStatus(lastPresenceText || "Live", true);
        await loadProjectsIndex();
        const [incoming, mine] = await loadRequests();
        await loadMessages();
        
        buildConversationsFromState(incoming, mine);
        await renderConversationsList();
        renderRequestsPanel(incoming);
        
        // auto-select
        if (!current) {
            if (preselectProjectId) {
                const c = conversations.find(
                    (x) => String(x.projectId) === String(preselectProjectId)
                );
                if (c) await selectConversation(c.key);  // ✅ await اضافه شد
            }
            if (!current && conversations.length) {
                await selectConversation(conversations[0].key);  // ✅ await اضافه شد
            }
        } else {
            await renderMessagesForCurrent();
            updateHeaderActionButtonsForCurrent();
            if (current.peer) {
                updatePresenceForPeer(current.peer.toLowerCase());
            }
            await refreshMetaForCurrent();
        }
        
        if (!current) setStatus("Live", true);
    } catch (e) {
        console.error(e);
        setStatus("Offline · Server error", false);
    }
}

// ----------------- Project info popup -----------------
function buildProjectInfoHTML(project) {
    if (!project) return '<div style="padding:20px;color:#8aa;text-align:center;">No project selected.</div>';
    const pid = project?.id ?? project?.projectId ?? '';
    const title = project?.title ?? `Project ${String(pid)}`;
    const owner = project?.owner ? short(String(project.owner).toLowerCase()) : '';
    const freelancer = project?.assignedFreelancer
        ? short(String(project.assignedFreelancer).toLowerCase())
        : (project?.freelancer ? short(String(project.freelancer).toLowerCase()) : '');
    const budget = project?.budget ?? project?.totalCommitment ?? '';
    const tokenSym = (project?.tokenSymbol ?? project?.token ?? project?.currency ?? 'USDT').toString();
    const status = (project?.status ?? 'Open').toString();
    const terms = humanTerms(project);
    const isWeb3 = !!project?.isWeb3Service;
    return `<div style="display:grid; gap:10px;">
        <div style="font-weight:800; font-size:1.05rem;">${escapeHTML(title)}</div>
        <div style="opacity:0.92;">Project ID: <span style="opacity:0.9;">${escapeHTML(String(pid))}</span></div>
        <div style="opacity:0.92;">Status: <span style="opacity:0.9;">${escapeHTML(status)}</span></div>
        <div style="opacity:0.92;">Budget: <span style="opacity:0.9;">${escapeHTML(String(budget))} ${escapeHTML(tokenSym)}</span></div>
        <div style="opacity:0.92;">Owner: <span style="opacity:0.9;">${escapeHTML(owner)}</span></div>
        <div style="opacity:0.92;">Freelancer: <span style="opacity:0.9;">${escapeHTML(freelancer)}</span></div>
        <div style="opacity:0.92;">Terms: <span style="opacity:0.9;">${escapeHTML(terms)}</span></div>
        <div style="opacity:0.92;">Service: <span style="opacity:0.9;">${escapeHTML(isWeb3 ? 'Web3' : 'Digital')}</span></div>
    </div>`;
}

function openProjectInfoPopup() {
    if (!projectInfoModal || !projectInfoBody) return;
    const p = current ? projectsById.get(String(current.projectId)) : null;
    projectInfoBody.innerHTML = buildProjectInfoHTML(p);
    openModal(projectInfoModal);
}

function closeProjectInfoPopup() {
    if (!projectInfoModal) return;
    closeModal(projectInfoModal);
}

// ----------------- Events -----------------
if (chatInfoBtn) chatInfoBtn.addEventListener('click', openProjectInfoPopup);
if (closeProjectInfoModalBtn) closeProjectInfoModalBtn.addEventListener('click', closeProjectInfoPopup);
if (projectInfoModal) projectInfoModal.addEventListener('click', (e) => { if (e.target === projectInfoModal) closeProjectInfoPopup(); });

if (toggleRequestsBtn) {
    toggleRequestsBtn.addEventListener("click", () => {
        requestsCollapsed = !requestsCollapsed;
        localStorage.setItem("requestsCollapsed", requestsCollapsed ? "1" : "0");
        if (requestsPanel) {
            if (requestsCollapsed) {
                requestsPanel.classList.add("collapsed");
                toggleRequestsBtn.textContent = "Requests ▾";
            } else {
                requestsPanel.classList.remove("collapsed");
                toggleRequestsBtn.textContent = "Requests ▴";
            }
        }
    });
}

if (closeTermsModalBtn) {
    closeTermsModalBtn.addEventListener("click", () => closeModal(termsModal));
}

if (termsModal) {
    termsModal.addEventListener("click", (e) => {
        if (e.target === termsModal) closeModal(termsModal);
    });
}

if (submitTermsBtn) {
    submitTermsBtn.addEventListener("click", async () => {
        try {
            await proposeTermsChange();
        } catch (e) {
            console.error(e);
            alert(e?.message || "Terms propose failed");
        }
    });
}

if (closeDeliveryModalBtn) {
    closeDeliveryModalBtn.addEventListener("click", () => closeModal(deliveryModal));
}

if (deliveryModal) {
    deliveryModal.addEventListener("click", (e) => {
        if (e.target === deliveryModal) closeModal(deliveryModal);
    });
}

if (submitDeliveryConfirmBtn) {
    submitDeliveryConfirmBtn.addEventListener("click", async () => {
        try {
            await submitDelivery();
        } catch (e) {
            console.error(e);
            alert(e?.message || "Delivery submit failed");
        }
    });
}

if (closeDisputeModalBtn) {
    closeDisputeModalBtn.addEventListener("click", () => closeModal(disputeModal));
}

if (disputeModal) {
    disputeModal.addEventListener("click", (e) => {
        if (e.target === disputeModal) closeModal(disputeModal);
    });
}

if (openDisputeConfirmBtn) {
    openDisputeConfirmBtn.addEventListener("click", async () => {
        try {
            await openDispute();
        } catch (e) {
            console.error(e);
            alert(e?.message || "Dispute failed");
        }
    });
}

if (changeTermsBtn) {
    changeTermsBtn.onclick = () => openModal(termsModal);
}

if (submitDeliveryBtn) {
    submitDeliveryBtn.onclick = () => {
        if (deliveryContentInput) deliveryContentInput.value = "";
        openModal(deliveryModal);
    };
}

if (acceptDeliveryBtn) {
    acceptDeliveryBtn.onclick = () => acceptDelivery();
}

if (openDisputeBtn) {
    openDisputeBtn.onclick = async () => {
        await loadOracles();
        fillOracleSelect();
        if (disputeReasonInput) disputeReasonInput.value = "";
        openModal(disputeModal);
    };
}

if (resolveDisputeBtn) {
    resolveDisputeBtn.onclick = () => oracleResolveDispute();
}

if (sendBtn) {
    sendBtn.addEventListener("click", () => sendMessage());
}

if (messageInput) {
    messageInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

document.addEventListener("mousemove", (e) => {
    const glow = document.querySelector(".bg-glow");
    if (glow) {
        glow.style.transform =
            `translate(${e.clientX - 50}px, ${-e.clientY + 50}px)`;
    }
});

// ----------------- Boot -----------------
await loadMyProfile();
await loadAdminPublicKey();
setE2EEStatus(e2eeEnabled, false);
await refreshAll(true);
setInterval(() => refreshAll(false), 2500);
});