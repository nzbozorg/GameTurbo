// script.js

document.addEventListener('DOMContentLoaded', () => {
  // ---------------- تنظیمات ----------------
  const API_URL = `http://${window.location.hostname}:5000`;
  // const API_URL = "http://10.21.126.67:5000"; // اگر روی سرور خاصی هستید این را فعال کنید

  // ✅ آدرس قرارداد (برای آمار سایت)
  const CONTRACT_ADDRESS = "0xFd2F7895c9D851288e8Afb3e86fb9Bd4A9153BBb";

  // ---------------- DOM ----------------
  const connectBtn = document.getElementById('connectWalletBtn');
  const heroPostJobBtn = document.getElementById('heroPostJobBtn');

  const walletModal = document.getElementById('walletModal');
  const termsModal = document.getElementById('termsModal');
  const acceptTermsBtn = document.getElementById('acceptTermsBtn');
  const acceptTermsCheckbox = document.getElementById('acceptTermsCheckbox');
  const closeTermsModalBtn = document.getElementById('closeTermsModalBtn');

  const roleModal = document.getElementById('roleModal');
  const closeModalBtn = document.getElementById('closeModalBtn');

  // Onboarding wizard
  const onboardingModal = document.getElementById('onboardingModal');
  const onboardingCloseBtn = document.getElementById('onboardingCloseBtn');
  const obTitle = document.getElementById('obTitle');
  const obDesc = document.getElementById('obDesc');
  const obSteps = document.getElementById('obSteps');
  const obAvatar = document.getElementById('obAvatar');
  const obWalletLine = document.getElementById('obWalletLine');
  const obRoleFreelancer = document.getElementById('obRoleFreelancer');
  const obRoleClient = document.getElementById('obRoleClient');
  const obRoleHint = document.getElementById('obRoleHint');
  const obUsername = document.getElementById('obUsername');
  const obBio = document.getElementById('obBio');
  const obLink = document.getElementById('obLink');
  const obLinkHint = document.getElementById('obLinkHint');
  const obFinalLine = document.getElementById('obFinalLine');
  const obBackBtn = document.getElementById('obBackBtn');
  const obNextBtn = document.getElementById('obNextBtn');
  const obFinishBtn = document.getElementById('obFinishBtn');

  const profileIcon = document.getElementById('userProfileIcon');

  // Wallet buttons
  const btnMetaMask = document.getElementById('btn-metamask');
  const btnTrust = document.getElementById('btn-trust');

  // Role buttons (Company removed)
  const btnFreelancer = document.getElementById('select-freelancer');
  const btnClient = document.getElementById('select-client');

  // Swap demo
  const swapBtn = document.getElementById('swapBtn');
  const swapAmountFrom = document.getElementById('swapAmountFrom');
  const swapAmountTo = document.getElementById('swapAmountTo');

  // ---------------- State ----------------
  let isConnected = false;
  let currentWallet = "";
  let provider = null;
  let signer = null;

  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  const currentUrl = window.location.href.replace(/^https?:\/\//, '');

  // ---------------- Local keys ----------------
  const walletLower = (w) => String(w || '').toLowerCase();
  const obDoneKey = (w) => `onboarding_done_${walletLower(w)}`;
  const termsPendingKey = (w) => `terms_pending_${walletLower(w)}`;

  // ---------------- UX Fix: remove blinking caret on plain-text clicks ----------------
  // Some browsers/features (e.g., caret browsing) show a blinking insertion caret when clicking normal text.
  // This clears a *collapsed* selection outside of inputs/textareas so the caret doesn't appear.
  function clearCollapsedSelectionIfNeeded(evt) {
    try {
      const t = evt?.target;
      if (!t) return;
      if (t.closest && t.closest('input, textarea, [contenteditable="true"]')) return;

      const sel = window.getSelection ? window.getSelection() : null;
      if (!sel) return;
      if (sel.isCollapsed) sel.removeAllRanges();
    } catch {
      /* silent */
    }
  }
  document.addEventListener('mouseup', clearCollapsedSelectionIfNeeded);
  document.addEventListener('touchend', clearCollapsedSelectionIfNeeded, { passive: true });

  // ---------------- Helpers ----------------
  function walletAvatarDataUrl(wallet) {
  try {
    const w = String(wallet || '').toLowerCase();
    const hash = ethers.utils.keccak256(ethers.utils.toUtf8Bytes(w));
    const fg = '#' + hash.slice(2, 8);
    const fg2 = '#' + hash.slice(8, 14);

    const size = 96;
    const cells = 5;
    const cell = Math.floor(size / cells);

    let bits = hash.slice(14);
    let bi = 0;
    const rects = [];

    for (let y = 0; y < cells; y++) {
      for (let x = 0; x < Math.ceil(cells / 2); x++) {
        const h = bits.slice(bi, bi + 2);
        bi += 2;
        const v = parseInt(h || '00', 16);
        const on = (v % 2) === 1;
        if (!on) continue;

        const color = (v % 4) < 2 ? fg : fg2;

        const px = x * cell;
        const py = y * cell;
        rects.push(`<rect x="${px}" y="${py}" width="${cell}" height="${cell}" fill="${color}" rx="4" />`);

        const mx = (cells - 1 - x) * cell;
        if (mx !== px) {
          rects.push(`<rect x="${mx}" y="${py}" width="${cell}" height="${cell}" fill="${color}" rx="4" />`);
        }
      }
    }

    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
        <rect width="100%" height="100%" fill="rgba(255,255,255,0)" />
        ${rects.join('')}
      </svg>
    `.trim();

    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  } catch (e) {
    return `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(wallet)}`;
  }
}

  function resetButton() {
    if (!connectBtn) return;
    connectBtn.innerText = "Connect Wallet";
    connectBtn.removeAttribute("style");
  }

  function disconnectWallet() {
    isConnected = false;
    currentWallet = "";
    localStorage.removeItem('userWallet');
    localStorage.removeItem('walletProvider');
    resetButton();
    if (profileIcon) profileIcon.style.display = "none";
    if (swapBtn) swapBtn.innerText = "Connect Wallet to Swap";
    alert("🔌 Disconnected");
  }

  function loginSuccess(address) {
    isConnected = true;
    currentWallet = address;
    localStorage.setItem('userWallet', address);

    const shortAddr = address.slice(0, 6) + "..." + address.slice(-4);

    if (connectBtn) {
      connectBtn.innerText = shortAddr;
      connectBtn.style.background = "rgba(0, 240, 255, 0.1)";
      connectBtn.style.border = "1px solid #00f0ff";
      connectBtn.style.color = "#00f0ff";
      connectBtn.style.boxShadow = "0 0 15px rgba(0, 240, 255, 0.3)";
      connectBtn.style.opacity = "1";
    }

    if (profileIcon) {
      profileIcon.style.display = "block";
      const img = profileIcon.querySelector('img');
      if (img) img.src = walletAvatarDataUrl(address);
      profileIcon.onclick = () => {
        window.location.href = "dashboard.html";
      };
    }

    if (swapBtn) {
      swapBtn.innerText = "Swap Now (Demo)";
      swapBtn.classList.add('btn-primary');
    }
  }

  // ---------------- Server Background ----------------
  async function processLoginBackground(wallet) {
    try {
      const doneKey = obDoneKey(wallet);
      const pendingKey = termsPendingKey(wallet);
      const isDoneLocal = localStorage.getItem(doneKey) === '1';
      const isPending = localStorage.getItem(pendingKey) === '1';
      // اگر Terms از قبل pending است، فقط مودال را بالا نگه دار و هیچ درخواست/کاری نکن (جلوگیری از لوپ رفرش)
      if (!isDoneLocal && isPending && termsModal) {
        if (acceptTermsCheckbox) acceptTermsCheckbox.checked = false;
        if (acceptTermsBtn) {
          acceptTermsBtn.disabled = true;
          acceptTermsBtn.style.opacity = '0.55';
          acceptTermsBtn.style.cursor = 'not-allowed';
        }
        hideModal(walletModal);
        showModal(termsModal);
        return;
      }

      const res = await fetch(`${API_URL}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wallet })
      });

      const data = await res.json().catch(() => null);
      // show onboarding only once per wallet (server says new OR local flag missing)
      if (data && data.success && (data.isNewUser || !isDoneLocal)) {
        if (!isDoneLocal && termsModal) {
          // reset checkbox state and button state
          if (acceptTermsCheckbox) acceptTermsCheckbox.checked = false;
          if (acceptTermsBtn) {
            acceptTermsBtn.disabled = true;
            acceptTermsBtn.style.opacity = '0.55';
            acceptTermsBtn.style.cursor = 'not-allowed';
          }
          // persist modal state across refresh/navigation
          localStorage.setItem(pendingKey, '1');
          termsModal.classList.add('active');
        }
      }
    } catch (e) {
      console.log("Server connection failed (Offline Mode Active)");
    }
  }

  // ---------------- Onboarding Wizard ----------------
  let obStep = 0;
  let obRole = '';

  function showModal(el) {
    try { if (el) el.classList.add('active'); } catch {}
  }

  function hideModal(el) {
    try { if (el) el.classList.remove('active'); } catch {}
  }

  function setDotActive(idx) {
    try {
      const dots = obSteps?.querySelectorAll('.step-dot') || [];
      dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    } catch {}
  }

  function showObStep(n) {
    obStep = Math.max(0, Math.min(2, Number(n) || 0));

    // panels
    try {
      const steps = onboardingModal?.querySelectorAll('.ob-step') || [];
      steps.forEach((s) => {
        const si = Number(s.getAttribute('data-step'));
        s.style.display = (si === obStep) ? 'block' : 'none';
      });
    } catch {}

    // title/desc
    if (obTitle && obDesc) {
      if (obStep === 0) {
        obTitle.textContent = 'Set up your profile';
        obDesc.textContent = 'We created an avatar for your wallet.';
      } else if (obStep === 1) {
        obTitle.textContent = 'Choose your role';
        obDesc.textContent = 'Pick how you want to use KRYLS.';
      } else {
        obTitle.textContent = 'Finalize details';
        obDesc.textContent = 'Choose a username and optionally add a bio/link.';
      }
    }

    setDotActive(obStep);

    if (obBackBtn) obBackBtn.disabled = obStep === 0;
    if (obNextBtn) obNextBtn.style.display = obStep < 2 ? 'inline-flex' : 'none';
    if (obFinishBtn) obFinishBtn.style.display = obStep === 2 ? 'inline-flex' : 'none';

    // UX
    if (obFinalLine) obFinalLine.style.display = 'none';
  }

  function openOnboarding() {
    if (!onboardingModal) return;
    if (obAvatar) obAvatar.src = walletAvatarDataUrl(currentWallet);
    if (obWalletLine) obWalletLine.textContent = `Wallet: ${currentWallet.slice(0, 6)}...${currentWallet.slice(-4)}`;
    obRole = '';
    if (obRoleHint) obRoleHint.textContent = '';
    if (obUsername) obUsername.value = '';
    if (obBio) obBio.value = '';
    if (obLink) obLink.value = '';
    if (obLinkHint) obLinkHint.textContent = '';
    showObStep(0);
    showModal(onboardingModal);
  }

  function closeOnboarding() {
    hideModal(onboardingModal);
  }

  function markObRole(role) {
    const r = (role || '').toString().trim().toLowerCase();
    if (!['freelancer', 'client'].includes(r)) return;
    obRole = r;
    try {
      if (obRoleFreelancer) obRoleFreelancer.style.borderColor = r === 'freelancer' ? 'rgba(0,240,255,0.55)' : '';
      if (obRoleClient) obRoleClient.style.borderColor = r === 'client' ? 'rgba(0,240,255,0.55)' : '';
    } catch {}
    if (obRoleHint) obRoleHint.textContent = `Selected: ${r.toUpperCase()}`;
  }

  function normalizeUsernameClient(x) {
    return (x || '').toString().trim().toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  function isValidUsernameClient(x) {
    const u = normalizeUsernameClient(x);
    return u.length >= 4 && /^[a-z0-9]+$/.test(u);
  }

  function normalizeLinkClient(x) {
    const raw = (x || '').toString().trim();
    if (!raw) return '';
    // allow user to type without protocol
    if (/^https?:\/\//i.test(raw)) return raw;
    return `https://${raw}`;
  }

  function isReasonableUrl(x) {
    try {
      const u = new URL(x);
      return ['http:', 'https:'].includes(u.protocol);
    } catch {
      return false;
    }
  }

  async function finishOnboarding() {
    if (!currentWallet) return;

    if (!obRole) return alert('Please select a role.');

    const usernameRaw = obUsername?.value || '';
    const username = normalizeUsernameClient(usernameRaw);
    if (!isValidUsernameClient(username)) {
      return alert('Username must be at least 4 characters and only a-z0-9.');
    }

    const bio = (obBio?.value || '').toString();

    let link = normalizeLinkClient(obLink?.value || '');
    if (link && !isReasonableUrl(link)) {
      if (obLinkHint) obLinkHint.textContent = 'Invalid link. Example: https://github.com/you';
      return alert('Link is invalid.');
    }
    const socials = link ? [link] : [];

    try {
      if (obFinishBtn) {
        obFinishBtn.disabled = true;
        obFinishBtn.textContent = 'Saving...';
      }

      // 1) Create profile + set role
      try {
        await fetch(`${API_URL}/api/set-role`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ wallet: currentWallet, role: obRole })
        });
      } catch {
        // offline mode
      }

      // 2) Update username/bio/link
      try {
        const res = await fetch(`${API_URL}/api/update-profile`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ wallet: currentWallet, username, bio, socials })
        });
        const out = await res.json().catch(() => null);
        if (out && out.success === false) throw new Error(out.message || 'Profile save failed');
      } catch (e) {
        console.log('Profile save failed (server offline):', e);
      }

      const doneKey = `onboarding_done_${String(currentWallet || '').toLowerCase()}`;
      localStorage.setItem(doneKey, '1');

      if (obFinalLine) obFinalLine.style.display = 'flex';

      // small delay for UX, then redirect
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 600);
    } catch (err) {
      console.error(err);
      alert(err?.message || 'Onboarding failed');
    } finally {
      if (obFinishBtn) {
        obFinishBtn.disabled = false;
        obFinishBtn.textContent = 'Finish';
      }
    }
  }

  async function checkUserProfileBackground(wallet) {
    try {
      const res = await fetch(`${API_URL}/api/profile/${wallet}`, { cache: 'no-store' });
      const data = await res.json().catch(() => null);
      if (data && data.success) console.log("Profile Synced:", data.user?.role);
    } catch (err) {
      console.log("Profile Sync Failed (Offline Mode)");
    }
  }

  // ---------------- Stats (Blockchain) ----------------
  async function fetchPlatformStats() {
    const statProjects = document.getElementById('stat-projects');
    const statCompanies = document.getElementById('stat-companies'); // در UI می‌تونه Premium Members نمایش داده بشه

    // اگر المان‌های آمار در صفحه نبودند یا ولت نبود، اجرا نکن
    if (!statProjects || !window.ethereum) return;

    try {
      const readProvider = new ethers.providers.Web3Provider(window.ethereum);

      const ABI_STATS = [
        "function getPlatformStats() external view returns (uint256 totalProjects, uint256 registeredCompanies)"
      ];

      const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI_STATS, readProvider);
      const stats = await contract.getPlatformStats();

      if (statProjects) statProjects.innerText = stats.totalProjects.toString();
      if (statCompanies) statCompanies.innerText = stats.registeredCompanies.toString();
    } catch (e) {
      console.log("Stats fetch error (minor):", e);
    }
  }

  // ---------------- Wallet Connect ----------------
  async function connectToProvider(ethProvider) {
    try {
      if (connectBtn) connectBtn.innerText = "Requesting...";

      provider = new ethers.providers.Web3Provider(ethProvider);
      const accounts = await provider.send("eth_requestAccounts", []);

      if (!accounts || accounts.length === 0) throw new Error("No accounts");
      currentWallet = accounts[0];
      signer = provider.getSigner();

      console.log(`✅ Connected: ${currentWallet}`);

      if (walletModal) walletModal.classList.remove('active');
      loginSuccess(currentWallet);

      processLoginBackground(currentWallet);
      fetchPlatformStats();
      setupAccountListener(ethProvider);
    } catch (err) {
      console.error(err);
      resetButton();
    }
  }

  function setupAccountListener(ethProvider) {
  try {
    if (!ethProvider || !ethProvider.on) return;

    // اگر قبلاً لیسنر ست شده، دوباره ست نکن (جلوی چندبار اجرا شدن را هم می‌گیرد)
    if (ethProvider.__krylsAccountsListenerAttached) return;
    ethProvider.__krylsAccountsListenerAttached = true;

    ethProvider.on('accountsChanged', async (accounts) => {
      try {
        const next = (accounts && accounts.length > 0) ? accounts[0] : "";

        // disconnected
        if (!next) {
          disconnectWallet();
          return;
        }

        // ✅ اگر همان آدرس قبلی است، هیچ کاری نکن (از فلش/پرش جلوگیری می‌کند)
        if (String(next).toLowerCase() === String(currentWallet).toLowerCase()) {
          return;
        }

        console.log("Account Changed:", next);
        currentWallet = next;
        localStorage.setItem('userWallet', currentWallet);

        // ✅ به جای reload فقط UI را آپدیت کن
        loginSuccess(currentWallet);

        // sync با بک‌اند (اختیاری)
        processLoginBackground(currentWallet);
        checkUserProfileBackground(currentWallet);

      } catch (e) {
        console.warn("accountsChanged handler failed:", e);
      }
    });
  } catch (e) {
    // ignore
  }
}


  // ---------------- Role Selection (Company removed) ----------------
  async function setUserRole(role) {
    const r = (role || '').toString().toLowerCase();
    if (!['client', 'freelancer'].includes(r)) {
      alert("Invalid role");
      return;
    }

    if (roleModal) roleModal.classList.remove('active');
    alert(`🎉 Welcome! You are now a ${r.toUpperCase()}.`);

    try {
      await fetch(`${API_URL}/api/set-role`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wallet: currentWallet, role: r })
      });
    } catch (err) {
      console.log("Role saved locally only (Server offline)");
    }

    if (r === 'freelancer') window.location.href = "market.html";
    else window.location.href = "dashboard.html";
  }

  // ---------------- Persistence (Auto UI restore) ----------------
  const storedWallet = localStorage.getItem('userWallet');
  if (storedWallet) {
    loginSuccess(storedWallet);

    const savedProviderType = localStorage.getItem('walletProvider');
    let ethProvider = window.ethereum;

    if (savedProviderType === 'trust') {
      if (window.trustwallet) ethProvider = window.trustwallet;
      else if (window.ethereum?.providers) {
        ethProvider = window.ethereum.providers.find(p => p.isTrust) || window.ethereum;
      }
    }

    if (ethProvider && window.ethers) {
      try {
        provider = new ethers.providers.Web3Provider(ethProvider);
        signer = provider.getSigner();
      } catch {}
    }

    checkUserProfileBackground(storedWallet);

    // restore Terms modal if a refresh/navigation happened while it was pending
    const doneKey = obDoneKey(storedWallet);
    const pendingKey = termsPendingKey(storedWallet);
    const isDoneLocal = localStorage.getItem(doneKey) === '1';
    const isPending = localStorage.getItem(pendingKey) === '1';
    if (!isDoneLocal && isPending && termsModal) {
      if (acceptTermsCheckbox) acceptTermsCheckbox.checked = false;
      if (acceptTermsBtn) {
        acceptTermsBtn.disabled = true;
        acceptTermsBtn.style.opacity = '0.55';
        acceptTermsBtn.style.cursor = 'not-allowed';
      }
      hideModal(walletModal);
      showModal(termsModal);
    }
  }

  // load stats on page load
  fetchPlatformStats();

  // ---------------- UI: Modals ----------------
  if (connectBtn) {
    connectBtn.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}

      if (!isConnected) {
        if (walletModal) walletModal.classList.add('active');
      } else {
        disconnectWallet();
      }
    });
  }

  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}

      if (walletModal) walletModal.classList.remove('active');
    });

    window.addEventListener('click', (e) => {
      if (e.target === walletModal) walletModal.classList.remove('active');
    });
  }

  if (heroPostJobBtn) {
    heroPostJobBtn.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}

      if (!isConnected) {
        if (walletModal) walletModal.classList.add('active');
      } else {
        window.location.href = "dashboard.html";
      }
    });
  }

  // ---------------- Wallet Buttons ----------------
  if (btnMetaMask) {
    btnMetaMask.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}

      if (isMobile && !window.ethereum) {
        window.location.href = `https://metamask.app.link/dapp/${currentUrl}`;
        return;
      }

      localStorage.setItem('walletProvider', 'metamask');

      let ethProvider = null;
      if (window.ethereum?.providers) {
        ethProvider = window.ethereum.providers.find(p => p.isMetaMask && !p.isTrust);
      } else if (window.ethereum?.isMetaMask && !window.ethereum.isTrust) {
        ethProvider = window.ethereum;
      }
      if (!ethProvider && window.ethereum) ethProvider = window.ethereum;

      if (ethProvider) {
        connectToProvider(ethProvider);
      } else {
        alert("❌ MetaMask not installed!");
        window.open("https://metamask.io/download/", "_blank");
      }
    });
  }

  if (btnTrust) {
    btnTrust.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}

      localStorage.setItem('walletProvider', 'trust');

      let trustProvider = null;
      if (window.trustwallet) trustProvider = window.trustwallet;
      else if (window.ethereum?.providers) trustProvider = window.ethereum.providers.find(p => p.isTrust);
      else if (window.ethereum?.isTrust) trustProvider = window.ethereum;

      if (trustProvider) {
        connectToProvider(trustProvider);
      } else {
        if (isMobile) {
          window.location.href =
            `https://link.trustwallet.com/open_url?coin_id=60&url=https://${currentUrl}`;
        } else {
          alert("❌ Trust Wallet not found!");
          window.open("https://trustwallet.com/browser-extension", "_blank");
        }
      }
    });
  }

  // ---------------- Terms / Onboarding Flow ----------------
  if (acceptTermsCheckbox) {
    acceptTermsCheckbox.addEventListener('change', () => {
      const ok = !!acceptTermsCheckbox.checked;
      if (acceptTermsBtn) {
        acceptTermsBtn.disabled = !ok;
        acceptTermsBtn.style.opacity = ok ? '1' : '0.55';
        acceptTermsBtn.style.cursor = ok ? 'pointer' : 'not-allowed';
      }
    });
  }

  if (closeTermsModalBtn) {
    closeTermsModalBtn.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}
      try {
        if (currentWallet) localStorage.removeItem(termsPendingKey(currentWallet));
      } catch {}
      hideModal(termsModal);
      // اگر کاربر Terms را بست، اتصال را هم قطع کن تا دوباره فوراً Terms بالا نیاید
      disconnectWallet();
    });
  }

  if (acceptTermsBtn) {
    acceptTermsBtn.addEventListener('click', (e) => {
      try { e.preventDefault(); e.stopPropagation(); } catch {}
      try {
        if (currentWallet) localStorage.removeItem(termsPendingKey(currentWallet));
      } catch {}
      hideModal(termsModal);
      openOnboarding();
    });
  }

  if (onboardingCloseBtn) onboardingCloseBtn.addEventListener('click', (e) => { try { e.preventDefault(); e.stopPropagation(); } catch {} closeOnboarding(); });

  if (obRoleFreelancer) obRoleFreelancer.addEventListener('click', () => markObRole('freelancer'));
  if (obRoleClient) obRoleClient.addEventListener('click', () => markObRole('client'));

  if (obBackBtn) {
    obBackBtn.addEventListener('click', () => showObStep(obStep - 1));
  }

  if (obNextBtn) {
    obNextBtn.addEventListener('click', () => {
      if (obStep === 1 && !obRole) return alert('Please select a role.');
      showObStep(obStep + 1);
    });
  }

  if (obFinishBtn) {
    obFinishBtn.addEventListener('click', finishOnboarding);
  }

  // Legacy role modal (kept for compatibility) - hide if onboarding is used
  if (btnFreelancer) btnFreelancer.addEventListener('click', () => setUserRole('freelancer'));
  if (btnClient) btnClient.addEventListener('click', () => setUserRole('client'));

  // ---------------- Swap Demo ----------------
  if (swapBtn) {
    swapBtn.onclick = () => {
      if (!isConnected && !localStorage.getItem('userWallet')) {
        if (walletModal) walletModal.classList.add('active');
        return;
      }

      const amount = Number(swapAmountFrom?.value || 0);
      if (!amount || amount <= 0) return alert("Please enter an amount!");

      const originalText = swapBtn.innerText;
      swapBtn.innerText = "Swapping...";

      setTimeout(() => {
        if (swapAmountTo) swapAmountTo.value = (amount * 3200).toFixed(2);
        alert(`✅ Swapped ${amount} ETH to USDT!`);
        swapBtn.innerText = originalText;
      }, 1000);
    };
  }

  // ---------------- Neon background glow ----------------
  document.addEventListener('mousemove', (e) => {
    const glow = document.querySelector('.bg-glow');
    if (glow) {
      glow.style.transform = `translate(-${e.clientX / 50}px, -${e.clientY / 50}px)`;
    }
  });
});
