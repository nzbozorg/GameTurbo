(() => {
const API = `http://${window.location.hostname}:5000`;
const $ = (id) => document.getElementById(id);

// Kryls Premium (Added): hide legacy company role from admin UI
function hideCompanyRoleOptions() {
    try {
        const rf = $("roleFilter");
        if (rf) Array.from(rf.querySelectorAll("option")).forEach((o) => {
            if ((o.value || "").toLowerCase() === "company") o.remove();
        });
        const er = $("editRole");
        if (er) Array.from(er.querySelectorAll("option")).forEach((o) => {
            if ((o.value || "").toLowerCase() === "company") o.remove();
        });
    } catch {}
}

// UI (top/actions)
const refreshBtn = $("refreshBtn");
const pauseLogsBtn = $("pauseLogsBtn");
const exportBtn = $("exportBtn");
const serverStatus = $("serverStatus");

// Filters
const q = $("q");
const roleFilter = $("roleFilter");
const logType = $("logType");
const projectIdFilter = $("projectIdFilter");
const clearSearchBtn = $("clearSearchBtn");
const clearLogViewBtn = $("clearLogViewBtn");

// Tabs
const tabBtns = Array.from(document.querySelectorAll(".tab[data-tab]"));

// Data Panel
const panelTitle = $("panelTitle");
const panelSub = $("panelSub");
const tableHead = $("tableHead");
const tableBody = $("tableBody");
const tableCount = $("tableCount");
const mobileList = $("mobileList");

// Logs
const logsBox = $("logsBox");

// Modal editor (users only)
const drawerOverlay = $("drawerOverlay");
const closeDrawerBtn = $("closeDrawerBtn");
const drawerMeta = $("drawerMeta");
const editWallet = $("editWallet");
const editRole = $("editRole");
const editUsername = $("editUsername");
const editBio = $("editBio");
const editSocials = $("editSocials");
const editPremiumActive = $("editPremiumActive");
const saveUserBtn = $("saveUserBtn");
const resetFormBtn = $("resetFormBtn");
const saveHint = $("saveHint");

// E2EE Decrypt Tools
const decryptTools = $("decryptTools");

// State
let activeTab = "users";
let selectedWallet = "";
let logsPaused = false;

hideCompanyRoleOptions();

const cache = {
    users: [],
    projects: [],
    requests: [],
    messages: [],
    logs: [],
};

// ---------- Helpers ----------
function esc(s) {
    return String(s ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function shortAddr(a) {
    a = String(a || "");
    if (a.length < 12) return a;
    return `${a.slice(0, 6)}...${a.slice(-4)}`;
}

function isHexTx(x) {
    return typeof x === "string" && x.startsWith("0x") && x.length >= 10;
}

// -------------------- E2EE Admin Decrypt Tools --------------------
function b64ToU8(b64) {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
}

function u8ToB64(u8) {
    const bin = String.fromCharCode.apply(null, u8);
    return btoa(bin);
}

// ✅ تصحیح: فاصله اضافه حذف شد (strFro mU8 → strFromU8)
function strFromU8(u8) {
    return new TextDecoder().decode(u8);
}

async function importAesKey(raw32) {
    return crypto.subtle.importKey(
        "raw",
        raw32,
        { name: "AES-GCM" },
        false,
        ["decrypt"]
    );
}

async function decryptSealedMessageV2(aesKey, sealed) {
    const iv = b64ToU8(sealed.iv);
    const ct = b64ToU8(sealed.ct);
    const aad = b64ToU8(sealed.aad);
    
    const ptBuf = await crypto.subtle.decrypt(
        {
            name: "AES-GCM",
            iv,
            additionalData: aad,
            tagLength: 128
        },
        aesKey,
        ct
    );

    return strFromU8(new Uint8Array(ptBuf));
}

function mountDecryptTools() {
    if (!decryptTools) return;
    
    decryptTools.innerHTML = `
        <div class="card-sub">E2EE Decrypt (Admin) - client-side</div>
        <div style="display:grid; gap:10px; margin-top:10px">
            <input id="decProjectId" placeholder="ProjectId (e.g. proj_...)" />
            <textarea id="decPub" class="mono" rows="2" placeholder="Recovery public key (base64)"></textarea>
            <textarea id="decPriv" class="mono" rows="3" placeholder="Recovery private key (base64)"></textarea>
            <div style="display:flex; gap:8px; flex-wrap:wrap">
                <button class="btn" type="button" id="decGen">Generate keypair</button>
                <button class="btn primary" type="button" id="decSaveAdminPub">Save Admin pubkey to server</button>
                <button class="btn primary" type="button" id="decRun">Decrypt cached messages for project</button>
            </div>
            <div class="card-sub" id="decHint"></div>
        </div>
    `;

    const decHint = $("decHint");

    $("decGen").onclick = async () => {
        try {
            const keyPair = await crypto.subtle.generateKey(
                {
                    name: "RSA-OAEP",
                    modulusLength: 2048,
                    publicExponent: new Uint8Array([1, 0, 1]),
                    hash: "SHA-256"
                },
                true,
                ["wrapKey", "unwrapKey"]
            );
            
            const pubSpki = await crypto.subtle.exportKey("spki", keyPair.publicKey);
            const privPkcs8 = await crypto.subtle.exportKey("pkcs8", keyPair.privateKey);
            
            $("decPub").value = u8ToB64(new Uint8Array(pubSpki));
            $("decPriv").value = u8ToB64(new Uint8Array(privPkcs8));
            
            decHint.textContent = "Generated. Store private key securely.";
        } catch (e) {
            decHint.textContent = e?.message || "Generate failed";
        }
    };

    $("decSaveAdminPub").onclick = async () => {
        try {
            const pub = ($("decPub").value || "").trim();
            const res = await apiPost("/api/keys/admin-pubkey", { adminPubKeyB64: pub });
            if (!res?.success) throw new Error(res?.message || "Save failed");
            decHint.textContent = "✅ Admin pubkey saved on server.";
        } catch (e) {
            decHint.textContent = "❌ " + (e?.message || "Save failed");
        }
    };

    $("decRun").onclick = async () => {
    try {
        const projectId = ($("decProjectId").value || "").trim();
        const privB64 = ($("decPriv").value || "").trim();

        if (!projectId) throw new Error("Missing projectId");
        if (!privB64) throw new Error("Missing recovery private key (PKCS8 base64)");

        const k = await apiGet(`/api/keys/get/${encodeURIComponent(projectId)}`);
        const rec = k?.data;
        if (!rec) throw new Error("❌ No key record for this projectId");

        // candidates: admin + all oracles
        const candidates = [];
        if (rec.wrappedForAdmin) candidates.push({ label: "admin", wrapped: rec.wrappedForAdmin });
        if (rec.wrappedForOracles && typeof rec.wrappedForOracles === "object") {
            for (const [w, v] of Object.entries(rec.wrappedForOracles)) {
                if (!v) continue;
                candidates.push({ label: `oracle:${String(w).toLowerCase()}`, wrapped: v });
            }
        }

        if (!candidates.length) throw new Error("❌ No wrapped keys stored for this project");

        const privKey = await crypto.subtle.importKey(
            "pkcs8",
            b64ToU8(privB64),
            { name: "RSA-OAEP", hash: "SHA-256" },
            true,
            ["unwrapKey"]
        );

        let aesKey = null;
        let used = null;

        for (const c of candidates) {
            try {
                aesKey = await crypto.subtle.unwrapKey(
                    "raw",
                    b64ToU8(c.wrapped),
                    privKey,
                    { name: "RSA-OAEP", hash: "SHA-256" },
                    { name: "AES-GCM", length: 256 },
                    true,
                    ["decrypt"]
                );
                used = c.label;
                break;
            } catch (e) {
                // try next
            }
        }

        if (!aesKey) throw new Error("❌ Private key does not match admin/oracle wrapped keys for this project");

        let ok = 0, fail = 0;
        for (const m of cache.messages) {
            if (String(m.projectId) !== String(projectId)) continue;
            if (!m.isEncrypted) continue;
            if (!m.sealed) continue;

            try {
                const decrypted = await decryptSealedMessageV2(aesKey, m.sealed);
                m.text = decrypted;
                m.__decrypted = true;
                ok++;
            } catch (e) {
                fail++;
            }
        }

        renderActive();
        openChatPopup(projectId);
        $("decHint").textContent = `✅ Decrypted: ${ok} | Failed: ${fail} | Used: ${used}`;
    } catch (e) {
        $("decHint").textContent = "❌ " + (e?.message || "Decrypt failed");
    }
};
}

function setStatusLive(ok) {
    if (!serverStatus) return;
    serverStatus.textContent = ok ? "LIVE" : "OFFLINE";
    serverStatus.classList.remove("ok", "bad", "warn");
    serverStatus.classList.add(ok ? "ok" : "bad");
}

async function apiGet(path) {
    const r = await fetch(`${API}${path}`, { cache: "no-store" });
    if (r.status === 401) throw new Error("Unauthorized (Admin password wrong)");
    return r.json().catch(() => ({}));
}

async function apiPost(path, body) {
    const r = await fetch(`${API}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {}),
    });
    if (r.status === 401) throw new Error("Unauthorized (Admin password wrong)");
    return r.json().catch(() => ({}));
}

function openModal() {
    drawerOverlay.classList.add("open");
}

function closeModal() {
    drawerOverlay.classList.remove("open");
}

function setTab(tab) {
    activeTab = tab;
    
    if (decryptTools) {
        decryptTools.style.display = tab === "messages" ? "block" : "none";
        if (tab === "messages") {
            try { mountDecryptTools(); } catch {}
        }
    }

    tabBtns.forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));

    const titles = {
        users: ["Users", "روی یک کاربر کلیک کن تا ویرایش باز شود."],
        projects: ["Projects", "لیست پروژه‌ها و وضعیت‌ها."],
        requests: ["Requests", "درخواست‌های فریلنسرها برای پروژه‌ها."],
        messages: ["Messages", "آخرین پیام‌ها (نمایش محدود)."],
        logs: ["Logs", "لاگ‌ها در کارت سمت راست نمایش داده می‌شوند."],
    };

    panelTitle.textContent = titles[tab]?.[0] || "Data";
    panelSub.textContent = titles[tab]?.[1] || "";

    renderActive();
}

function applyUserFilters(list) {
    const query = (q.value || "").trim().toLowerCase();
    const rf = (roleFilter.value || "").trim().toLowerCase();
    return list.filter((x) => {
        const okRole = rf ? String(x.role || "").toLowerCase() === rf : true;
        if (!query) return okRole;
        const hay = JSON.stringify(x).toLowerCase();
        return okRole && hay.includes(query);
    });
}

function applyGenericSearch(list) {
    const query = (q.value || "").trim().toLowerCase();
    if (!query) return list;
    return list.filter((x) => JSON.stringify(x).toLowerCase().includes(query));
}

// ---------- Modal / User edit ----------
function loadUserToForm(wallet) {
    const u = cache.users.find((x) => String(x.wallet).toLowerCase() === String(wallet).toLowerCase());
    if (!u) return;
    selectedWallet = u.wallet;
    drawerMeta.textContent = `Wallet: ${shortAddr(u.wallet)} • Role: ${u.role || '"-"'}`;
    editWallet.value = u.wallet;
    editRole.value = u.role || "freelancer";
    editUsername.value = u.username || "";
    editBio.value = u.bio || "";
    if (editPremiumActive) editPremiumActive.value = u.premiumActive ? "true" : "false";
    try {
        editSocials.value = JSON.stringify(u.socials || [], null, 2);
    } catch {
        editSocials.value = "[]";
    }
    saveHint.textContent = "";
    saveHint.className = "card-sub";
    openModal();
}

function resetForm() {
    if (!selectedWallet) return;
    loadUserToForm(selectedWallet);
}

function parseSocialsOrThrow(raw) {
    const txt = (raw || "").trim();
    if (!txt) return [];
    const parsed = JSON.parse(txt);
    if (!Array.isArray(parsed)) throw new Error("NOT_ARRAY");
    return parsed;
}

// ---------- Renderers ----------
function setTableColumns(cols) {
    tableHead.innerHTML = `<tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr>`;
}

function setCount(n, label) {
    tableCount.textContent = `${n} ${label}`;
}

function renderUsers() {
    const rows = applyUserFilters(cache.users);
    setTableColumns(["Wallet", "Role", "Username", "Premium", "Joined", "Actions"]);
    tableBody.innerHTML = rows.map((u) => {
        const isPrem = !!u.premiumActive;
        return `
            <tr data-wallet="${esc(u.wallet)}">
                <td class="mono">${esc(shortAddr(u.wallet))}</td>
                <td><span class="pill">${esc(u.role || "")}</span></td>
                <td>${esc(u.username || "")}</td>
                <td>${isPrem ? `<span class="pill ok">ACTIVE</span>` : `<span class="pill bad">INACTIVE</span>`}</td>
                <td class="mono">${esc((u.joinedAt || "").toString().slice(0, 19).replace("T", " "))}</td>
                <td>
                    <div class="row-actions">
                        <button type="button" class="btn" data-edit="${esc(u.wallet)}">Edit</button>
                    </div>
                </td>
            </tr>
        `;
    }).join("");

    tableBody.querySelectorAll("tr[data-wallet]").forEach((tr) => {
        tr.addEventListener("click", () => loadUserToForm(tr.getAttribute("data-wallet")));
    });

    tableBody.querySelectorAll("button[data-edit]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            loadUserToForm(btn.getAttribute("data-edit"));
        });
    });

    mobileList.innerHTML = rows.map((u) => {
        const isPrem = !!u.premiumActive;
        return `
            <div class="row" data-wallet="${esc(u.wallet)}">
                <div class="row-top">
                    <div class="row-title">${esc(u.username || "—")}</div>
                    <span class="pill ${isPrem ? "ok" : "bad"}">${isPrem ? "PREMIUM" : "FREE"}</span>
                </div>
                <div class="row-meta">
                    <span class="pill">${esc(u.role || "-")}</span>
                    <span class="mono">${esc(shortAddr(u.wallet))}</span>
                </div>
                <div class="row-actions">
                    <button type="button" class="btn" data-edit="${esc(u.wallet)}">Edit</button>
                </div>
            </div>
        `;
    }).join("");

    mobileList.querySelectorAll("[data-wallet]").forEach((el) => {
        el.addEventListener("click", () => loadUserToForm(el.getAttribute("data-wallet")));
    });

    mobileList.querySelectorAll("button[data-edit]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            loadUserToForm(btn.getAttribute("data-edit"));
        });
    });

    setCount(rows.length, "users");
}

function renderProjects() {
    const rows = applyGenericSearch(cache.projects);
    setTableColumns(["ProjectId", "Owner", "Status", "Budget", "Assigned", "Tx", "Created"]);
    tableBody.innerHTML = rows.map((p) => {
        const st = (p.status || "").toString();
        const stPill =
            st === "Open" ? `<span class="pill ok">Open</span>` :
            st === "In Progress" ? `<span class="pill warn">In Progress</span>` :
            `<span class="pill">${esc(st)}</span>`;
        
        return `
            <tr>
                <td class="mono">${esc(p.id || "")}</td>
                <td class="mono">${esc(shortAddr(p.owner || ""))}</td>
                <td>${stPill}</td>
                <td>${esc(p.budget || "")} <span class="mono">${esc(p.tokenSymbol || "")}</span></td>
                <td class="mono">${esc(p.assignedFreelancer ? shortAddr(p.assignedFreelancer) : "-")}</td>
                <td class="mono">${esc(p.txHash ? shortAddr(p.txHash) : "-")}</td>
                <td class="mono">${esc((p.createdAt || "").toString().slice(0, 19).replace("T", " "))}</td>
            </tr>
        `;
    }).join("");

    mobileList.innerHTML = rows.map((p) => {
        const st = (p.status || "").toString();
        const cls = st === "Open" ? "ok" : (st === "In Progress" ? "warn" : "");
        return `
            <div class="row">
                <div class="row-top">
                    <div class="row-title">Project #${esc(p.id || "")}</div>
                    <span class="pill ${cls}">${esc(st || "-")}</span>
                </div>
                <div class="row-meta">
                    <span class="mono">Owner: ${esc(shortAddr(p.owner || ""))}</span>
                    <span class="mono">Budget: ${esc(p.budget || "")} ${esc(p.tokenSymbol || "")}</span>
                </div>
                <div class="row-meta">
                    <span class="mono">Assigned: ${esc(p.assignedFreelancer ? shortAddr(p.assignedFreelancer) : "-")}</span>
                    <span class="mono">Tx: ${esc(p.txHash ? shortAddr(p.txHash) : "-")}</span>
                </div>
            </div>
        `;
    }).join("");

    setCount(rows.length, "projects");
}

function renderRequests() {
    const rows = applyGenericSearch(cache.requests);
    setTableColumns(["RequestId", "ProjectId", "Owner", "Freelancer", "Status", "Created", "Updated"]);
    tableBody.innerHTML = rows.map((r) => {
        const st = (r.status || "").toString();
        const stPill =
            st === "Pending" ? `<span class="pill warn">Pending</span>` :
            st === "Approved" ? `<span class="pill ok">Approved</span>` :
            st === "Rejected" ? `<span class="pill bad">Rejected</span>` :
            `<span class="pill">${esc(st)}</span>`;
        
        return `
            <tr>
                <td class="mono">${esc(r.id || "")}</td>
                <td class="mono">${esc(r.projectId || "")}</td>
                <td class="mono">${esc(shortAddr(r.owner || ""))}</td>
                <td class="mono">${esc(shortAddr(r.freelancer || ""))}</td>
                <td>${stPill}</td>
                <td class="mono">${esc((r.createdAt || "").toString().slice(0, 19).replace("T", " "))}</td>
                <td class="mono">${esc((r.updatedAt || "").toString().slice(0, 19).replace("T", " "))}</td>
            </tr>
        `;
    }).join("");

    mobileList.innerHTML = rows.map((r) => {
        const st = (r.status || "").toString();
        const cls = st === "Approved" ? "ok" : (st === "Pending" ? "warn" : (st === "Rejected" ? "bad" : ""));
        return `
            <div class="row">
                <div class="row-top">
                    <div class="row-title">Req #${esc(r.id || "")} • Project ${esc(r.projectId || "")}</div>
                    <span class="pill ${cls}">${esc(st || "-")}</span>
                </div>
                <div class="row-meta">
                    <span class="mono">Owner: ${esc(shortAddr(r.owner || ""))}</span>
                    <span class="mono">Freelancer: ${esc(shortAddr(r.freelancer || ""))}</span>
                </div>
                <div class="row-meta">
                    <span class="mono">Created: ${esc((r.createdAt || "").toString().slice(0,19).replace("T", " "))}</span>
                </div>
            </div>
        `;
    }).join("");

    setCount(rows.length, "requests");
}

function renderMessages() {
    const rows = applyGenericSearch(cache.messages).slice(0, 500);
    setTableColumns(["Time", "ProjectId", "From", "To", "Type", "Text"]);
    tableBody.innerHTML = rows.map((m) => `
        <tr>
            <td class="mono">${esc((m.timestamp || "").toString().slice(0, 19).replace("T", " "))}</td>
            <td class="mono">${esc(m.projectId || "")}</td>
            <td class="mono">${esc(shortAddr(m.sender || ""))}</td>
            <td class="mono">${esc(shortAddr(m.receiver || ""))}</td>
            <td><span class="pill">${esc(m.type || "")}</span></td>
            <td>
                ${m.__decrypted ? '🔓 ' : ''}
                ${m.isEncrypted ? '🔒 ' : ''}
                ${esc((m.text || "").toString().slice(0, 160))}
            </td>
        </tr>
    `).join("");

    mobileList.innerHTML = rows.map((m) => `
        <div class="row">
            <div class="row-top">
                <div class="row-title">${esc((m.type || "MSG"))} • Project ${esc(m.projectId || "")}</div>
                <span class="pill">${esc((m.timestamp || "").toString().slice(11, 19))}</span>
            </div>
            <div class="row-meta">
                <span class="mono">From: ${esc(shortAddr(m.sender || ""))}</span>
                <span class="mono">To: ${esc(shortAddr(m.receiver || ""))}</span>
            </div>
            <div class="row-meta">
                ${m.__decrypted ? '🔓 ' : ''}
                ${m.isEncrypted ? '🔒 ' : ''}
                ${esc((m.text || "").toString().slice(0, 180))}
            </div>
        </div>
    `).join("");

    setCount(rows.length, "messages (max 500)");
}

function renderActive() {
    roleFilter.disabled = activeTab !== "users";
    
    if (activeTab === "users") return renderUsers();
    if (activeTab === "projects") return renderProjects();
    if (activeTab === "requests") return renderRequests();
    if (activeTab === "messages") return renderMessages();
    if (activeTab === "logs") {
        setTableColumns(["Logs"]);
        tableBody.innerHTML = `<tr><td style="padding:14px; color: rgba(255,255,255,.62);">Logs are on the right panel.</td></tr>`;
        mobileList.innerHTML = `<div class="row"><div class="row-title">Logs</div><div class="row-meta">لاگ‌ها در کارت سمت راست نمایش داده می‌شوند.</div></div>`;
        tableCount.textContent = "—";
        return;
    }
}

// ---------- Logs ----------
function renderLogs(logs) {
    const typeF = (logType.value || "").trim();
    const pidFilter = (projectIdFilter?.value || "").trim();
    const filtered = (logs || []).filter((x) => {
        const typeOk = typeF ? (String(x.type || "") === typeF) : true;
        
        // ✅ فیلتر دقیق پروژه‌آی‌دی (نه شامل بودن)
        if (pidFilter) {
            const pidFromLog = String(x.projectId || x.meta?.projectId || "").trim();
            return typeOk && (pidFromLog === pidFilter);
        }
        
        return typeOk;
    });

    logsBox.innerHTML = filtered.map((x) => {
        const t = (x.ts || "").toString().replace("T", " ").replace("Z", "");
        const tp = (x.type || "EVENT").toString();
        const actor = x.actor ? shortAddr(x.actor) : "-";
        const meta = x.meta ? JSON.stringify(x.meta, null, 2) : "";
        
        let pillCls = "pill";
        if (tp === "CHAT") pillCls = "pill ok";
        if (tp === "REQUEST") pillCls = "pill warn";
        if (tp === "PROJECT") pillCls = "pill ok";
        if (tp === "PREMIUM") pillCls = "pill ok";
        if (tp === "ADMIN") pillCls = "pill warn";
        
        return `
            <div class="log">
                <div class="log-top">
                    <div class="log-ts">${esc(t)}</div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                        <span class="${pillCls}">${esc(tp)}</span>
                        <span class="pill mono">${esc(actor)}</span>
                    </div>
                </div>
                <div class="log-msg">${esc(x.msg || "")}</div>
                ${meta ? `<div class="log-meta">${esc(meta)}</div>` : ""}
            </div>
        `;
    }).join("");

    logsBox.scrollTop = logsBox.scrollHeight;
}

async function refreshLogs() {
    if (logsPaused) return;
    const res = await apiGet("/api/admin/logs?limit=120");
    if (!res.success) return;
    cache.logs = res.logs || [];
    setStatusLive(true);
    renderLogs(cache.logs);
}

// ---------- Data refresh ----------
async function refreshAll() {
    try {
        setStatusLive(true);
        const [u, p, r, m] = await Promise.all([
            apiGet("/api/admin/users"),
            apiGet("/api/admin/projects"),
            apiGet("/api/admin/requests"),
            apiGet("/api/admin/messages?limit=1200"),
        ]);
        
        cache.users = u.users || [];
        cache.projects = p.projects || [];
        cache.requests = r.requests || [];
        cache.messages = m.messages || [];
        
        renderActive();
    } catch (e) {
        console.error(e);
        setStatusLive(false);
        alert(e.message || "Failed to load admin data");
    }
}

// ---------- Export JSON ----------
function downloadJSON(filename, data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
}

function exportCurrent() {
    const now = new Date().toISOString().replaceAll(":", "-");
    if (activeTab === "users") {
        const rows = applyUserFilters(cache.users);
        return downloadJSON(`admin_users_${now}.json`, rows);
    }

    if (activeTab === "projects") return downloadJSON(`admin_projects_${now}.json`, applyGenericSearch(cache.projects));
    if (activeTab === "requests") return downloadJSON(`admin_requests_${now}.json`, applyGenericSearch(cache.requests));
    if (activeTab === "messages") return downloadJSON(`admin_messages_${now}.json`, applyGenericSearch(cache.messages).slice(0, 1200));
    if (activeTab === "logs") return downloadJSON(`admin_logs_${now}.json`, (cache.logs || []));

    return downloadJSON(`admin_dump_${now}.json`, cache);
}

// ---------- Events wiring ----------
tabBtns.forEach((b) => b.addEventListener("click", () => setTab(b.dataset.tab)));
refreshBtn.addEventListener("click", async () => {
    await refreshAll();
    await refreshLogs();
});
q.addEventListener("input", renderActive);
roleFilter.addEventListener("change", renderActive);
logType.addEventListener("change", () => renderLogs(cache.logs));
projectIdFilter?.addEventListener("input", () => renderLogs(cache.logs));
clearSearchBtn.addEventListener("click", () => {
    q.value = "";
    roleFilter.value = "";
    renderActive();
});
clearLogViewBtn.addEventListener("click", () => {
    logsBox.innerHTML = "";
});
exportBtn.addEventListener("click", exportCurrent);
pauseLogsBtn.addEventListener("click", () => {
    logsPaused = !logsPaused;
    pauseLogsBtn.textContent = logsPaused ? "Resume Logs" : "Pause Logs";
    if (!logsPaused) refreshLogs();
});
closeDrawerBtn.addEventListener("click", closeModal);
drawerOverlay.addEventListener("click", (e) => {
    if (e.target === drawerOverlay) closeModal();
});
window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeModal();
});
resetFormBtn.addEventListener("click", resetForm);
saveUserBtn.addEventListener("click", async () => {
    if (!selectedWallet) return alert("اول یک کاربر را انتخاب کن.");
    let socials = [];
    try {
        socials = parseSocialsOrThrow(editSocials.value);
    } catch {
        saveHint.textContent = "❌ Socials باید JSON Array باشد. اگر نیاز نداری، خالی بگذار یا بنویس: []";
        saveHint.className = "hint-bad";
        editSocials.focus();
        return;
    }

    const payload = {
        wallet: selectedWallet,
        role: editRole.value,
        username: editUsername.value, 
        bio: editBio.value,
        socials,
        premiumActive: (editPremiumActive && editPremiumActive.value === "true"),
    };

    const res = await apiPost("/api/admin/users/update", payload);
    if (!res.success) {
        saveHint.textContent = res.message || "Save failed";
        saveHint.className = "hint-bad";
        return;
    }

    saveHint.textContent = "✅ Saved successfully.";
    saveHint.className = "hint-ok";
    await refreshAll();
});


// ---------- Decrypted Chat Popup ----------
let chatPopup = null;

function ensureChatPopup() {
    if (chatPopup) return;

    const style = document.createElement("style");
    style.textContent = `
    .chat-overlay{position:fixed; inset:0; background:rgba(0,0,0,.62); display:none; align-items:center; justify-content:center; z-index:9999;}
    .chat-overlay.open{display:flex;}
    .chat-modal{width:min(980px, 94vw); height:min(78vh, 760px); background:rgba(18,18,22,.98); border:1px solid rgba(255,255,255,.14); border-radius:16px; box-shadow:0 24px 80px rgba(0,0,0,.55); overflow:hidden; display:flex; flex-direction:column;}
    .chat-head{padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.10); display:flex; align-items:center; justify-content:space-between; gap:10px;}
    .chat-title{font-weight:700; font-size:14px; color:rgba(255,255,255,.92); display:flex; align-items:center; gap:10px;}
    .chat-sub{font-size:12px; color:rgba(255,255,255,.56);}
    .chat-actions{display:flex; gap:8px; align-items:center;}
    .chat-actions .btn{padding:8px 10px; border-radius:10px;}
    .chat-body{flex:1; overflow:auto; padding:14px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.01));}
    .bubble-row{display:flex; margin:8px 0;}
    .bubble{max-width:min(72%, 720px); padding:10px 12px; border-radius:14px; border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.06); color:rgba(255,255,255,.92); white-space:pre-wrap; word-break:break-word;}
    .bubble.me{background:rgba(79, 160, 255, .16); border-color:rgba(79, 160, 255, .28);}
    .meta{margin-top:6px; font-size:11px; color:rgba(255,255,255,.55); display:flex; gap:10px; align-items:center;}
    .tag{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; font-size:11px; padding:2px 6px; border-radius:999px; border:1px solid rgba(255,255,255,.14); color:rgba(255,255,255,.68);}
    .chat-foot{padding:10px 14px; border-top:1px solid rgba(255,255,255,.10); display:flex; gap:10px; align-items:center; justify-content:space-between;}
    .chat-foot .hint{font-size:12px; color:rgba(255,255,255,.6);}
    `;
    document.head.appendChild(style);

    const overlay = document.createElement("div");
    overlay.className = "chat-overlay";
    overlay.id = "chatOverlay";
    overlay.innerHTML = `
      <div class="chat-modal" role="dialog" aria-modal="true" aria-label="Decrypted chat">
        <div class="chat-head">
          <div>
            <div class="chat-title">🔓 Decrypted chat <span class="tag" id="chatPopupProjectTag"></span></div>
            <div class="chat-sub" id="chatPopupSub">—</div>
          </div>
          <div class="chat-actions">
            <button class="btn" type="button" id="chatCopyBtn">Copy text</button>
            <button class="btn primary" type="button" id="chatCloseBtn">Close</button>
          </div>
        </div>
        <div class="chat-body" id="chatPopupBody"></div>
        <div class="chat-foot">
          <div class="hint" id="chatPopupHint">Only decrypted messages are shown.</div>
          <div class="hint" id="chatPopupCount">—</div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    const close = () => closeChatPopup();
    overlay.addEventListener("click", (e) => {
        if (e.target === overlay) close();
    });
    overlay.querySelector("#chatCloseBtn").addEventListener("click", close);
    overlay.querySelector("#chatCopyBtn").addEventListener("click", () => copyChatText());

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") close();
    });

    chatPopup = overlay;
}

function closeChatPopup() {
    if (!chatPopup) return;
    chatPopup.classList.remove("open");
}

function openChatPopup(projectId) {
    ensureChatPopup();
    renderChatPopup(projectId);
    chatPopup.classList.add("open");
}

function renderChatPopup(projectId) {
    const pid = String(projectId || "").trim();
    if (!pid) return;

    const body = document.getElementById("chatPopupBody");
    const tag = document.getElementById("chatPopupProjectTag");
    const sub = document.getElementById("chatPopupSub");
    const count = document.getElementById("chatPopupCount");

    tag.textContent = `Project ${pid}`;

    const msgs = (cache.messages || [])
        .filter((m) => String(m.projectId) === pid)
        .filter((m) => m.__decrypted || !m.isEncrypted) // show plaintext + decrypted
        .sort((a,b) => String(a.timestamp||"").localeCompare(String(b.timestamp||"")));

    // Determine two main participants for alignment
    const participants = [];
    for (const m of msgs) {
        const s = String(m.sender || "").toLowerCase();
        const r = String(m.receiver || "").toLowerCase();
        if (s && !participants.includes(s)) participants.push(s);
        if (r && !participants.includes(r)) participants.push(r);
        if (participants.length >= 2) break;
    }
    const left = participants[0] || "";
    const right = participants[1] || "";

    sub.textContent = participants.length
        ? `Left: ${shortAddr(left)}  •  Right: ${shortAddr(right)}`
        : "—";

    body.innerHTML = msgs.map((m) => {
        const sender = String(m.sender || "").toLowerCase();
        const isRight = right && sender === right;
        const rowStyle = isRight ? "justify-content:flex-end;" : "justify-content:flex-start;";
        const bubbleClass = isRight ? "bubble me" : "bubble";
        const time = (m.timestamp || "").toString().slice(0, 19).replace("T", " ");
        const text = (m.text || "").toString();
        const flags = `${m.__decrypted ? "🔓" : ""}${m.isEncrypted ? " 🔒" : ""}`.trim();
        return `
          <div class="bubble-row" style="${rowStyle}">
            <div class="${bubbleClass}">
              <div>${esc(text)}</div>
              <div class="meta">
                <span class="tag">${esc(shortAddr(sender))}</span>
                <span>${esc(time)}</span>
                ${flags ? `<span>${esc(flags)}</span>` : ``}
              </div>
            </div>
          </div>
        `;
    }).join("") || `<div style="color:rgba(255,255,255,.6); padding:12px;">No decrypted messages found for this project.</div>`;

    count.textContent = `${msgs.length} messages`;
    // scroll to bottom
    body.scrollTop = body.scrollHeight;
}

function copyChatText() {
    try {
        const body = document.getElementById("chatPopupBody");
        if (!body) return;
        const lines = Array.from(body.querySelectorAll(".bubble")).map((b) => b.innerText.trim());
        const text = lines.join("\n\n");
        navigator.clipboard?.writeText(text);
    } catch {}
}


// ---------- Boot ----------
(async () => {
    ensureChatPopup();
    await refreshAll();
    await refreshLogs();
    setTab("users");
    setInterval(refreshLogs, 2000);
})();
})();