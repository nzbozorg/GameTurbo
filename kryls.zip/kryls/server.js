// server.js - KRYLS (Admin Panel) - PRISMA + SQLITE ONLY (NO JSON FILE DB)
// ✅ Removed: JSON DB (db/*.json, logs.jsonl) and ensureDB/readJSON/writeJSON
// ✅ Uses Prisma as the single source of truth for ALL data
// ✅ Keeps endpoints and response shapes compatible with the previous server.js

require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");

// Prisma client instance must be exported from ./db.js (Prisma 7 + adapter)
const prisma = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 5000;
const HOST = "0.0.0.0";
const DAY_MS = 24 * 60 * 60 * 1000;

const API_BASE = "/api";
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "kryls12345"; // ✅ عوضش کن

// -------------------- Token allowlist --------------------
const ACCEPTED_TOKENS = {
  // Sepolia stablecoins
  USDT: "0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0",
  USDC: "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238",
  DAI: "0xFF34B3d4Aee8ddCd6F9AFFFB6Fe49bD371b8a357",
};

function normalizeTokenSymbol(x) {
  return (x || "").toString().trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function resolveAcceptedToken(tokenOrSymbol, tokenSymbol) {
  const rawToken = (tokenOrSymbol || "").toString().trim();
  const sym1 = normalizeTokenSymbol(tokenSymbol);
  const sym2 = normalizeTokenSymbol(rawToken);

  if (isAddr(rawToken)) {
    const lower = rawToken.toLowerCase();
    const ok = Object.values(ACCEPTED_TOKENS).some((v) => (v || "").toLowerCase() === lower);
    if (!ok) return { tokenAddress: "", tokenSymbol: sym1 || "" };
    const foundSym =
      Object.entries(ACCEPTED_TOKENS).find(([, v]) => (v || "").toLowerCase() === lower)?.[0] || "";
    return { tokenAddress: rawToken, tokenSymbol: sym1 || foundSym || "" };
  }

  if (sym1 && ACCEPTED_TOKENS[sym1]) return { tokenAddress: ACCEPTED_TOKENS[sym1], tokenSymbol: sym1 };
  if (sym2 && ACCEPTED_TOKENS[sym2]) return { tokenAddress: ACCEPTED_TOKENS[sym2], tokenSymbol: sym2 };
  return { tokenAddress: "", tokenSymbol: sym1 || sym2 || "" };
}

// -------------------- Utilities --------------------
function nowISO() {
  return new Date().toISOString();
}

function norm(addr) {
  return (addr || "").toString().trim().toLowerCase();
}

function isAddr(s) {
  return /^0x[a-fA-F0-9]{40}$/.test((s || "").toString().trim());
}

function genId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function defaultUsernameFromWallet(w) {
  if (!w) return "user0000";
  const x = w.replace(/^0x/, "");
  return (x.slice(0, 4) + x.slice(-4)).toLowerCase();
}

function normalizeUsername(u) {
  return (u || "").toString().trim().toLowerCase();
}

function isValidUsername(u) {
  return /^[a-z0-9]{4,}$/.test(u);
}

function safeUrl(input) {
  let s = (input || "").toString().trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  try {
    const u = new URL(s);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.toString();
  } catch {
    return null;
  }
}

function normalizeLinks(arr) {
  const out = [];
  if (!Array.isArray(arr)) return out;
  for (const item of arr) {
    const url = safeUrl(item);
    if (url && !out.includes(url)) out.push(url);
    if (out.length >= 30) break;
  }
  return out;
}

// -------------------- Admin Auth (Basic Auth) --------------------
function parseBasicAuth(req) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Basic ")) return null;
  try {
    const raw = Buffer.from(h.slice(6), "base64").toString("utf8");
    const [u, p] = raw.split(":");
    return { u, p };
  } catch {
    return null;
  }
}

function adminGuard(req, res, next) {
  const cred = parseBasicAuth(req);
  if (!cred || cred.u !== ADMIN_USER || cred.p !== ADMIN_PASS) {
    res.setHeader("WWW-Authenticate", 'Basic realm="KRYLS Admin"');
    return res.status(401).send("Unauthorized");
  }
  next();
}

// -------------------- Prisma helpers --------------------
async function prismaPing() {
  await prisma.$queryRaw`SELECT 1`;
}

async function logEvent(type, actor, msg, meta) {
  // Stored only in DB (no jsonl file)
  try {
    if (!prisma.logEvent) return;
    await prisma.logEvent.create({
      data: {
        ts: new Date(),
        type: (type || "EVENT").toString(),
        actor: (actor || "").toString(),
        msg: (msg || "").toString(),
        meta: meta && typeof meta === "object" ? meta : null,
      },
    });
  } catch {
    // avoid crashing on logging
  }
}

async function isUsernameTaken(username, exceptWallet) {
  const u = normalizeUsername(username);
  if (!u) return false;
  const found = await prisma.userProfile.findFirst({
    where: {
      username: u,
      ...(exceptWallet ? { wallet: { not: norm(exceptWallet) } } : {}),
    },
    select: { wallet: true },
  });
  return !!found;
}

async function ensureDefaultOracles() {
  // If oracle model exists and table empty, seed defaults.
  try {
    if (!prisma.oracle) return;
    const count = await prisma.oracle.count();
    if (count > 0) return;

    const defaults = [
      { wallet: "0x1111111111111111111111111111111111111111", name: "Oracle #1", active: true },
      { wallet: "0x2222222222222222222222222222222222222222", name: "Oracle #2", active: true },
      { wallet: "0x3333333333333333333333333333333333333333", name: "Oracle #3", active: true },
    ];

    await prisma.oracle.createMany({ data: defaults });
  } catch {
    // no-op
  }
}

// -------------------- Presence (in-memory) --------------------
const PRESENCE_TTL_MS = 15 * 1000;
const presenceMap = new Map(); // wallet -> lastSeenMs

function touchPresence(wallet) {
  const w = norm(wallet);
  if (!isAddr(w)) return;
  presenceMap.set(w, Date.now());
}

function presenceStatusFor(wallet) {
  const w = norm(wallet);
  const last = presenceMap.get(w) || 0;
  const online = Date.now() - last <= PRESENCE_TTL_MS;
  return { online, lastSeen: last ? new Date(last).toISOString() : null };
}

// -------------------- Static --------------------
app.use(express.static(__dirname));

// ✅ Admin pages
app.get("/admin", adminGuard, async (req, res) => {
  await logEvent("ADMIN", ADMIN_USER, "Open admin panel");
  res.sendFile(path.join(__dirname, "admin.html"));
});

app.get("/admin.html", adminGuard, (req, res) => res.redirect("/admin"));
app.get("/admin.js", adminGuard, (req, res) => res.sendFile(path.join(__dirname, "admin.js")));

// -------------------- Health endpoint --------------------
app.get(`${API_BASE}/_dbcheck`, async (req, res) => {
  try {
    await prismaPing();
    res.json({
      success: true,
      mode: "prisma",
      prismaEnabled: true,
      prismaReady: true,
      prismaInitError: null,
      sqliteFile: path.join(__dirname, "dev.db"),
    });
  } catch (e) {
    res.status(500).json({
      success: false,
      mode: "prisma",
      prismaEnabled: true,
      prismaReady: false,
      prismaInitError: e?.message || String(e),
      sqliteFile: path.join(__dirname, "dev.db"),
    });
  }
});

// -------------------- E2EE Key Management APIs (DB) --------------------
app.post(`${API_BASE}/keys/store`, async (req, res) => {
  try {
    const {
      projectId,
      wrappedForAdmin,
      wrappedForUsers,
      wrappedForOracles,
      wrappedForOracle,
      oracleWallet,
    } = req.body || {};

    if (!projectId) return res.json({ success: false, message: "Missing projectId" });

    const pid = String(projectId);

    const existing = await prisma.wrappedKeyRecord.findUnique({
      where: { projectId: pid },
      select: { projectId: true, wrappedForUsers: true, wrappedForOracles: true },
    });

    const nextUsers = { ...(existing?.wrappedForUsers || {}) };
    const nextOracles = { ...(existing?.wrappedForOracles || {}) };

    if (wrappedForUsers && typeof wrappedForUsers === "object") {
      for (const [w, v] of Object.entries(wrappedForUsers)) {
        if (!w || !v) continue;
        nextUsers[String(w).toLowerCase()] = String(v);
      }
    }

    if (wrappedForOracles && typeof wrappedForOracles === "object") {
      for (const [w, v] of Object.entries(wrappedForOracles)) {
        if (!w || !v) continue;
        nextOracles[String(w).toLowerCase()] = String(v);
      }
    }

    if (wrappedForOracle && oracleWallet) {
      nextOracles[String(oracleWallet).toLowerCase()] = String(wrappedForOracle);
    }

    await prisma.wrappedKeyRecord.upsert({
      where: { projectId: pid },
      create: {
        projectId: pid,
        wrappedForAdmin: wrappedForAdmin ? String(wrappedForAdmin) : null,
        wrappedForUsers: nextUsers,
        wrappedForOracles: nextOracles,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      update: {
        wrappedForAdmin: wrappedForAdmin ? String(wrappedForAdmin) : undefined,
        wrappedForUsers: nextUsers,
        wrappedForOracles: nextOracles,
        updatedAt: new Date(),
      },
    });

    await logEvent("E2EE", "system", "store wrapped keys", { projectId: pid });
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, message: "Failed to store keys" });
  }
});

app.get(`${API_BASE}/keys/get/:projectId`, async (req, res) => {
  try {
    const pid = String(req.params.projectId || "");
    const data = await prisma.wrappedKeyRecord.findUnique({ where: { projectId: pid } });
    res.json({ success: true, data: data || null });
  } catch (e) {
    res.json({ success: false, message: "Failed to get keys" });
  }
});

// -------------------- E2EE User Public Keys (DB) --------------------
app.post(`${API_BASE}/e2ee/pubkey`, async (req, res) => {
  try {
    const { wallet, pubKeyB64 } = req.body || {};
    const w = norm(wallet);
    const incoming = String(pubKeyB64 || "").trim();

    if (!isAddr(w) || !incoming) {
      return res.status(400).json({ success: false, message: "Invalid payload" });
    }

    const existing = await prisma.userProfile.findUnique({
      where: { wallet: w },
      select: { wallet: true, e2eePubKeyB64: true },
    });

    if (!existing) {
      // create minimal profile if missing (keeps old behavior flexible)
      await prisma.userProfile.create({
        data: {
          wallet: w,
          role: "freelancer",
          username: defaultUsernameFromWallet(w),
          bio: "",
          socials: [],
          joinedAt: new Date(),
          e2eePubKeyB64: incoming,
          e2eePubKeyUpdatedAt: new Date(),
        },
      });
      await logEvent("E2EE", w, "create profile + set pubkey");
      return res.json({ success: true, unchanged: false });
    }

    const current = String(existing.e2eePubKeyB64 || "").trim();
    if (current && current === incoming) {
      return res.json({ success: true, unchanged: true });
    }

    await prisma.userProfile.update({
      where: { wallet: w },
      data: { e2eePubKeyB64: incoming, e2eePubKeyUpdatedAt: new Date() },
    });

    await logEvent("E2EE", w, "update user pubkey");
    res.json({ success: true, unchanged: false });
  } catch (e) {
    res.json({ success: false, message: "Failed to save pubkey" });
  }
});

app.get(`${API_BASE}/e2ee/pubkey/:wallet`, async (req, res) => {
  try {
    const w = norm(req.params.wallet);
    if (!isAddr(w)) return res.status(400).json({ success: false, message: "Invalid wallet" });

    const p = await prisma.userProfile.findUnique({
      where: { wallet: w },
      select: { wallet: true, e2eePubKeyB64: true },
    });

    res.json({ success: true, wallet: w, pubKeyB64: p?.e2eePubKeyB64 || null });
  } catch {
    res.json({ success: false, message: "Failed to get pubkey" });
  }
});

// -------------------- Admin pubkey (DB Config) --------------------
app.post(`${API_BASE}/keys/admin-pubkey`, adminGuard, async (req, res) => {
  try {
    const { adminPubKeyB64 } = req.body || {};
    if (!adminPubKeyB64) return res.json({ success: false, message: "Missing adminPubKeyB64" });

    await prisma.config.upsert({
      where: { key: "adminPubKeyB64" },
      create: { key: "adminPubKeyB64", value: { adminPubKeyB64 }, updatedAt: new Date() },
      update: { value: { adminPubKeyB64 }, updatedAt: new Date() },
    });

    await logEvent("ADMIN", ADMIN_USER, "update admin pubkey");
    res.json({ success: true });
  } catch {
    res.json({ success: false, message: "Failed to save admin pubkey" });
  }
});

app.get(`${API_BASE}/keys/admin-pubkey`, async (req, res) => {
  try {
    const row = await prisma.config.findUnique({ where: { key: "adminPubKeyB64" } });
    res.json({ success: true, adminPubKeyB64: row?.value?.adminPubKeyB64 || null });
  } catch {
    res.json({ success: true, adminPubKeyB64: null });
  }
});

// -------------------- Public APIs --------------------
// Login
app.post(`${API_BASE}/login`, async (req, res) => {
  const w = norm(req.body?.wallet);
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const user = await prisma.userProfile.findUnique({ where: { wallet: w } });
  const exists = !!user;

  await logEvent("AUTH", w, "login", { exists });

  if (exists) return res.json({ success: true, isNewUser: false, role: user.role, user });
  return res.json({ success: true, isNewUser: true });
});

// set-role (create/update profile)
app.post(`${API_BASE}/set-role`, async (req, res) => {
  const w = norm(req.body?.wallet);
  let role = (req.body?.role || "freelancer").toString().trim().toLowerCase();
  if (role === "company") role = "client";
  if (!["client", "freelancer"].includes(role)) role = "freelancer";

  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const existing = await prisma.userProfile.findUnique({ where: { wallet: w } });

  let user;
  if (!existing) {
    user = await prisma.userProfile.create({
      data: {
        wallet: w,
        role,
        username: defaultUsernameFromWallet(w),
        bio: "",
        socials: [],
        joinedAt: new Date(),
        companyPaidTx: "",
        premiumActive: false,
      },
    });
    await logEvent("PROFILE", w, "create profile", { role });
  } else {
    user = await prisma.userProfile.update({
      where: { wallet: w },
      data: { role },
    });
    await logEvent("PROFILE", w, "update role", { role });
  }

  res.json({ success: true, user });
});

// get profile
app.get(`${API_BASE}/profile/:wallet`, async (req, res) => {
  const w = norm(req.params.wallet);
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const user = await prisma.userProfile.findUnique({ where: { wallet: w } });
  res.json({ success: true, user: user || null });
});

// Presence
app.post(`${API_BASE}/presence/ping`, (req, res) => {
  const w = norm(req.body?.wallet);
  if (!isAddr(w)) return res.status(400).json({ success: false, message: "Invalid wallet" });
  touchPresence(w);
  res.json({ success: true });
});

app.get(`${API_BASE}/presence/status`, (req, res) => {
  const raw = (req.query.wallets || "").toString();
  const wallets = raw
    .split(",")
    .map((x) => norm(x))
    .filter((x) => isAddr(x))
    .slice(0, 50);
  const out = {};
  wallets.forEach((w) => (out[w] = presenceStatusFor(w)));
  res.json({ success: true, status: out });
});

// Profile update
function profileUpdateValidation(req, currentUsername, wallet) {
  let username = normalizeUsername(req.body?.username || currentUsername || defaultUsernameFromWallet(wallet));
  if (!username) username = defaultUsernameFromWallet(wallet);
  if (!isValidUsername(username)) {
    return { ok: false, message: "Username invalid. Min 4 chars, only lowercase letters and numbers." };
  }
  return { ok: true, username };
}

app.post(`${API_BASE}/profile/update`, async (req, res) => {
  const w = norm(req.body?.wallet);
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const current = await prisma.userProfile.findUnique({ where: { wallet: w } });
  if (!current) return res.json({ success: false, message: "Profile not found" });

  const v = profileUpdateValidation(req, current.username, w);
  if (!v.ok) return res.json({ success: false, message: v.message });

  if (await isUsernameTaken(v.username, w)) {
    return res.json({ success: false, message: "Username already taken." });
  }

  const links = normalizeLinks(req.body?.socials);

  const user = await prisma.userProfile.update({
    where: { wallet: w },
    data: {
      username: v.username,
      bio: (req.body?.bio || "").toString(),
      socials: links,
    },
  });

  await logEvent("PROFILE", w, "update profile", { username: user.username });
  res.json({ success: true, user });
});

// alias
app.post(`${API_BASE}/update-profile`, async (req, res) => {
  // forward to the same handler
  req.url = `${API_BASE}/profile/update`;
  return app._router.handle(req, res, () => {});
});

// Premium activate
app.post(`${API_BASE}/premium/activate`, async (req, res) => {
  try {
    const w = norm(req.body?.wallet);
    const txHash = (req.body?.txHash || "").toString();
    const tokenSymbol = (req.body?.tokenSymbol || req.body?.token || "").toString();

    if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

    const user = await prisma.userProfile.findUnique({ where: { wallet: w } });
    if (!user) return res.json({ success: false, message: "Profile not found" });

    const updated = await prisma.userProfile.update({
      where: { wallet: w },
      data: {
        premiumActive: true,
        premiumPaidAt: new Date(),
        premiumTxHash: txHash,
        premiumToken: tokenSymbol,
        companyPaidTx: txHash || user.companyPaidTx || "",
      },
    });

    await logEvent("PREMIUM", w, "premium activated", { txHash, tokenSymbol });
    res.json({ success: true, user: updated });
  } catch {
    res.json({ success: false, message: "Failed to activate premium" });
  }
});

// mark-company-paid
app.post(`${API_BASE}/mark-company-paid`, async (req, res) => {
  const w = norm(req.body?.wallet);
  const txHash = (req.body?.txHash || "").toString();
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const user = await prisma.userProfile.findUnique({ where: { wallet: w } });
  if (!user) return res.json({ success: false, message: "Profile not found" });

  await prisma.userProfile.update({
    where: { wallet: w },
    data: {
      companyPaidTx: txHash,
      premiumActive: true,
      premiumPaidAt: user.premiumPaidAt || new Date(),
      premiumTxHash: txHash || user.premiumTxHash || "",
      premiumToken: user.premiumToken || "",
    },
  });

  await logEvent("PREMIUM", w, "mark premium paid", { txHash });
  res.json({ success: true });
});

// -------------------- Projects --------------------
async function cleanupProjectsDB() {
  const now = new Date();

  // unpin expired pins
  await prisma.project.updateMany({
    where: { pinned: true, pinnedUntil: { lt: now } },
    data: { pinned: false, pinnedUntil: null, updatedAt: now },
  });

  // delete expired OPEN projects
  await prisma.project.deleteMany({
    where: { status: "Open", expiresAt: { lt: now } },
  });
}

app.post(`${API_BASE}/post-project`, async (req, res) => {
  try {
    const p = req.body || {};
    const owner = norm(p.owner);

    if (!isAddr(owner)) return res.json({ success: false, message: "Invalid owner wallet" });
    if (!p.title || !p.budget) return res.json({ success: false, message: "Missing fields" });

    const MIN_DESC_LEN = 80;
    const desc = (p.desc || "").toString().trim();
    if (desc.length < MIN_DESC_LEN) {
      return res.json({ success: false, message: `Description required (min ${MIN_DESC_LEN} chars).` });
    }

    const serviceCategory = Number.isFinite(+p.serviceCategory) ? +p.serviceCategory : 0;
    const roleCategory = Number.isFinite(+p.roleCategory) ? +p.roleCategory : 0;
    if (!serviceCategory || !roleCategory) {
      return res.json({ success: false, message: "Service category and role category are required." });
    }

    const tokenInput = (p.token || p.tokenAddress || "").toString().trim();
    const tokenSymInput = (p.tokenSymbol || "").toString().trim();
    const resolved = resolveAcceptedToken(tokenInput || tokenSymInput, tokenSymInput);
    if (!resolved.tokenAddress) {
      return res.json({
        success: false,
        message: "Unsupported token. Allowed: USDT / USDC / DAI on Sepolia.",
      });
    }

    const ownerProfile = await prisma.userProfile.findUnique({ where: { wallet: owner } });
    const isPremiumOwner = !!ownerProfile?.premiumActive;

    const pinnedRequested = !!p.pinned;
    let pinGranted = false;
    let pinDeniedReason = "";

    if (pinnedRequested) {
      if (!isPremiumOwner) {
        pinDeniedReason = "Premium required";
      } else {
        const last = ownerProfile?.lastPinnedAt ? new Date(ownerProfile.lastPinnedAt).getTime() : 0;
        const ok = !last || Date.now() - last >= DAY_MS;
        if (!ok) {
          pinDeniedReason = "Cooldown";
        } else {
          pinGranted = true;
          await prisma.userProfile.update({
            where: { wallet: owner },
            data: { lastPinnedAt: new Date() },
          });
        }
      }
    }

    const projectId = genId("proj");
    const expiresAt = new Date(Date.now() + (isPremiumOwner ? 15 : 7) * DAY_MS);

    const project = await prisma.project.create({
      data: {
        id: projectId,
        createdAt: new Date(),
        updatedAt: new Date(),
        ownerWallet: owner,
        premiumOwner: isPremiumOwner,
        expiresAt,
        title: (p.title || "Untitled").toString(),
        desc: (p.desc || "").toString(),
        budget: (p.budget || "0").toString(),
        tags: Array.isArray(p.tags) ? p.tags.map(String) : [],
        status: "Open",
        pinned: pinGranted ? true : false,
        pinnedUntil: pinGranted ? new Date(Date.now() + DAY_MS) : null,
        token: resolved.tokenAddress,
        tokenSymbol: resolved.tokenSymbol,
        totalCommitment: (p.totalCommitment || p.budget || "0").toString(),
        hourlyRate: (p.hourlyRate || "0").toString(),
        paymentType: Number.isFinite(+p.paymentType) ? +p.paymentType : 0,
        milestoneAmounts: Array.isArray(p.milestoneAmounts) ? p.milestoneAmounts.map(String) : [],
        milestoneDescriptions: Array.isArray(p.milestoneDescriptions) ? p.milestoneDescriptions.map(String) : [],
        isWeb3Service: false,
        serviceCategory,
        roleCategory,
        issueCertificate: false,
        assignedFreelancer: null,
        onChainId: null,
        txHash: null,
        pinDeniedReason: pinDeniedReason || null,
      },
    });

    await logEvent("PROJECT", owner, "post project", { projectId: project.id, title: project.title });

    res.json({
      success: true,
      project,
      pinGranted,
      pinDeniedReason,
      nextPinAt: pinGranted
        ? new Date(Date.now() + DAY_MS).toISOString()
        : ownerProfile?.lastPinnedAt
        ? new Date(new Date(ownerProfile.lastPinnedAt).getTime() + DAY_MS).toISOString()
        : null,
    });
  } catch (e) {
    res.json({ success: false, message: "Failed to post project" });
  }
});

app.get(`${API_BASE}/all-open-projects`, async (req, res) => {
  await cleanupProjectsDB();

  const open = await prisma.project.findMany({
    where: { status: "Open" },
    orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
  });

  res.json({ success: true, projects: open });
});

app.get(`${API_BASE}/project/:id`, async (req, res) => {
  await cleanupProjectsDB();

  const id = (req.params.id || "").toString();
  const project = await prisma.project.findUnique({ where: { id } });

  const owner = project?.ownerWallet ? norm(project.ownerWallet) : "";
  const ownerProfile = owner ? await prisma.userProfile.findUnique({ where: { wallet: owner } }) : null;

  res.json({
    success: true,
    project: project || null,
    pinGranted: false,
    pinDeniedReason: null,
    nextPinAt: ownerProfile?.lastPinnedAt
      ? new Date(new Date(ownerProfile.lastPinnedAt).getTime() + DAY_MS).toISOString()
      : null,
  });
});

app.get(`${API_BASE}/client-projects/:wallet`, async (req, res) => {
  await cleanupProjectsDB();

  const w = norm(req.params.wallet);
  const mine = await prisma.project.findMany({
    where: { ownerWallet: w },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, projects: mine });
});

app.get(`${API_BASE}/freelancer-active/:wallet`, async (req, res) => {
  await cleanupProjectsDB();

  const w = norm(req.params.wallet);
  const active = await prisma.project.findMany({
    where: { assignedFreelancer: w, status: "In Progress" },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, projects: active });
});

app.post(`${API_BASE}/cancel-project`, async (req, res) => {
  try {
    const wallet = norm(req.body?.wallet);
    const projectId = (req.body?.projectId || "").toString();
    if (!isAddr(wallet) || !projectId) return res.json({ success: false, message: "Invalid payload" });

    const p = await prisma.project.findUnique({ where: { id: projectId } });
    if (!p) return res.json({ success: false, message: "Project not found" });
    if (norm(p.ownerWallet) !== wallet) return res.json({ success: false, message: "Only owner can cancel" });
    if ((p.status || "") !== "Open")
      return res.json({ success: false, message: "Only Open projects can be cancelled" });

    const updated = await prisma.project.update({
      where: { id: projectId },
      data: { status: "Cancelled", updatedAt: new Date() },
    });

    await logEvent("PROJECT", wallet, "cancel project", { projectId });
    res.json({ success: true, project: updated });
  } catch {
    res.json({ success: false, message: "Cancel failed" });
  }
});

// -------------------- Requests --------------------
app.post(`${API_BASE}/request-project`, async (req, res) => {
  try {
    const { projectId, freelancer, price, duration, coverLetter } = req.body || {};
    const pid = (projectId || "").toString();
    const fr = norm(freelancer);

    if (!pid || !isAddr(fr)) return res.status(400).json({ success: false, message: "projectId & freelancer required" });

    const pf = await prisma.userProfile.findUnique({ where: { wallet: fr } });
    if (!pf) return res.status(400).json({ success: false, message: "Please select role first" });
    if ((pf.role || "") !== "freelancer")
      return res.status(403).json({ success: false, message: "Only freelancers can request projects" });

    const project = await prisma.project.findUnique({ where: { id: pid } });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    if ((project.status || "") !== "Open") return res.status(400).json({ success: false, message: "Project is not open" });
    if (norm(project.ownerWallet) === fr) return res.status(400).json({ success: false, message: "Owner cannot request own project" });

    const existsPending = await prisma.request.findFirst({
      where: { projectId: pid, freelancerWallet: fr, status: "Pending" },
    });
    if (existsPending) return res.status(400).json({ success: false, message: "You already requested this project" });

    const r = await prisma.request.create({
      data: {
        id: genId("req"),
        createdAt: new Date(),
        updatedAt: new Date(),
        projectId: pid,
        ownerWallet: norm(project.ownerWallet),
        freelancerWallet: fr,
        price: (price || "").toString(),
        duration: (duration || "").toString(),
        coverLetter: (coverLetter || "").toString(),
        status: "Pending",
        hiddenFor: [],
      },
    });

    await logEvent("REQUEST", fr, "send request", { projectId: pid, owner: r.ownerWallet, requestId: r.id });

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: pid,
        senderWallet: fr,
        receiverWallet: norm(project.ownerWallet),
        text: `📩 New request from ${fr.slice(0, 6)}...${fr.slice(-4)}\n${(coverLetter || "").toString().slice(0, 140)}`,
        timestamp: new Date(),
        type: "system",
      },
    });

    res.json({ success: true, request: {
      id: r.id,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
      projectId: r.projectId,
      owner: r.ownerWallet,
      freelancer: r.freelancerWallet,
      price: r.price,
      duration: r.duration,
      coverLetter: r.coverLetter,
      status: r.status,
      hiddenFor: r.hiddenFor || [],
    }});
  } catch {
    res.status(500).json({ success: false, message: "Failed to request project" });
  }
});

app.get(`${API_BASE}/requests/incoming/:wallet`, async (req, res) => {
  const w = norm(req.params.wallet);

  const reqs = await prisma.request.findMany({
    where: {
      ownerWallet: w,
      OR: [{ hiddenFor: { equals: [] } }, { NOT: { hiddenFor: { has: w } } }],
    },
    orderBy: { createdAt: "desc" },
  });

  const projectIds = [...new Set(reqs.map((r) => r.projectId))];
  const projects = await prisma.project.findMany({ where: { id: { in: projectIds } } });
  const map = new Map(projects.map((p) => [p.id, p]));

  const incoming = reqs.map((r) => ({
    id: r.id,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
    projectId: r.projectId,
    owner: r.ownerWallet,
    freelancer: r.freelancerWallet,
    price: r.price,
    duration: r.duration,
    coverLetter: r.coverLetter,
    status: r.status,
    hiddenFor: r.hiddenFor || [],
    project: map.get(r.projectId) || null,
  }));

  res.json({ success: true, requests: incoming });
});

app.get(`${API_BASE}/requests/mine/:wallet`, async (req, res) => {
  const w = norm(req.params.wallet);

  const reqs = await prisma.request.findMany({
    where: {
      freelancerWallet: w,
      OR: [{ hiddenFor: { equals: [] } }, { NOT: { hiddenFor: { has: w } } }],
    },
    orderBy: { createdAt: "desc" },
  });

  const projectIds = [...new Set(reqs.map((r) => r.projectId))];
  const projects = await prisma.project.findMany({ where: { id: { in: projectIds } } });
  const map = new Map(projects.map((p) => [p.id, p]));

  const mine = reqs.map((r) => ({
    id: r.id,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
    projectId: r.projectId,
    owner: r.ownerWallet,
    freelancer: r.freelancerWallet,
    price: r.price,
    duration: r.duration,
    coverLetter: r.coverLetter,
    status: r.status,
    hiddenFor: r.hiddenFor || [],
    project: map.get(r.projectId) || null,
  }));

  res.json({ success: true, requests: mine });
});

app.post(`${API_BASE}/requests/confirm`, async (req, res) => {
  try {
    const { ownerWallet, requestId, projectId, freelancer, txHash, onChainId } = req.body || {};
    const owner = norm(ownerWallet);
    const rid = (requestId || "").toString();
    const pid = (projectId || "").toString();
    const fr = norm(freelancer);

    if (!isAddr(owner) || !isAddr(fr) || !rid || !pid) return res.json({ success: false, message: "Invalid payload" });

    const reqItem = await prisma.request.findUnique({ where: { id: rid } });
    if (!reqItem) return res.json({ success: false, message: "Request not found" });

    const project = await prisma.project.findUnique({ where: { id: pid } });
    if (!project) return res.json({ success: false, message: "Project not found" });

    if (norm(project.ownerWallet) !== owner) return res.json({ success: false, message: "Only owner can confirm" });
    if (norm(reqItem.ownerWallet) !== owner) return res.json({ success: false, message: "Owner mismatch" });
    if (norm(reqItem.freelancerWallet) !== fr) return res.json({ success: false, message: "Freelancer mismatch" });
    if ((project.status || "") !== "Open") return res.json({ success: false, message: "Project is not open" });
    if (owner === fr) return res.json({ success: false, message: "Owner cannot be freelancer" });

    const updatedAt = new Date();

    await prisma.$transaction(async (tx) => {
      await tx.request.update({
        where: { id: rid },
        data: { status: "Approved", updatedAt },
      });

      await tx.request.updateMany({
        where: { projectId: pid, status: "Pending", id: { not: rid } },
        data: { status: "Rejected", updatedAt },
      });

      await tx.project.update({
        where: { id: pid },
        data: {
          status: "In Progress",
          assignedFreelancer: fr,
          txHash: txHash || null,
          onChainId: onChainId !== undefined && onChainId !== null ? String(onChainId) : null,
          updatedAt,
        },
      });

      await tx.message.create({
        data: {
          id: genId("msg"),
          projectId: pid,
          senderWallet: owner,
          receiverWallet: fr,
          text: `✅ Approved! Escrow created on Sepolia.${onChainId ? " On-chain ID: " + String(onChainId) + ". " : " "}${txHash ? " Tx: " + txHash : " "}`,
          timestamp: new Date(),
          type: "system",
        },
      });
    });

    const project2 = await prisma.project.findUnique({ where: { id: pid } });
    const req2 = await prisma.request.findUnique({ where: { id: rid } });

    await logEvent("REQUEST", owner, "confirm request", { projectId: pid, freelancer: fr, txHash, onChainId });

    res.json({ success: true, project: project2, request: req2 });
  } catch {
    res.json({ success: false, message: "Failed to confirm request" });
  }
});

app.post(`${API_BASE}/requests/reject`, async (req, res) => {
  try {
    const { ownerWallet, requestId, projectId, freelancer } = req.body || {};
    const owner = norm(ownerWallet);
    const rid = (requestId || "").toString();
    const pid = (projectId || "").toString();
    const fr = norm(freelancer);

    if (!isAddr(owner) || !isAddr(fr) || !rid || !pid) return res.json({ success: false, message: "Invalid payload" });

    const reqItem = await prisma.request.findUnique({ where: { id: rid } });
    if (!reqItem) return res.json({ success: false, message: "Request not found" });

    if (norm(reqItem.ownerWallet) !== owner) return res.json({ success: false, message: "Only owner can reject" });
    if (norm(reqItem.freelancerWallet) !== fr) return res.json({ success: false, message: "Freelancer mismatch" });
    if ((reqItem.status || "") !== "Pending") return res.json({ success: false, message: "Request is not pending" });

    const updated = await prisma.request.update({
      where: { id: rid },
      data: { status: "Rejected", updatedAt: new Date() },
    });

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: pid,
        senderWallet: owner,
        receiverWallet: fr,
        text: "❌ Your request has been rejected by the client.",
        timestamp: new Date(),
        type: "system",
      },
    });

    await logEvent("REQUEST", owner, "reject request", { projectId: pid, freelancer: fr, requestId: rid });

    const project = await prisma.project.findUnique({ where: { id: pid } });

    res.json({ success: true, request: updated, project: project || null });
  } catch {
    res.json({ success: false, message: "Failed to reject request" });
  }
});

app.post(`${API_BASE}/requests/hide`, async (req, res) => {
  try {
    const w = norm(req.body?.wallet);
    const rid = (req.body?.requestId || "").toString();
    if (!isAddr(w) || !rid) return res.json({ success: false, message: "Invalid payload" });

    const r = await prisma.request.findUnique({ where: { id: rid } });
    if (!r) return res.json({ success: false, message: "Request not found" });

    const owner = norm(r.ownerWallet);
    const fr = norm(r.freelancerWallet);
    if (w !== owner && w !== fr) return res.json({ success: false, message: "Only participants can hide" });

    const hiddenFor = Array.isArray(r.hiddenFor) ? r.hiddenFor : [];
    const exists = hiddenFor.map(norm).includes(w);
    const next = exists ? hiddenFor : [...hiddenFor, w];

    await prisma.request.update({
      where: { id: rid },
      data: { hiddenFor: next, updatedAt: new Date() },
    });

    await logEvent("REQUEST", w, "hide request", { requestId: rid, projectId: r.projectId });
    res.json({ success: true });
  } catch {
    res.json({ success: false, message: "Failed to hide request" });
  }
});

// -------------------- Terms --------------------
app.get(`${API_BASE}/oracles`, async (req, res) => {
  const oracles = await prisma.oracle.findMany({ where: { active: { not: false } } });
  res.json({ success: true, oracles: oracles.filter((o) => o && isAddr(o.wallet)) });
});

app.get(`${API_BASE}/terms/pending/:projectId`, async (req, res) => {
  const pid = (req.params.projectId || "").toString();
  const pending = await prisma.termsProposal.findFirst({
    where: { projectId: pid, status: "Pending" },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, proposal: pending || null });
});

app.post(`${API_BASE}/terms/propose`, async (req, res) => {
  try {
    const { projectId, wallet, price, deliveryDate, deliveryDays } = req.body || {};
    const pid = (projectId || "").toString();
    const w = norm(wallet);
    if (!pid || !isAddr(w)) return res.status(400).json({ success: false, message: "Invalid payload" });

    const p = await prisma.project.findUnique({ where: { id: pid } });
    if (!p) return res.status(404).json({ success: false, message: "Project not found" });

    const owner = norm(p.ownerWallet);
    const fr = norm(p.assignedFreelancer);
    if (w !== owner && w !== fr) return res.status(403).json({ success: false, message: "Only project participants can propose terms." });

    const newPrice = (price ?? "").toString();
    const dd = (deliveryDate ?? "").toString().trim();
    const days = (deliveryDays ?? "").toString().trim();

    await prisma.$transaction(async (tx) => {
      await tx.termsProposal.updateMany({
        where: { projectId: pid, status: "Pending" },
        data: { status: "Superseded", updatedAt: new Date() },
      });

      const proposal = await tx.termsProposal.create({
        data: {
          id: genId("terms"),
          createdAt: new Date(),
          updatedAt: new Date(),
          projectId: pid,
          proposerWallet: w,
          price: newPrice,
          deliveryDate: dd,
          deliveryDays: days,
          status: "Pending",
        },
      });

      const other = w === owner ? fr : owner;

      await tx.message.create({
        data: {
          id: genId("msg"),
          projectId: pid,
          senderWallet: w,
          receiverWallet: other || owner,
          text: `🔁 Terms change proposed: Price=${newPrice || "—"} | Delivery=${dd || (days ? days + " days" : "—")}.`,
          timestamp: new Date(),
          type: "system",
          meta: { kind: "terms_propose", proposalId: proposal.id },
        },
      });

      await logEvent("TERMS", w, "propose terms", { projectId: pid, proposalId: proposal.id });

      res.json({ success: true, proposal });
    });
  } catch {
    res.status(500).json({ success: false, message: "Failed to propose terms" });
  }
});

app.post(`${API_BASE}/terms/respond`, async (req, res) => {
  try {
    const { projectId, wallet, proposalId, action } = req.body || {};
    const pid = (projectId || "").toString();
    const w = norm(wallet);
    const id = (proposalId || "").toString();
    const act = (action || "").toString().toLowerCase();

    if (!pid || !isAddr(w) || !id || !["accept", "reject"].includes(act)) {
      return res.status(400).json({ success: false, message: "Invalid payload" });
    }

    const p = await prisma.project.findUnique({ where: { id: pid } });
    if (!p) return res.status(404).json({ success: false, message: "Project not found" });

    const owner = norm(p.ownerWallet);
    const fr = norm(p.assignedFreelancer);
    if (w !== owner && w !== fr) return res.status(403).json({ success: false, message: "Only participants can respond." });

    const proposal = await prisma.termsProposal.findUnique({ where: { id } });
    if (!proposal || proposal.projectId !== pid) return res.status(404).json({ success: false, message: "Proposal not found" });

    if ((proposal.status || "") !== "Pending") return res.status(400).json({ success: false, message: "Proposal is not pending" });
    if (norm(proposal.proposerWallet) === w) return res.status(403).json({ success: false, message: "Proposer cannot respond to own proposal" });

    const updatedAt = new Date();

    await prisma.$transaction(async (tx) => {
      const newStatus = act === "accept" ? "Accepted" : "Rejected";

      await tx.termsProposal.update({
        where: { id },
        data: { status: newStatus, updatedAt },
      });

      if (act === "accept") {
        await tx.project.update({
          where: { id: pid },
          data: {
            agreedPrice: (proposal.price || "").toString(),
            deliveryDate: (proposal.deliveryDate || "").toString(),
            deliveryDays: (proposal.deliveryDays || "").toString(),
            updatedAt,
          },
        });
      }

      const other = w === owner ? fr : owner;

      await tx.message.create({
        data: {
          id: genId("msg"),
          projectId: pid,
          senderWallet: w,
          receiverWallet: other || owner,
          text:
            act === "accept"
              ? `✅ Terms updated by agreement. New Price=${proposal.price || "—"} | Delivery=${proposal.deliveryDate || (proposal.deliveryDays ? proposal.deliveryDays + " days" : "—")}.`
              : `✖ Terms change rejected.`,
          timestamp: new Date(),
          type: "system",
          meta: { kind: "terms_" + act, proposalId: id },
        },
      });
    });

    await logEvent("TERMS", w, "respond terms", { projectId: pid, proposalId: id, action: act });

    const proposal2 = await prisma.termsProposal.findUnique({ where: { id } });
    const project2 = await prisma.project.findUnique({ where: { id: pid } });

    res.json({ success: true, proposal: proposal2, project: project2 });
  } catch {
    res.status(500).json({ success: false, message: "Failed to respond terms" });
  }
});

// -------------------- Delivery --------------------
app.get(`${API_BASE}/delivery/latest/:projectId`, async (req, res) => {
  const pid = (req.params.projectId || "").toString();
  const latest = await prisma.delivery.findFirst({
    where: { projectId: pid },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, delivery: latest || null });
});

app.post(`${API_BASE}/delivery/submit`, async (req, res) => {
  try {
    const { projectId, freelancerWallet, content } = req.body || {};
    const pid = (projectId || "").toString();
    const fr = norm(freelancerWallet);
    const c = (content || "").toString();

    if (!pid || !isAddr(fr) || !c.trim()) return res.status(400).json({ success: false, message: "Invalid payload" });

    const p = await prisma.project.findUnique({ where: { id: pid } });
    if (!p) return res.status(404).json({ success: false, message: "Project not found" });
    if ((p.status || "") !== "In Progress") return res.status(400).json({ success: false, message: "Project is not in progress" });
    if (norm(p.assignedFreelancer) !== fr) return res.status(403).json({ success: false, message: "Only assigned freelancer can submit delivery" });

    const delivery = await prisma.delivery.create({
      data: {
        id: genId("deliv"),
        createdAt: new Date(),
        updatedAt: new Date(),
        projectId: pid,
        freelancerWallet: fr,
        ownerWallet: norm(p.ownerWallet),
        content: c,
        status: "Submitted",
      },
    });

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: pid,
        senderWallet: fr,
        receiverWallet: norm(p.ownerWallet),
        text: `📦 Delivery submitted: ${c.slice(0, 220)}${c.length > 220 ? "…" : " "}`,
        timestamp: new Date(),
        type: "system",
        meta: { kind: "delivery_submit", deliveryId: delivery.id },
      },
    });

    await logEvent("DELIVERY", fr, "submit delivery", { projectId: pid, deliveryId: delivery.id });

    res.json({ success: true, delivery });
  } catch {
    res.status(500).json({ success: false, message: "Delivery submit failed" });
  }
});

app.post(`${API_BASE}/delivery/accept`, async (req, res) => {
  try {
    const { projectId, ownerWallet, deliveryId } = req.body || {};
    const pid = (projectId || "").toString();
    const owner = norm(ownerWallet);
    const did = (deliveryId || "").toString();

    if (!pid || !isAddr(owner) || !did) return res.status(400).json({ success: false, message: "Invalid payload" });

    const p = await prisma.project.findUnique({ where: { id: pid } });
    if (!p) return res.status(404).json({ success: false, message: "Project not found" });
    if (norm(p.ownerWallet) !== owner) return res.status(403).json({ success: false, message: "Only owner can accept delivery" });

    const d = await prisma.delivery.findUnique({ where: { id: did } });
    if (!d || d.projectId !== pid) return res.status(404).json({ success: false, message: "Delivery not found" });
    if ((d.status || "") !== "Submitted") return res.status(400).json({ success: false, message: "Delivery is not submitted" });

    const updatedAt = new Date();

    const [delivery, project] = await prisma.$transaction([
      prisma.delivery.update({ where: { id: did }, data: { status: "Accepted", updatedAt } }),
      prisma.project.update({ where: { id: pid }, data: { status: "Completed", completedAt: updatedAt, updatedAt } }),
    ]);

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: pid,
        senderWallet: owner,
        receiverWallet: norm(p.assignedFreelancer),
        text: `✅ Delivery accepted. Project completed. (Chat will auto-delete after 24h)`,
        timestamp: new Date(),
        type: "system",
        meta: { kind: "delivery_accept", deliveryId: delivery.id },
      },
    });

    await logEvent("DELIVERY", owner, "accept delivery", { projectId: pid, deliveryId: delivery.id });

    res.json({ success: true, project, delivery });
  } catch {
    res.status(500).json({ success: false, message: "Accept failed" });
  }
});

// -------------------- Disputes --------------------
app.post(`${API_BASE}/delivery/dispute`, async (req, res) => {
  try {
    const { projectId, wallet, deliveryId, reason, oracleWallet } = req.body || {};
    const pid = (projectId || "").toString();
    const w = norm(wallet);
    const did = (deliveryId || "").toString();
    const rsn = (reason || "").toString();
    const oracle = norm(oracleWallet);

    if (!pid || !isAddr(w) || !did) return res.status(400).json({ success: false, message: "Invalid payload" });

    const p = await prisma.project.findUnique({ where: { id: pid } });
    if (!p) return res.status(404).json({ success: false, message: "Project not found" });

    const owner = norm(p.ownerWallet);
    const fr = norm(p.assignedFreelancer);
    if (w !== owner && w !== fr) return res.status(403).json({ success: false, message: "Only participants can open dispute" });

    const oracles = await prisma.oracle.findMany({ where: { active: { not: false } } });
    const chosen = isAddr(oracle) ? oracle : (oracles[0]?.wallet || "0x0000000000000000000000000000000000000000");

    const dispute = await prisma.dispute.create({
      data: {
        id: genId("disp"),
        createdAt: new Date(),
        updatedAt: new Date(),
        projectId: pid,
        deliveryId: did,
        openedByWallet: w,
        ownerWallet: owner,
        freelancerWallet: fr,
        oracleWallet: chosen,
        reason: rsn,
        status: "Open",
        decision: "",
        notes: "",
      },
    });

    await prisma.project.update({ where: { id: pid }, data: { status: "Disputed", updatedAt: new Date() } });

    const other = w === owner ? fr : owner;

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: pid,
        senderWallet: w,
        receiverWallet: other || owner,
        text: `⚖ Dispute opened. Oracle=${chosen.slice(0, 6)}...${chosen.slice(-4)}. Reason: ${rsn ? rsn.slice(0, 180) : "—"}`,
        timestamp: new Date(),
        type: "system",
        meta: { kind: "dispute_open", disputeId: dispute.id, oracle: chosen },
      },
    });

    await logEvent("DISPUTE", w, "open dispute", { projectId: pid, disputeId: dispute.id, oracle: chosen });

    res.json({ success: true, dispute });
  } catch {
    res.status(500).json({ success: false, message: "Dispute open failed" });
  }
});

app.get(`${API_BASE}/dispute/latest/:projectId`, async (req, res) => {
  const pid = (req.params.projectId || "").toString();
  const latest = await prisma.dispute.findFirst({
    where: { projectId: pid },
    orderBy: { createdAt: "desc" },
  });
  res.json({ success: true, dispute: latest || null });
});

app.post(`${API_BASE}/dispute/resolve`, async (req, res) => {
  try {
    const { disputeId, oracleWallet, decision, notes } = req.body || {};
    const did = (disputeId || "").toString();
    const ow = norm(oracleWallet);
    const dec = (decision || "").toString().toLowerCase();
    const nts = (notes || "").toString();

    if (!did || !isAddr(ow)) return res.status(400).json({ success: false, message: "Invalid payload" });

    const oracles = await prisma.oracle.findMany({ where: { active: { not: false } } });
    const isOracle = oracles.some((o) => norm(o.wallet) === ow);
    if (!isOracle) return res.status(403).json({ success: false, message: "Only oracle can resolve" });

    const d = await prisma.dispute.findUnique({ where: { id: did } });
    if (!d) return res.status(404).json({ success: false, message: "Dispute not found" });
    if ((d.status || "") !== "Open") return res.status(400).json({ success: false, message: "Dispute not open" });
    if (norm(d.oracleWallet) !== ow) return res.status(403).json({ success: false, message: "This dispute is assigned to another oracle" });

    const updatedAt = new Date();

    const dispute = await prisma.dispute.update({
      where: { id: did },
      data: { status: "Resolved", updatedAt, decision: dec, notes: nts },
    });

    await prisma.project.update({
      where: { id: dispute.projectId },
      data: { status: "Completed", completedAt: updatedAt, updatedAt },
    });

    await prisma.message.create({
      data: {
        id: genId("msg"),
        projectId: dispute.projectId,
        senderWallet: ow,
        receiverWallet: dispute.openedByWallet,
        text: `🧑‍⚖️ Oracle resolved dispute. Decision=${dec || "—"}. Notes: ${nts ? nts.slice(0, 180) : "—"} (Chat will auto-delete after 24h)`,
        timestamp: new Date(),
        type: "system",
        meta: { kind: "dispute_resolve", disputeId: dispute.id, decision: dec },
      },
    });

    await logEvent("DISPUTE", ow, "resolve dispute", { disputeId: dispute.id, projectId: dispute.projectId, decision: dec });

    res.json({ success: true, dispute });
  } catch {
    res.status(500).json({ success: false, message: "Resolve failed" });
  }
});

// -------------------- Messages (DB) - E2EE supported --------------------
app.post(`${API_BASE}/send-message`, async (req, res) => {
  try {
    const { projectId, sender, receiver, text, iv, isEncrypted, sealed } = req.body || {};
    const pid = (projectId || "").toString();
    const s = norm(sender);
    const r = norm(receiver);
    const t = (text || "").toString();

    if (!pid || !isAddr(s) || !isAddr(r) || !t.trim()) {
      return res.status(400).json({ success: false, message: "Invalid message payload" });
    }

    const data = {
      id: genId("msg"),
      projectId: pid,
      senderWallet: s,
      receiverWallet: r,
      text: t,
      timestamp: new Date(),
      type: "user",
      isEncrypted: !!isEncrypted,
      iv: isEncrypted ? (iv || null) : null,
      sealed: sealed ? sealed : null,
    };

    await prisma.message.create({ data });
    await logEvent("CHAT", s, "send message", { projectId: pid, to: r, encrypted: !!isEncrypted });

    res.json({ success: true });
  } catch {
    res.status(500).json({ success: false, message: "Failed to send message" });
  }
});

app.get(`${API_BASE}/messages/:wallet`, async (req, res) => {
  const w = norm(req.params.wallet);
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const msgs = await prisma.message.findMany({
    where: { OR: [{ senderWallet: w }, { receiverWallet: w }] },
    orderBy: { timestamp: "asc" },
  });

  res.json({ success: true, messages: msgs });
});

// -------------------- Admin APIs (DB) --------------------
app.get(`${API_BASE}/admin/users`, adminGuard, async (req, res) => {
  const users = await prisma.userProfile.findMany({ orderBy: { joinedAt: "desc" } });
  res.json({ success: true, users });
});

app.post(`${API_BASE}/admin/users/update`, adminGuard, async (req, res) => {
  const w = norm(req.body?.wallet);
  if (!isAddr(w)) return res.json({ success: false, message: "Invalid wallet" });

  const user = await prisma.userProfile.findUnique({ where: { wallet: w } });
  if (!user) return res.json({ success: false, message: "User not found" });

  let premiumActive = user.premiumActive;
  if (typeof req.body?.premiumActive === "boolean") premiumActive = !!req.body.premiumActive;
  else if (typeof req.body?.premiumActive === "string") premiumActive = req.body.premiumActive === "true";

  let role = (req.body?.role || user.role || "freelancer").toString().trim().toLowerCase();
  if (role === "company") role = "client";
  if (!["client", "freelancer"].includes(role)) role = "freelancer";

  let username = normalizeUsername(req.body?.username || user.username || defaultUsernameFromWallet(w));
  if (!username) username = defaultUsernameFromWallet(w);
  if (!isValidUsername(username)) return res.json({ success: false, message: "Username invalid (min 4, a-z0-9 only)" });
  if (await isUsernameTaken(username, w)) return res.json({ success: false, message: "Username already taken" });

  const updated = await prisma.userProfile.update({
    where: { wallet: w },
    data: {
      premiumActive,
      role,
      username,
      bio: (req.body?.bio || "").toString(),
      socials: normalizeLinks(req.body?.socials || user.socials),
      companyPaidTx: (req.body?.companyPaidTx || user.companyPaidTx || "").toString(),
    },
  });

  await logEvent("ADMIN", ADMIN_USER, "update user", { wallet: w, role: updated.role });

  res.json({ success: true, user: updated });
});

app.get(`${API_BASE}/admin/projects`, adminGuard, async (req, res) => {
  const projects = await prisma.project.findMany({ orderBy: { createdAt: "desc" } });
  res.json({ success: true, projects });
});

app.get(`${API_BASE}/admin/requests`, adminGuard, async (req, res) => {
  const requests = await prisma.request.findMany({ orderBy: { createdAt: "desc" } });
  res.json({ success: true, requests });
});

app.get(`${API_BASE}/admin/messages`, adminGuard, async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit || "500", 10), 1), 3000);
  const messages = await prisma.message.findMany({ orderBy: { timestamp: "desc" }, take: limit });
  res.json({ success: true, messages });
});

app.get(`${API_BASE}/admin/logs`, adminGuard, async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit || "100", 10), 1), 1000);
  const logs = await prisma.logEvent.findMany({ orderBy: { ts: "desc" }, take: limit });
  res.json({ success: true, logs });
});

// -------------------- Cleanup: auto-delete chats 24h after completion (DB) --------------------
async function cleanupExpiredChatsDB() {
  try {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const completed = await prisma.project.findMany({
      where: { status: "Completed", completedAt: { lte: cutoff } },
      select: { id: true },
    });

    if (!completed.length) return;

    const ids = completed.map((p) => p.id);

    await prisma.$transaction([
      prisma.message.deleteMany({ where: { projectId: { in: ids } } }),
      prisma.delivery.deleteMany({ where: { projectId: { in: ids } } }),
      prisma.dispute.deleteMany({ where: { projectId: { in: ids } } }),
      prisma.termsProposal.deleteMany({ where: { projectId: { in: ids } } }),
      prisma.request.deleteMany({ where: { projectId: { in: ids } } }),
    ]);

    await logEvent("CLEANUP", "server", "auto-delete chats after 24h", { projects: ids });
  } catch {
    // no-op
  }
}

setInterval(cleanupExpiredChatsDB, 10 * 60 * 1000);

// -------------------- Run --------------------
(async () => {
  await prismaPing();
  await ensureDefaultOracles();

  app.listen(PORT, HOST, async () => {
    console.log(`🚀 Server running on http://${HOST}:${PORT}`);
    console.log(`🔐 Admin panel: http://${HOST}:${PORT}/admin (user=${ADMIN_USER})`);
    console.log(`💾 DB mode: prisma/sqlite ONLY`);
    await logEvent("ADMIN", ADMIN_USER, "server started", { host: HOST, port: PORT, dbMode: "prisma" });
  });
})();