// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/Strings.sol";
import "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";
import "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

// [--- External Modules Interfaces ---]
interface IERC20Metadata {
    function decimals() external view returns (uint8);
}

interface IKrylsCertificate {
    function issueCertificate(
        uint256 projectId,
        address client,
        address freelancer,
        uint8 serviceCategory,
        uint8 roleCategory
    ) external;
}

// Standard Kleros / ERC-792 Interface
interface IArbitrator {
    function createDispute(uint256 _choices, bytes memory _extraData) external payable returns (uint256 disputeID);
    function arbitrationCost(bytes memory _extraData) external view returns (uint256 cost);
}

/**
 * @title KrylsEscrowProduction (Kleros + XMTP)
 * @notice Automated, non-custodial escrow for digital services.
 *
 * Key Features:
 * - Dispute resolution via Kleros Arbitrator.
 * - Dispute configuration editable ONLY before first deposit; locked automatically once funded.
 * - Optional deposit deferral at project creation.
 * - Optional XMTP integration.
 */
contract KrylsEscrowProduction is Ownable2Step, Pausable, ReentrancyGuard, EIP712 {
    using SafeERC20 for IERC20;
    using Strings for uint256;
    using EnumerableSet for EnumerableSet.AddressSet;

    // -------- Custom Errors --------
    error InvalidProject();
    error NotParticipant();
    error OnlyClient();
    error OnlyFreelancer();
    error ProjectNotActive();
    error ProjectAlreadyDisputed();
    error EmptyString();
    error StringTooLong();
    error InvalidPaymentType();
    error BudgetTooLow();
    error ExceedsBudget();
    error NoRemainingFunds();
    error InsufficientBalance();
    error InvalidMilestone();
    error MilestoneAlreadyPaid();
    error InvalidState();
    error DisputeExists();
    error DisputeNotActive();
    error FeeTooHigh();
    error ZeroAddress();
    error InvalidToken();
    error Unauthorized();
    error TimeExpired();
    error InvalidCategories();
    error InvalidDeadline();
    error FrontRunProtection();
    error InvalidArbitrator();
    error DuplicateProject();
    error InsufficientTokenBalance();
    error EmergencyWithdrawNotAllowed();
    error CommitmentMismatch();
    error DepositExceedsCommitment();
    error InvalidDepositAmount();
    error DisputeConfigLocked();
    error InsufficientArbitrationFee();

    // -------- Enums & Constants --------
    enum PaymentType { Full, Milestone }
    
    enum Status { Active, Completed, Cancelled, Disputed }
    enum DisputeStatus { None, Raised, Resolved }

    enum Web3ServiceCategory {
        DeFi, NFTAndDigitalAssets, DAOs, GameFiAndMetaverse, InfraAndProtocols, WalletsAndPayments,
        IdentityPrivacySecurity, OnOffRampsAndFiatBridges, DataAnalyticsAndTools, SocialAndContentWeb3,
        RWAAndEnterprise, LaunchpadsIncubatorsGrants
    }
   
    enum DigitalServiceCategory { WebDevelopment, MobileAppDevelopment, GraphicDesign, SEOAndDigitalMarketing }

    enum Web3RoleCategory {
        SmartContractEngineer, SmartContractAuditor, BackendBlockchainEngineer, DevOpsInfrastructure,
        FrontendDappDeveloper, ProductManagerWeb3, UXUIDesignerWeb3, TokenomicsExpert, OnchainDataAnalyst,
        CommunityManager, MarketingGrowthWeb3, ContentCreatorEducator, LegalComplianceAdvisor,
        DAOOperatorGovernance, NFTGameArtist3DDesigner, LocalizationTranslation, BizDevPartnership
    }
    enum DigitalRoleCategory {
        FrontendDeveloper, BackendDeveloper, MobileDeveloper, UIUXDesigner, GraphicDesigner,
        SEOSpecialist, DigitalMarketer, ContentCreator
    }

    uint16 public constant MAX_PLATFORM_FEE_BPS = 1000;
    uint8 public constant MAX_MILESTONE_COUNT = 20;
    uint256 public constant MIN_BUDGET = 1000;
    uint256 public constant MAX_STRING_LENGTH = 1000;
    uint256 public constant MAX_DELAY = 30 days;
    uint256 public constant FRONT_RUN_DELAY = 5 minutes;
    uint256 public constant MAX_PROJECT_DURATION = 365 days;
    // fixed registration fee (token-decimals-based)
    uint256 public constant CLIENT_REG_FEE = 30;

    // -------- Allowed tokens (pre-added) --------
    address public constant USDT = 0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0;
    address public constant USDC = 0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238;
    address public constant DAI  = 0xFF34B3d4Aee8ddCd6F9AFFFB6Fe49bD371b8a357;

    // -------- Structs --------
    struct Project {
        address client;
        address freelancer;
        address token;

        uint256 totalCommitment;
        uint256 depositedFunds;

        uint256 fundsReleased;
        uint256 createdAt;
        uint256 completedAt;

        uint256 externalDisputeId;
        uint256 arbitrationFeeEstimate;

        PaymentType paymentType;
        Status status;

        uint16 platformFeeBps;

        uint8 milestoneCount;
        uint8 serviceCategory;
        uint8 roleCategory;
        bool issueCertificate;
        bool xmtpEnabled;
        bool isWeb3Service;
        uint32 lastActionTime;

        // Dispute routing
        address arbitrator;
        bool disputeConfigLocked;

        string xmtpConversationId;
    }

    struct Milestone {
        uint256 amount;
        uint256 paidAt;
        uint256 autoApproveDeadline;
        bytes32 descriptionHash;
        bool paid;
        bool clientApproved;
        bool freelancerApproved;
        bool isDeposited;
    }

    struct Dispute {
        address raisedBy;
        uint256 raisedAt;
        uint256 resolvedAt;
        address resolvedBy;
        uint256 clientShare; // bps
        string reason;
        string resolutionNote;
        DisputeStatus status;
    }

    struct Timelock {
        uint256 timestamp;
        bytes32 operationHash;
    }

    // -------- State Variables & Mappings --------
    address public feeRecipient;
    uint16 public defaultPlatformFeeBps;
    uint256 public timelockDelay = 0;

    mapping(address => uint256) public totalLockedFundsByToken;
    mapping(uint8 => uint16) public serviceCategoryFees;
    
    // Client registration
    mapping(address => bool) public isRegisteredClient;
    uint256 public totalRegisteredClients;
    
    // Simple platform stats by token
    mapping(address => uint256) public totalVolumeByToken;

    EnumerableSet.AddressSet private allowedTokens;

    Project[] public projects;
    mapping(uint256 => Milestone[]) public projectMilestones;
    mapping(uint256 => Dispute) public disputes;

    mapping(uint256 => uint256) public projectEarliestDeadline;

    mapping(bytes32 => Timelock) public timelocks;
    mapping(bytes32 => bool) public activeProjectHashes;
    mapping(uint256 => bytes32) public projectHashes;

    address public certificateContract;
    // Arbitrator allowlist
    mapping(address => bool) public allowedArbitrators;

    // Maps Kleros DisputeID to ProjectID
    mapping(uint256 => uint256) public disputeIdToProjectId;

    // -------- Events --------
    event PlatformFeeUpdated(uint16 newBps);
    event FeeRecipientUpdated(address newRecipient);
    event TokenAllowedUpdated(address indexed token, bool allowed);
    event CertificateContractUpdated(address newContract);
    event TimelockDelayUpdated(uint256 newDelay);
    event AllowedArbitratorUpdated(address indexed arbitrator, bool allowed);
    event ServiceCategoryFeeUpdated(uint8 indexed category, uint16 newBps);
    event ProjectCreated(
        uint256 indexed id,
        address indexed client,
        address indexed freelancer,
        address token,
        uint256 totalCommitment,
        uint8 paymentType,
        uint16 platformFeeBps,
        bool isWeb3Service
    );
    event ProjectMetadata(
        uint256 indexed id,
        uint8 serviceCategory,
        uint8 roleCategory,
        bool issueCertificate,
        bool isWeb3Service
    );
    event MilestoneAdded(uint256 indexed projectId, uint256 milestoneIndex, uint256 amount, bytes32 descriptionHash);
    event MilestoneApproved(uint256 indexed projectId, uint256 milestoneIndex, address indexed by);
    event MilestonePaid(uint256 indexed projectId, uint256 milestoneIndex, uint256 amount);
    event MilestoneDepositRequired(uint256 indexed projectId, uint256 milestoneIndex, uint256 amount);
    event AutoApproveDeadlineSet(uint256 indexed projectId, uint256 milestoneIndex, uint256 deadline);
    event MilestoneAutoApproved(uint256 indexed projectId, uint256 milestoneIndex);

    event FullPaymentReleased(uint256 indexed projectId, uint256 amount);
    event ProjectCancelled(uint256 indexed projectId, uint256 refundAmount, address initiatedBy);
    event ProjectDisputed(uint256 indexed projectId, address indexed raisedBy, string reason);
    event ProjectDisputeResolved(uint256 indexed projectId, address resolvedBy, uint256 clientShare, string resolutionNote);
    event ProjectSettled(
        uint256 indexed projectId,
        address indexed resolver,
        bool disputed,
        uint256 clientShareOfEscrow,
        uint256 freelancerShareOfEscrow
    );
    event CertificateIssued(uint256 indexed projectId, address certificateContract, uint8 serviceCategory, uint8 roleCategory);
    event CertificateIssueFailed(uint256 indexed projectId, string reason);
    event ProjectCompleted(uint256 indexed projectId, uint256 completedAt);
    event EmergencyStop(address indexed by, string reason);
    event TokensRescued(address indexed token, uint256 amount, address indexed to);

    event ProjectFundsDeposited(uint256 indexed projectId, uint256 amount, uint256 newTotalDeposited);
    event ProjectFundsWithdrawn(uint256 indexed projectId, uint256 amount);
    event EmergencyWithdrawExecuted(uint256 indexed projectId, address indexed user, uint256 amount);
    event ProjectExpired(uint256 indexed projectId);
    event ProjectArbitratorAssigned(uint256 indexed projectId, address indexed arbitrator);
    event ExternalDisputeCreated(uint256 indexed projectId, address indexed arbitrator, uint256 externalDisputeId);
    event ExternalDisputeCreateFailed(uint256 indexed projectId, address indexed arbitrator, string reason);

    event ProjectXMTPUpdated(uint256 indexed projectId, string conversationId, bool enabled);
    event ProjectXMTPOnchainMessage(uint256 indexed projectId, address indexed sender, string message);

    event ClientRegistered(address indexed client);
    
    event ProjectDisputeConfigUpdated(
        uint256 indexed projectId,
        address arbitrator
    );
    
    // Kleros Ruling Event
    event Ruling(address indexed _arbitrator, uint256 indexed _disputeID, uint256 _ruling);

    // -------- Modifiers --------
    modifier validProject(uint256 projectId) {
        if (projectId >= projects.length) revert InvalidProject();
        _;
    }

    modifier onlyProjectParticipant(uint256 projectId) {
        Project storage p = projects[projectId];
        if (_msgSender() != p.client && _msgSender() != p.freelancer) revert NotParticipant();
        _;
    }

    modifier onlyClient(uint256 projectId) {
        if (_msgSender() != projects[projectId].client) revert OnlyClient();
        _;
    }

    modifier onlyFreelancer(uint256 projectId) {
        if (_msgSender() != projects[projectId].freelancer) revert OnlyFreelancer();
        _;
    }

    modifier projectActive(uint256 projectId) {
        if (projects[projectId].status != Status.Active) revert ProjectNotActive();
        _;
    }

    modifier notDisputed(uint256 projectId) {
        if (projects[projectId].status == Status.Disputed) revert ProjectAlreadyDisputed();
        _;
    }

    modifier validString(string calldata str, uint256 maxLength) {
        if (bytes(str).length == 0) revert EmptyString();
        if (bytes(str).length > maxLength) revert StringTooLong();
        _;
    }

    modifier frontRunProtected(uint256 projectId) {
        Project storage p = projects[projectId];
        if (block.timestamp < p.lastActionTime + FRONT_RUN_DELAY) revert FrontRunProtection();
        p.lastActionTime = uint32(block.timestamp);
        _;
    }

    modifier timelocked(bytes32 operation) {
        bytes32 hash = keccak256(abi.encode(operation, _msgSender(), msg.data));
        Timelock storage tl = timelocks[hash];

        if (tl.timestamp == 0) {
            tl.timestamp = block.timestamp + timelockDelay;
            tl.operationHash = hash;
            return;
        }

        if (block.timestamp < tl.timestamp) revert TimeExpired();
        delete timelocks[hash];
        _;
    }

    // -------- Constructor --------
    constructor(address initialOwner)
        Ownable(initialOwner)
        EIP712("KRYLS", "1")
    {
        feeRecipient = initialOwner;
        defaultPlatformFeeBps = 250; // 2.5% default

        // defaults for all categories
        uint8 maxWeb3Category = uint8(Web3ServiceCategory.LaunchpadsIncubatorsGrants);
        for (uint8 i = 0; i <= maxWeb3Category; i++) {
            serviceCategoryFees[i] = 250;
        }
        uint8 maxDigitalCategory = uint8(DigitalServiceCategory.SEOAndDigitalMarketing);
        for (uint8 i = 0; i <= maxDigitalCategory; i++) {
            serviceCategoryFees[i] = 250;
        }

        // -------- Pre-allow tokens (USDT/USDC/DAI) --------
        allowedTokens.add(USDT);
        emit TokenAllowedUpdated(USDT, true);

        allowedTokens.add(USDC);
        emit TokenAllowedUpdated(USDC, true);

        allowedTokens.add(DAI);
        emit TokenAllowedUpdated(DAI, true);
    }

    // -------- Admin Functions (Timelocked) --------
    function setDefaultPlatformFeeBps(uint16 _bps)
        external
        onlyOwner
        timelocked(keccak256("setDefaultPlatformFeeBps"))
    {
        if (_bps > MAX_PLATFORM_FEE_BPS) revert FeeTooHigh();
        defaultPlatformFeeBps = _bps;
        emit PlatformFeeUpdated(_bps);
    }

    function setServiceCategoryFeeBps(uint8 _category, uint16 _bps)
        external
        onlyOwner
        timelocked(keccak256("setServiceCategoryFeeBps"))
    {
        if (_bps > MAX_PLATFORM_FEE_BPS) revert FeeTooHigh();
        if (_category > uint8(Web3ServiceCategory.LaunchpadsIncubatorsGrants) &&
            _category > uint8(DigitalServiceCategory.SEOAndDigitalMarketing))
            revert InvalidCategories();
        serviceCategoryFees[_category] = _bps;
        emit ServiceCategoryFeeUpdated(_category, _bps);
    }

    function setFeeRecipient(address _recipient)
        external
        onlyOwner
        timelocked(keccak256("setFeeRecipient"))
    {
        if (_recipient == address(0)) revert ZeroAddress();
        feeRecipient = _recipient;
        emit FeeRecipientUpdated(_recipient);
    }

    function setAllowedToken(address _token, bool _allowed)
        external
        onlyOwner
        timelocked(keccak256("setAllowedToken"))
    {
        if (_token == address(0)) revert ZeroAddress();
        if (_allowed) allowedTokens.add(_token);
        else allowedTokens.remove(_token);

        emit TokenAllowedUpdated(_token, _allowed);
    }

    function setCertificateContract(address _certificate)
        external
        onlyOwner
        timelocked(keccak256("setCertificateContract"))
    {
        certificateContract = _certificate;
        emit CertificateContractUpdated(_certificate);
    }

    function setTimelockDelay(uint256 _delay)
        external
        onlyOwner
        timelocked(keccak256("setTimelockDelay"))
    {
        if (_delay > MAX_DELAY) revert InvalidDeadline();
        timelockDelay = _delay;
        emit TimelockDelayUpdated(_delay);
    }

    function setAllowedArbitrator(address arbitrator, bool allowed)
        external
        onlyOwner
        timelocked(keccak256("setAllowedArbitrator"))
    {
        if (arbitrator == address(0)) revert ZeroAddress();
        allowedArbitrators[arbitrator] = allowed;
        emit AllowedArbitratorUpdated(arbitrator, allowed);
    }

    // -------- Pause Controls --------
    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function emergencyStop(string calldata reason)
        external
        onlyOwner
        validString(reason, 200)
    {
        _pause();
        emit EmergencyStop(_msgSender(), reason);
    }

    // Rescue tokens not locked in escrow accumulator
    function rescueTokens(address tokenAddress, uint256 amount) external onlyOwner {
        if (tokenAddress == address(0)) revert InvalidToken();
        IERC20 token = IERC20(tokenAddress);
        uint256 lockedBalance = totalLockedFundsByToken[tokenAddress];
        uint256 totalBalance = token.balanceOf(address(this));
        uint256 availableBalance = totalBalance > lockedBalance ? totalBalance - lockedBalance : 0;

        if (amount > availableBalance) revert InsufficientBalance();
        token.safeTransfer(owner(), amount);

        emit TokensRescued(tokenAddress, amount, owner());
    }

    // -------- View Functions --------
    function getProjectFinancials(uint256 projectId)
        public
        view
        validProject(projectId)
        returns (
            uint256 totalCommitment,
            uint256 depositedFunds,
            uint256 fundsReleased,
            uint256 remainingCommitment,
            uint16 platformFeeBps_
        )
    {
        Project storage p = projects[projectId];
        totalCommitment = p.totalCommitment;
        depositedFunds = p.depositedFunds;
        fundsReleased = p.fundsReleased;
        remainingCommitment = p.totalCommitment - p.depositedFunds;
        platformFeeBps_ = p.platformFeeBps;
    }

    function getTotalLockedFunds(address tokenAddress) external view returns (uint256) {
        return totalLockedFundsByToken[tokenAddress];
    }

    function getPlatformStats() external view returns (uint256 totalProjects, uint256 registeredCompanies) {
        return (projects.length, totalRegisteredClients);
    }

    function getTotalVolume(address token) external view returns (uint256) {
        return totalVolumeByToken[token];
    }

    // -------- Client Registration --------
    function registerClient(address _token) external nonReentrant whenNotPaused {
        if (!allowedTokens.contains(_token)) revert InvalidToken();
        if (isRegisteredClient[_msgSender()]) revert InvalidState();

        uint8 decimals = IERC20Metadata(_token).decimals();
        uint256 amountToPay = CLIENT_REG_FEE * (10 ** decimals);

        IERC20(_token).safeTransferFrom(_msgSender(), feeRecipient, amountToPay);
        isRegisteredClient[_msgSender()] = true;
        totalRegisteredClients++;

        emit ClientRegistered(_msgSender());
    }

    // -------- Core Project Logic (Create) --------
    function createProject(
        address _freelancer,
        address _token,
        uint256 _totalCommitment,
        uint8 _paymentType,
        uint256[] calldata _milestoneAmounts,
        string[] calldata _milestoneDescriptions,
        bool _isWeb3Service,
        uint8 _serviceCategory,
        uint8 _roleCategory,
        bool _issueCertificate,
        address _arbitrator,
        bool _deferDeposit,
        bool _enableXMTP 
    )
        external
        whenNotPaused
        nonReentrant
        returns (uint256 projectId)
    {
        if (_freelancer == address(0) || _freelancer == _msgSender()) revert ZeroAddress();
        if (_token == address(0) || !allowedTokens.contains(_token)) revert InvalidToken();
        if (_totalCommitment < MIN_BUDGET) revert BudgetTooLow();
        if (_paymentType > uint8(PaymentType.Milestone)) revert InvalidPaymentType();
        if (_arbitrator != address(0) && !allowedArbitrators[_arbitrator]) revert InvalidArbitrator();

        PaymentType paymentType = PaymentType(_paymentType);
        
        // 1. Validate Payment/Commitment integrity using original values
        uint256 amountToDeposit = _validateFlexiblePaymentType(
            paymentType,
            _milestoneAmounts,
            _milestoneDescriptions,
            _totalCommitment,
            _deferDeposit
        );

        // 2. XMTP Logic: Add fee to commitment and amountToDeposit
        if (_enableXMTP) {
            uint8 decimals = IERC20Metadata(_token).decimals();
            uint256 xmtpFee = 50 * (10 ** decimals);
            
            _totalCommitment += xmtpFee;

            if (amountToDeposit > 0 || (!_deferDeposit && amountToDeposit == 0)) {
                if (amountToDeposit > 0) {
                     amountToDeposit += xmtpFee;
                }
            }
        }

        bytes32 hash = keccak256(abi.encode(
            _msgSender(),
            _freelancer,
            _token,
            _totalCommitment,
            _paymentType,
            _milestoneAmounts.length,
            _isWeb3Service,
            _serviceCategory,
            _roleCategory,
            block.chainid
        ));
        if (activeProjectHashes[hash]) revert DuplicateProject();

        _validateCategories(_isWeb3Service, _serviceCategory, _roleCategory);

        // Pull tokens if depositing now
        if (amountToDeposit > 0) {
            IERC20 token = IERC20(_token);
            if (token.balanceOf(_msgSender()) < amountToDeposit) revert InsufficientTokenBalance();
            _pullTokens(_token, _msgSender(), amountToDeposit);
        }

        projectId = projects.length;
        Project storage p = projects.push();

        // Category fee
        uint16 feeBps = serviceCategoryFees[_serviceCategory];
        if (feeBps == 0) feeBps = defaultPlatformFeeBps;

        p.client = _msgSender();
        p.freelancer = _freelancer;
        p.token = _token;
        p.totalCommitment = _totalCommitment;
        p.depositedFunds = amountToDeposit;
        p.paymentType = paymentType;
        p.status = Status.Active;
        p.platformFeeBps = feeBps;
        p.milestoneCount = uint8(_milestoneAmounts.length);
        p.createdAt = block.timestamp;
        p.serviceCategory = _serviceCategory;
        p.roleCategory = _roleCategory;
        p.issueCertificate = _issueCertificate;
        p.isWeb3Service = _isWeb3Service;
        p.lastActionTime = uint32(block.timestamp);
        p.arbitrator = _arbitrator;
        
        // XMTP Struct Settings
        p.xmtpEnabled = _enableXMTP;
        if (_enableXMTP) {
            p.xmtpConversationId = string(abi.encodePacked(
                block.timestamp.toString(),
                "_",
                uint256(uint160(_msgSender())).toHexString(20)
            ));
        }

        activeProjectHashes[hash] = true;
        projectHashes[projectId] = hash;

        if (_arbitrator != address(0)) emit ProjectArbitratorAssigned(projectId, _arbitrator);
        
        // Accumulator & volume
        if (amountToDeposit > 0) {
            totalLockedFundsByToken[_token] += amountToDeposit;
            totalVolumeByToken[_token] += amountToDeposit;
        }

        // Initialize milestones
        if (paymentType == PaymentType.Milestone) {
            _initializeFlexibleMilestones(
                projectId,
                _milestoneAmounts,
                _milestoneDescriptions,
                amountToDeposit
            );
        }

        // Lock dispute config if funded now
        if (p.depositedFunds > 0) {
            p.disputeConfigLocked = true;
        }

        if (_enableXMTP) {
             emit ProjectXMTPUpdated(projectId, p.xmtpConversationId, true);
        }

        emit ProjectCreated(projectId, p.client, p.freelancer, p.token, p.totalCommitment, _paymentType, p.platformFeeBps, _isWeb3Service);
        emit ProjectMetadata(projectId, _serviceCategory, _roleCategory, p.issueCertificate, _isWeb3Service);
        emit ProjectFundsDeposited(projectId, amountToDeposit, p.depositedFunds);
    }

    // -------- Dispute Config Editing (only before funding) --------
    function updateProjectDisputeConfig(
        uint256 projectId,
        address arbitrator
    )
        external
        whenNotPaused
        validProject(projectId)
        projectActive(projectId)
        onlyClient(projectId)
    {
        Project storage p = projects[projectId];
        if (p.disputeConfigLocked || p.depositedFunds > 0) revert DisputeConfigLocked();
        if (disputes[projectId].status != DisputeStatus.None) revert DisputeExists();
        if (arbitrator != address(0) && !allowedArbitrators[arbitrator]) revert InvalidArbitrator();

        p.arbitrator = arbitrator;

        if (arbitrator != address(0)) emit ProjectArbitratorAssigned(projectId, arbitrator);
        emit ProjectDisputeConfigUpdated(projectId, arbitrator);
    }

    // -------- Deposit Funds (generalized) --------
    function depositProjectFunds(uint256 projectId, uint256 amountToDeposit)
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
        projectActive(projectId)
        onlyClient(projectId)
    {
        if (amountToDeposit == 0) revert InvalidDepositAmount();
        Project storage p = projects[projectId];
        uint256 remainingCommitment = p.totalCommitment - p.depositedFunds;
        if (amountToDeposit > remainingCommitment) revert DepositExceedsCommitment();

        _pullTokens(p.token, _msgSender(), amountToDeposit);
        p.depositedFunds += amountToDeposit;

        // lock dispute config on first deposit
        if (!p.disputeConfigLocked) {
            p.disputeConfigLocked = true;
        }

        totalLockedFundsByToken[p.token] += amountToDeposit;
        totalVolumeByToken[p.token] += amountToDeposit;
        if (p.paymentType == PaymentType.Milestone) {
            _updateMilestoneDepositStatus(projectId);
        }

        emit ProjectFundsDeposited(projectId, amountToDeposit, p.depositedFunds);
    }

    // -------- Full --------
    function releaseFull(uint256 projectId)
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
        projectActive(projectId)
        notDisputed(projectId)
        onlyClient(projectId)
        frontRunProtected(projectId)
    {
        Project storage p = projects[projectId];
        if (p.paymentType != PaymentType.Full) revert InvalidPaymentType();

        uint256 remaining = p.totalCommitment - p.fundsReleased;
        if (remaining == 0) revert NoRemainingFunds();
        uint256 availableBalance = p.depositedFunds - p.fundsReleased;
        if (availableBalance < remaining) revert InsufficientBalance();
        
        p.fundsReleased = p.totalCommitment;
        (uint256 netAmount, uint256 feeAmount) = _calculateAmounts(remaining, p.platformFeeBps);

        IERC20 token = IERC20(p.token);
        _transferTokens(token, p.freelancer, netAmount);
        _transferTokens(token, feeRecipient, feeAmount);
        totalLockedFundsByToken[p.token] -= remaining;
        emit FullPaymentReleased(projectId, remaining);
        _checkProjectCompletion(projectId, p);
    }

    // -------- Cancel --------
    function clientCancelProject(uint256 projectId)
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
        projectActive(projectId)
        onlyClient(projectId)
        frontRunProtected(projectId)
    {
        _cancelProject(projectId, true);
    }

    function freelancerCancelProject(uint256 projectId)
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
        projectActive(projectId)
        onlyFreelancer(projectId)
        frontRunProtected(projectId)
    {
        _cancelProject(projectId, false);
    }

    function _cancelProject(uint256 projectId, bool isClient) internal {
        Project storage p = projects[projectId];
        IERC20 token = IERC20(p.token);

        uint256 remainingInEscrow = p.depositedFunds - p.fundsReleased;
        if (remainingInEscrow == 0) revert NoRemainingFunds();
        if (!isClient) {
            if (p.fundsReleased != 0) revert InvalidState();
            if (p.paymentType == PaymentType.Milestone) {
                for (uint256 i = 0; i < projectMilestones[projectId].length; i++) {
                    Milestone storage m = projectMilestones[projectId][i];
                    if (m.clientApproved || m.freelancerApproved) revert InvalidState();
                }
            }
        }

        p.status = Status.Cancelled;
        p.fundsReleased = p.depositedFunds;

        _transferTokens(token, p.client, remainingInEscrow);
        totalLockedFundsByToken[p.token] -= remainingInEscrow;
        emit ProjectCancelled(projectId, remainingInEscrow, _msgSender());
        emit ProjectFundsWithdrawn(projectId, remainingInEscrow);
        _clearProjectHash(projectId);
    }

    // -------- Dispute Lifecycle --------
    /**
     * @notice Raise a dispute.
     * @dev Supports Kleros via IArbitrator interface. Caller must send msg.value >= arbitrationCost if using Kleros.
     */
    function raiseDispute(
        uint256 projectId,
        string calldata reason,
        bytes calldata extraData
    )
        external
        payable // Standard Kleros fee
        whenNotPaused
        nonReentrant
        validProject(projectId)
        projectActive(projectId)
        onlyProjectParticipant(projectId)
        validString(reason, 200)
    {
        Project storage p = projects[projectId];
        if (p.status == Status.Disputed) revert ProjectAlreadyDisputed();
        if (disputes[projectId].status != DisputeStatus.None) revert DisputeExists();

        Dispute storage d = disputes[projectId];
        d.raisedBy = _msgSender();
        d.raisedAt = block.timestamp;
        d.status = DisputeStatus.Raised;
        d.reason = reason;

        p.status = Status.Disputed;

        emit ProjectDisputed(projectId, _msgSender(), reason);
        // Standard Kleros / ERC-792 dispute creation
        if (p.arbitrator != address(0)) {
            IArbitrator arb = IArbitrator(p.arbitrator);
            uint256 cost = arb.arbitrationCost(extraData);
            
            // Check if user sent enough ETH for arbitration fee
            if (msg.value < cost) revert InsufficientArbitrationFee();
            // Create dispute in Kleros (choices = 2: 1=Client, 2=Freelancer usually)
            try arb.createDispute{value: cost}(2, extraData) returns (uint256 extId) {
                p.externalDisputeId = extId;
                disputeIdToProjectId[extId] = projectId; // Map for callback
                emit ExternalDisputeCreated(projectId, p.arbitrator, extId);
            } catch Error(string memory r) {
                emit ExternalDisputeCreateFailed(projectId, p.arbitrator, r);
                // Refund if failed
                if (msg.value > 0) {
                    (bool sent, ) = payable(_msgSender()).call{value: msg.value}("");
                    require(sent, "Refund failed");
                }
            } catch {
                emit ExternalDisputeCreateFailed(projectId, p.arbitrator, "Low-level error");
                if (msg.value > 0) {
                    (bool sent, ) = payable(_msgSender()).call{value: msg.value}("");
                    require(sent, "Refund failed");
                }
            }
        }
    }

    /**
     * @notice Standard Kleros callback.
     * @dev Kleros Court calls this function to execute the ruling.
     * Ruling 1 = Party A (Client usually), Ruling 2 = Party B (Freelancer), 0 = Refused.
     */
    function rule(uint256 _disputeID, uint256 _ruling) external {
        uint256 projectId = disputeIdToProjectId[_disputeID];
        Project storage p = projects[projectId];
        
        // Ensure only the assigned arbitrator can rule
        require(_msgSender() == p.arbitrator, "Only arbitrator");
        require(p.status == Status.Disputed, "Not disputed");

        emit Ruling(p.arbitrator, _disputeID, _ruling);

        // Convert Kleros Ruling to clientShareBps
        // Assuming: 1 = Client wins (100%), 2 = Freelancer wins (0% to client)
        // 0 = Refused to arbitrate (Split 50/50)
        uint256 clientShareBps;
        if (_ruling == 1) {
            clientShareBps = 10000;
        } else if (_ruling == 2) {
            clientShareBps = 0;
        } else {
            clientShareBps = 5000;
        }

        _finalizeDisputeResolution(projectId, clientShareBps, "Kleros Ruling", _msgSender(), true);
    }

    /**
     * @notice Manual Arbitrator submits dispute outcome on-chain.
     * @dev Kept for backwards compatibility or non-standard arbitrators.
     */
    function ruleFromArbitrator(
        uint256 projectId,
        uint256 clientShareBps,
        string calldata resolutionNote
    )
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
        validString(resolutionNote, MAX_STRING_LENGTH)
    {
        Project storage p = projects[projectId];
        if (p.status != Status.Disputed) revert ProjectAlreadyDisputed();
        if (p.arbitrator == address(0)) revert InvalidArbitrator();
        if (_msgSender() != p.arbitrator) revert Unauthorized();

        _finalizeDisputeResolution(projectId, clientShareBps, resolutionNote, _msgSender(), true);
    }

    // -------- Emergency --------
    function emergencyWithdraw(uint256 projectId)
        external
        whenPaused
        nonReentrant
        validProject(projectId)
        onlyClient(projectId)
    {
        Project storage p = projects[projectId];
        if (p.status != Status.Active) revert EmergencyWithdrawNotAllowed();

        uint256 remainingInEscrow = p.depositedFunds - p.fundsReleased;
        if (remainingInEscrow == 0) revert NoRemainingFunds();
        IERC20 token = IERC20(p.token);
        if (token.balanceOf(address(this)) < totalLockedFundsByToken[p.token]) revert InsufficientBalance();

        p.status = Status.Cancelled;
        p.fundsReleased = p.depositedFunds;

        _transferTokens(token, _msgSender(), remainingInEscrow);
        totalLockedFundsByToken[p.token] -= remainingInEscrow;

        emit EmergencyWithdrawExecuted(projectId, _msgSender(), remainingInEscrow);
        emit ProjectCancelled(projectId, remainingInEscrow, _msgSender());
        emit ProjectFundsWithdrawn(projectId, remainingInEscrow);
        _clearProjectHash(projectId);
    }

    function checkAndExpireProject(uint256 projectId)
        external
        whenNotPaused
        nonReentrant
        validProject(projectId)
    {
        if (checkProjectExpiry(projectId)) {
            Project storage p = projects[projectId];
            p.status = Status.Cancelled;

            uint256 remainingInEscrow = p.depositedFunds - p.fundsReleased;
            if (remainingInEscrow > 0) {
                IERC20 token = IERC20(p.token);
                _transferTokens(token, p.client, remainingInEscrow);
                emit ProjectFundsWithdrawn(projectId, remainingInEscrow);
                totalLockedFundsByToken[p.token] -= remainingInEscrow;
            }

            p.fundsReleased = p.depositedFunds;
            emit ProjectExpired(projectId);
            emit ProjectCancelled(projectId, remainingInEscrow, address(this));
            _clearProjectHash(projectId);
        }
    }

    // -------- Internal (Milestones / Settlement) --------
    function _payMilestone(uint256 projectId, uint256 milestoneIndex) internal {
        Project storage p = projects[projectId];
        Milestone storage m = _getMilestone(projectId, milestoneIndex);

        if (m.paid) revert MilestoneAlreadyPaid();
        if (!m.clientApproved || !m.freelancerApproved) revert InvalidState();
        uint256 availableBalance = p.depositedFunds - p.fundsReleased;
        if (availableBalance < m.amount) revert InsufficientBalance();

        IERC20 token = IERC20(p.token);

        m.paid = true;
        m.paidAt = block.timestamp;
        p.fundsReleased += m.amount;

        (uint256 netAmount, uint256 feeAmount) = _calculateAmounts(m.amount, p.platformFeeBps);
        _transferTokens(token, p.freelancer, netAmount);
        _transferTokens(token, feeRecipient, feeAmount);
        totalLockedFundsByToken[p.token] -= m.amount;

        emit MilestonePaid(projectId, milestoneIndex, m.amount);
        emit ProjectFundsWithdrawn(projectId, m.amount);

        _updateProjectEarliestDeadline(projectId);
        _updateMilestoneDepositStatus(projectId);
        if (_allMilestonesPaid(projectId)) {
            _checkProjectCompletion(projectId, p);
        }
    }

    function _finalizeDisputeResolution(
        uint256 projectId,
        uint256 clientShareBps,
        string memory resolutionNote,
        address resolver,
        bool isDispute
    ) internal {
        if (clientShareBps > 10000) revert InvalidState();
        Project storage p = projects[projectId];
        Dispute storage d = disputes[projectId];

        if (p.status != Status.Disputed) revert ProjectAlreadyDisputed();
        if (d.status != DisputeStatus.Raised) revert DisputeNotActive();

        uint256 remainingInEscrow = p.depositedFunds - p.fundsReleased;
        if (remainingInEscrow == 0) revert NoRemainingFunds();
        IERC20 token = IERC20(p.token);
        if (token.balanceOf(address(this)) < remainingInEscrow) revert InsufficientBalance();

        uint256 clientAmount = (remainingInEscrow * clientShareBps) / 10000;
        uint256 freelancerAmount = remainingInEscrow - clientAmount;

        d.status = DisputeStatus.Resolved;
        d.resolvedAt = block.timestamp;
        d.resolvedBy = resolver;
        d.clientShare = clientShareBps;
        d.resolutionNote = resolutionNote;

        if (clientAmount > 0) {
            _transferTokens(token, p.client, clientAmount);
            emit ProjectFundsWithdrawn(projectId, clientAmount);
        }
        if (freelancerAmount > 0) {
            _transferTokens(token, p.freelancer, freelancerAmount);
            emit ProjectFundsWithdrawn(projectId, freelancerAmount);
        }

        p.fundsReleased = p.depositedFunds;
        totalLockedFundsByToken[p.token] -= remainingInEscrow;
        emit ProjectSettled(projectId, resolver, isDispute, clientAmount, freelancerAmount);
        emit ProjectDisputeResolved(projectId, resolver, clientShareBps, resolutionNote);

        _completeProject(projectId, p);
    }

    function _completeProject(uint256 projectId, Project storage p) internal {
        p.status = Status.Completed;
        p.completedAt = block.timestamp;
        _updateProjectEarliestDeadline(projectId);

        // If not disputed, emit settlement for reputation
        if (disputes[projectId].status != DisputeStatus.Resolved) {
            uint256 finalAmount = p.depositedFunds - p.fundsReleased;
            // expected 0
            emit ProjectSettled(projectId, p.freelancer, false, 0, finalAmount);
        }

        emit ProjectCompleted(projectId, block.timestamp);

        _issueCertificateIfNeeded(projectId, p);
        _clearProjectHash(projectId);
    }

    function _issueCertificateIfNeeded(uint256 projectId, Project storage p) internal {
        if (!p.issueCertificate || certificateContract == address(0)) return;
        try IKrylsCertificate(certificateContract).issueCertificate(
            projectId,
            p.client,
            p.freelancer,
            p.serviceCategory,
            p.roleCategory
        ) {
            emit CertificateIssued(projectId, certificateContract, p.serviceCategory, p.roleCategory);
        } catch Error(string memory reason) {
            emit CertificateIssueFailed(projectId, reason);
        } catch {
            emit CertificateIssueFailed(projectId, "Low-level error");
        }
    }

    // -------- Internal Helpers --------
    function _getMilestone(uint256 projectId, uint256 milestoneIndex) internal view returns (Milestone storage) {
        if (milestoneIndex >= projectMilestones[projectId].length) revert InvalidMilestone();
        return projectMilestones[projectId][milestoneIndex];
    }

    function _allMilestonesPaid(uint256 projectId) internal view returns (bool) {
        Milestone[] storage milestones = projectMilestones[projectId];
        for (uint256 i = 0; i < milestones.length; i++) {
            if (!milestones[i].paid) return false;
        }
        return true;
    }

    function _clearProjectHash(uint256 projectId) internal {
        bytes32 hash = projectHashes[projectId];
        if (hash != bytes32(0)) {
            if (activeProjectHashes[hash]) delete activeProjectHashes[hash];
            delete projectHashes[projectId];
        }
    }

    function _calculateAmounts(uint256 gross, uint16 feeBps) internal pure returns (uint256 netAmount, uint256 feeAmount) {
        if (feeBps == 0) return (gross, 0);
        feeAmount = (gross * feeBps) / 10000;
        netAmount = gross - feeAmount;
    }

    function _pullTokens(address token, address from, uint256 amount) internal {
        IERC20 t = IERC20(token);
        uint256 beforeBalance = t.balanceOf(address(this));
        t.safeTransferFrom(from, address(this), amount);
        uint256 afterBalance = t.balanceOf(address(this));
        if (afterBalance < beforeBalance + amount) revert InsufficientBalance();
    }

    function _transferTokens(IERC20 token, address to, uint256 amount) internal {
        if (amount > 0) token.safeTransfer(to, amount);
    }

    function _validateFlexiblePaymentType(
        PaymentType paymentType,
        uint256[] calldata amounts,
        string[] calldata descriptions,
        uint256 totalCommitment,
        bool deferDeposit
    ) internal pure returns (uint256 amountToDeposit) {
        if (deferDeposit) {
            // Panel-editing period before funds are locked.
        }

        if (paymentType == PaymentType.Milestone) {
            if (amounts.length == 0 || amounts.length > MAX_MILESTONE_COUNT) revert InvalidPaymentType();
            if (descriptions.length != amounts.length) revert InvalidPaymentType();

            uint256 calculatedTotal;
            for (uint256 i = 0; i < amounts.length; i++) {
                calculatedTotal += amounts[i];
            }
            if (calculatedTotal != totalCommitment) revert CommitmentMismatch();
            return deferDeposit ? 0 : amounts[0];

        } else { // Full
            if (amounts.length != 0 || descriptions.length != 0) revert InvalidPaymentType();
            return deferDeposit ? 0 : totalCommitment;
        }
    }

    function _updateProjectEarliestDeadline(uint256 projectId) internal {
        Project storage p = projects[projectId];
        if (p.paymentType != PaymentType.Milestone || p.status != Status.Active) {
            projectEarliestDeadline[projectId] = 0;
            return;
        }

        uint256 earliest = type(uint256).max;
        Milestone[] storage milestones = projectMilestones[projectId];
        for (uint256 i = 0; i < milestones.length; i++) {
            Milestone storage m = milestones[i];
            if (!m.paid && m.autoApproveDeadline > block.timestamp && m.autoApproveDeadline < earliest) {
                earliest = m.autoApproveDeadline;
            }
        }

        projectEarliestDeadline[projectId] = (earliest == type(uint256).max) ? 0 : earliest;
    }

    function _updateMilestoneDepositStatus(uint256 projectId) internal {
        Project storage p = projects[projectId];
        Milestone[] storage milestones = projectMilestones[projectId];

        uint256 cumulativePaidAmount = p.fundsReleased;

        for (uint256 i = 0; i < milestones.length; i++) {
            Milestone storage m = milestones[i];
            if (!m.paid) {
                cumulativePaidAmount += m.amount;
                if (cumulativePaidAmount <= p.depositedFunds && !m.isDeposited) {
                    m.isDeposited = true;
                    emit MilestoneDepositRequired(projectId, i, m.amount);
                }
            }
        }
    }

    function _initializeFlexibleMilestones(
        uint256 projectId,
        uint256[] calldata amounts,
        string[] calldata descriptions,
        uint256 initialDepositAmount
    ) internal {
        uint256 commitmentSum = 0;
        Milestone[] storage msArr = projectMilestones[projectId];

        for (uint256 i = 0; i < amounts.length; i++) {
            uint256 amount = amounts[i];
            bytes memory descBytes = bytes(descriptions[i]);
            if (descBytes.length == 0 || amount == 0) revert EmptyString();
            if (descBytes.length > MAX_STRING_LENGTH) revert StringTooLong();

            bytes32 descHash = keccak256(descBytes);
            commitmentSum += amount;

            bool isDeposited = commitmentSum <= initialDepositAmount;
            msArr.push();
            uint256 idx = msArr.length - 1;
            Milestone storage m = msArr[idx];

            m.amount = amount;
            m.paid = false;
            m.clientApproved = false;
            m.freelancerApproved = false;
            m.descriptionHash = descHash;
            m.paidAt = 0;
            m.autoApproveDeadline = 0;
            m.isDeposited = isDeposited;

            emit MilestoneAdded(projectId, idx, amount, descHash);
            if (isDeposited) emit MilestoneDepositRequired(projectId, idx, amount);
        }
    }

    function _checkProjectCompletion(uint256 projectId, Project storage p) internal {
        if (p.fundsReleased == p.totalCommitment) {
            _completeProject(projectId, p);
        }
    }

    function checkProjectExpiry(uint256 projectId) internal view returns (bool) {
        Project storage p = projects[projectId];
        return (block.timestamp > p.lastActionTime + MAX_PROJECT_DURATION);
    }

    function _validateCategories(bool isWeb3Service, uint8 serviceCategory, uint8 roleCategory) internal pure {
        if (isWeb3Service) {
            if (serviceCategory > uint8(Web3ServiceCategory.LaunchpadsIncubatorsGrants)) revert InvalidCategories();
            if (roleCategory > uint8(Web3RoleCategory.BizDevPartnership)) revert InvalidCategories();
        } else {
            if (serviceCategory > uint8(DigitalServiceCategory.SEOAndDigitalMarketing)) revert InvalidCategories();
            if (roleCategory > uint8(DigitalRoleCategory.ContentCreator)) revert InvalidCategories();
        }
    }
}