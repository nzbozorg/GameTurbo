// dashboard.js (KRYLS)
// Dashboard logic (Profile + Role switch + Post Project wizard)
// Notes (2026-02):
// - Kryls Premium UI removed
// - Web3/Blockchain toggle removed
// - Issue Certificate removed
// - Description is REQUIRED (min length enforced client + server)
// - Service Category + Role Category are REQUIRED

document.addEventListener('DOMContentLoaded', async () => {
  // ---------------- Config ----------------
  const userWallet = localStorage.getItem('userWallet');
  const API_URL = `http://${window.location.hostname}:5000`;

  // ✅ Sepolia token addresses (must match server allowlist)
  const TOKEN_ADDRESSES = {
    USDT: "0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0",
    USDC: "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238",
    DAI:  "0xFF34B3d4Aee8ddCd6F9AFFFB6Fe49bD371b8a357",
  };

  // ✅ Project description rule (client-side; server enforces too)
  const MIN_DESC_LEN = 80;

  // ---------------- DOM ----------------
  const displayName = document.getElementById('displayName');
  const displayWallet = document.getElementById('displayWallet');
  const displayBio = document.getElementById('displayBio');
  const headerAvatar = document.getElementById('headerAvatar');
  const profileAvatar = document.getElementById('profileAvatar');
  const socialContainer = document.getElementById('socialLinksContainer');

  const freelancerSec = document.getElementById('freelancerSection');
  const clientSec = document.getElementById('clientSection');
  const activeProjectsList = document.getElementById('activeProjectsList');
  const myProjectsList = document.getElementById('myProjectsList');

  const editModal = document.getElementById('editModal');
  const postJobModal = document.getElementById('postJobModal');

  // Role switch
  const roleSwitchPanel = document.getElementById('roleSwitchPanel');
  const roleSelect = document.getElementById('roleSelect');
  const applyRoleBtn = document.getElementById('applyRoleBtn');

  // Buttons
  const editBtn = document.getElementById('editProfileBtn');
  const closeEditBtn = document.getElementById('closeEditModal');
  const saveProfileBtn = document.getElementById('saveProfileBtn');

  const openPostJobBtn = document.getElementById('openPostJobModal');
  const closePostJobBtn = document.getElementById('closePostJob');
  const submitJobBtn = document.getElementById('submitJobBtn');

  const logoutBtn = document.getElementById('logoutBtn');
  const findProjectBtn = document.getElementById('findProjectBtn');

  // Inputs edit profile
  const inputUsername = document.getElementById('inputUsername');
  const inputBio = document.getElementById('inputBio');

  // Links UI
  const linkType = document.getElementById('linkType'); // old UI compatibility
  const linkUrl = document.getElementById('linkUrl');
  const addLinkBtn = document.getElementById('addLinkBtn');
  const tempLinkList = document.getElementById('tempLinkList');

  // Dashboard stats
  const dashShell = document.getElementById('dashShell');
  const dashSubtitle = document.getElementById('dashSubtitle');
  const statPosted = document.getElementById('statPosted');
  const statOpen = document.getElementById('statOpen');
  const statInProgress = document.getElementById('statInProgress');

  // Wizard step buttons
  const nextBtn = document.getElementById('nextBtn');
  const prevBtn = document.getElementById('prevBtn');

  // Wizard inputs
  const jobTitleEl = document.getElementById('jobTitle');
  const jobDescEl = document.getElementById('jobDesc');
  const paymentTypeEl = document.getElementById('cp-paymentType');
  const tokenEl = document.getElementById('cp-token');
  const budgetEl = document.getElementById('jobBudget');

  // Milestones
  const msSection = document.getElementById('milestone-section');
  const addMsBtn = document.getElementById('add-ms-btn');

  // Categories
  const web3CatsWrap = document.getElementById('web3CatsWrap'); // keep id for layout stability
  const categorySearchEl = document.getElementById('cp-categorySearch');
  const serviceCatEl = document.getElementById('cp-serviceCat');
  const roleCatEl = document.getElementById('cp-roleCat');

  // ---------------- State ----------------
  let currentData = null;
  let tempLinks = [];
  let currentStep = 0;
  let milestones = [];

  // ---------------- Guards ----------------
  if (!userWallet) {
    alert("Please connect your wallet first!");
    window.location.href = "index.html";
    return;
  }

  // Hide legacy UI parts if present
  if (linkType) linkType.style.display = 'none';

  // ---------------- Helpers ----------------
  function setSafeButtonType(el) {
    try {
      if (el && el.tagName === 'BUTTON' && !el.getAttribute('type')) el.setAttribute('type', 'button');
    } catch {}
  }

  function showToast(msg) {
    alert(msg);
  }

  function normalizeRole(role) {
    const r = (role || '').toString().trim().toLowerCase();
    if (r === 'company') return 'client'; // legacy mapping
    if (r === 'client' || r === 'freelancer') return r;
    return 'client';
  }

  function parseNumberSafe(v) {
    const n = Number((v ?? '').toString());
    return Number.isFinite(n) ? n : 0;
  }

  function safeUrl(input) {
    let s = (input || '').toString().trim();
    if (!s) return null;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try {
      const u = new URL(s);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
      return u.toString();
    } catch {
      return null;
    }
  }

  function domainOf(u) {
    try { return new URL(u).hostname.replace(/^www\./i, ''); } catch { return (u || '').toString(); }
  }

  function normalizeLinks(value) {
    const out = [];
    if (Array.isArray(value)) {
      value.forEach(v => {
        const url = safeUrl(v);
        if (url && !out.includes(url)) out.push(url);
      });
    } else if (value && typeof value === 'object') {
      Object.values(value).forEach(v => {
        const url = safeUrl(v);
        if (url && !out.includes(url)) out.push(url);
      });
    }
    return out.slice(0, 30);
  }

  function renderProfileLinks(links) {
    if (!socialContainer) return;
    socialContainer.innerHTML = '';
    const list = normalizeLinks(links);
    if (!list.length) return;

    list.forEach(u => {
      const a = document.createElement('a');
      a.href = u;
      a.target = '_blank';
      a.rel = 'noreferrer';
      a.className = 'tag';
      a.style.textDecoration = 'none';
      a.textContent = domainOf(u);
      socialContainer.appendChild(a);
    });
  }

  function renderTempLinks() {
    if (!tempLinkList) return;
    tempLinkList.innerHTML = '';

    tempLinks.forEach((u, idx) => {
      const chip = document.createElement('div');
      chip.className = 'tag';
      chip.style.display = 'inline-flex';
      chip.style.alignItems = 'center';
      chip.style.gap = '10px';
      chip.style.margin = '6px 6px 0 0';
      chip.style.cursor = 'pointer';

      const label = document.createElement('span');
      label.textContent = domainOf(u);

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'btn btn-secondary';
      del.textContent = '×';
      del.style.padding = '2px 10px';

      del.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        tempLinks.splice(idx, 1);
        renderTempLinks();
      });

      chip.addEventListener('click', (e) => {
        const t = e.target;
        if (t && t.tagName === 'BUTTON') return;
        window.open(u, '_blank', 'noreferrer');
      });

      chip.appendChild(label);
      chip.appendChild(del);
      tempLinkList.appendChild(chip);
    });
  }

  function normalizeUsername(u) {
    return (u || '').toString().trim().toLowerCase();
  }

  function isValidUsername(u) {
    return /^[a-z0-9]{4,}$/.test((u || '').toString());
  }

  function walletAvatarDataUrl(wallet) {
    try {
      const w = String(wallet || '').toLowerCase();
      const hash = ethers.utils.keccak256(ethers.utils.toUtf8Bytes(w));
      const fg = '#' + hash.slice(2, 8);
      const fg2 = '#' + hash.slice(8, 14);
      const size = 96;
      const cells = 5;
      const cell = Math.floor(size / cells);
      let bits = hash.slice(14);
      let bi = 0;
      const rects = [];

      for (let y = 0; y < cells; y++) {
        for (let x = 0; x < Math.ceil(cells / 2); x++) {
          const h = bits.slice(bi, bi + 2);
          bi += 2;
          const v = parseInt(h || '00', 16);
          const on = (v % 2) === 1;
          if (!on) continue;

          const color = (v % 4) < 2 ? fg : fg2;
          const px = x * cell;
          const py = y * cell;

          rects.push(`<rect x="${px}" y="${py}" width="${cell}" height="${cell}" fill="${color}" rx="4" />`);

          const mx = (cells - 1 - x) * cell;
          if (mx !== px) rects.push(`<rect x="${mx}" y="${py}" width="${cell}" height="${cell}" fill="${color}" rx="4" />`);
        }
      }

      const svg = `
        <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
          <rect width="100%" height="100%" fill="rgba(255,255,255,0)" />
          ${rects.join('')}
        </svg>
      `.trim();

      return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
    } catch {
      return `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(wallet || 'KRYLS')}`;
    }
  }

  function statusToClass(status) {
    const s = (status || '').toString().toLowerCase();
    if (s === 'open') return 'status-open';
    if (s === 'in progress' || s === 'inprogress') return 'status-inprogress';
    if (s === 'completed' || s === 'done') return 'status-completed';
    if (s === 'cancelled' || s === 'canceled') return 'status-canceled';
    return 'status-open';
  }

  function setStats({ posted = 0, open = 0, inProgress = 0 }) {
    if (statPosted) statPosted.textContent = String(posted);
    if (statOpen) statOpen.textContent = String(open);
    if (statInProgress) statInProgress.textContent = String(inProgress);
  }

  // ---------------- Wizard ----------------
  function validateStep(step) {
    if (step === 0) {
      const title = (jobTitleEl?.value || '').toString().trim();
      const desc = (jobDescEl?.value || '').toString().trim();

      if (!title) {
        showToast('Please enter a project title.');
        return false;
      }
      if (desc.length < MIN_DESC_LEN) {
        showToast(`Description is required (min ${MIN_DESC_LEN} characters).`);
        return false;
      }
      return true;
    }

    if (step === 1) {
      const tokenSymbol = (tokenEl?.value || '').toString().trim().toUpperCase();
      const paymentType = parseInt((paymentTypeEl?.value || '0').toString(), 10);
      const budget = parseNumberSafe(budgetEl?.value || 0);

      if (!tokenSymbol || !TOKEN_ADDRESSES[tokenSymbol]) {
        showToast('Please select a valid token.');
        return false;
      }

      if (!budget || budget <= 0) {
        showToast('Please enter a valid total budget.');
        return false;
      }

      if (paymentType === 1) {
        if (!milestones.length) {
          showToast('Please add at least one milestone.');
          return false;
        }
        const msSum = milestones.reduce((acc, m) => acc + parseNumberSafe(m.amount), 0);
        if (!msSum || msSum <= 0) {
          showToast('Milestone amounts look invalid.');
          return false;
        }
      
        // ✅ IMPORTANT: on-chain escrow requires sum(milestones) == total budget
        if (Math.abs(msSum - budget) > 1e-9) {
          showToast(`Milestone total (${msSum}) must equal total budget (${budget}).`);
          return false;
        }
}

      return true;
    }

    if (step === 2) {
      const serviceCategory = parseInt((serviceCatEl?.value || '0').toString(), 10) || 0;
      const roleCategory = parseInt((roleCatEl?.value || '0').toString(), 10) || 0;

      if (!serviceCategory) {
        showToast('Please select a Service Category.');
        return false;
      }
      if (!roleCategory) {
        showToast('Please select a Role Category.');
        return false;
      }
      return true;
    }

    return true;
  }

  function showStep(step) {
    currentStep = step;

    document.querySelectorAll('.form-step').forEach((s, i) => s.classList.toggle('active', i === step));

    const dots = document.querySelectorAll('.step-dot');
    if (dots && dots.length) dots.forEach((d, i) => d.classList.toggle('active', i === step));

    if (prevBtn) prevBtn.style.display = (step === 0) ? 'none' : 'inline-flex';
    if (nextBtn) nextBtn.style.display = (step === 2) ? 'none' : 'inline-flex';
    if (submitJobBtn) submitJobBtn.style.display = (step === 2) ? 'inline-flex' : 'none';

    if (step === 2) updateCategories();
  }

  function updatePaymentUi() {
    const pt = parseInt((paymentTypeEl?.value || '0').toString(), 10);
    if (msSection) msSection.style.display = (pt === 1) ? 'block' : 'none';
  }

  function renderMilestones() {
    const list = document.getElementById('milestone-list');
    if (!list) return;

    list.innerHTML = '';
    milestones.forEach((m, i) => {
      const li = document.createElement('li');
      li.innerHTML = `<span>${m.desc} - <b>${m.amount}</b></span> <button type="button" class="btn btn-secondary">Remove</button>`;
      li.querySelector('button')?.addEventListener('click', () => {
        milestones.splice(i, 1);
        renderMilestones();
      });
      list.appendChild(li);
    });
  }

  // ---------------- Categories (Service -> Role/Subcategory) ----------------
  const ROLE_CATEGORY_MAP = {
    1: [
      { id: 101, label: 'Web Development' },
      { id: 102, label: 'Mobile Development' },
      { id: 103, label: 'Desktop Applications' },
      { id: 104, label: 'Backend & APIs' },
      { id: 105, label: 'Frontend (UI Implementation)' },
      { id: 106, label: 'Full-stack Development' },
      { id: 107, label: 'DevOps & Cloud' },
      { id: 108, label: 'Database / Data Engineering' },
      { id: 109, label: 'QA / Testing' },
      { id: 110, label: 'Cybersecurity' },
      { id: 111, label: 'Automation / Scripting' },
      { id: 112, label: 'AI / Machine Learning' },
      { id: 113, label: 'Data Science / Analytics' },
    ],
    2: [
      { id: 201, label: 'UI/UX Design' },
      { id: 202, label: 'Graphic Design' },
      { id: 203, label: 'Branding' },
      { id: 204, label: 'Illustration' },
      { id: 205, label: '3D / Animation' },
      { id: 206, label: 'Product Design' },
      { id: 207, label: 'Presentation Design' },
    ],
    3: [
      { id: 301, label: 'Content Writing' },
      { id: 302, label: 'Copywriting' },
      { id: 303, label: 'Technical Writing' },
      { id: 304, label: 'Editing / Proofreading' },
      { id: 305, label: 'Translation' },
      { id: 306, label: 'Localization' },
    ],
    4: [
      { id: 401, label: 'Digital Marketing' },
      { id: 402, label: 'SEO' },
      { id: 403, label: 'Social Media' },
      { id: 404, label: 'Paid Ads (PPC)' },
      { id: 405, label: 'Email Marketing' },
      { id: 406, label: 'Sales / Lead Generation' },
      { id: 407, label: 'Community Management' },
    ],
    5: [
      { id: 501, label: 'Video Editing' },
      { id: 502, label: 'Motion Graphics' },
      { id: 503, label: 'Audio Editing' },
      { id: 504, label: 'Voice Over' },
      { id: 505, label: 'Music Production' },
    ],
    6: [
      { id: 601, label: 'Virtual Assistance' },
      { id: 602, label: 'Project Management' },
      { id: 603, label: 'Product Management' },
      { id: 604, label: 'Customer Support' },
      { id: 605, label: 'Data Entry' },
      { id: 606, label: 'Operations' },
    ],
    7: [
      { id: 701, label: 'Accounting / Bookkeeping' },
      { id: 702, label: 'Financial Analysis' },
      { id: 703, label: 'Tax Consulting' },
      { id: 704, label: 'Legal Consulting' },
      { id: 705, label: 'Contracts / Policies' },
    ],
    8: [
      { id: 801, label: 'Architecture' },
      { id: 802, label: 'Civil Engineering' },
      { id: 803, label: 'Mechanical Engineering' },
      { id: 804, label: 'Electrical Engineering' },
      { id: 805, label: 'CAD / Modeling' },
    ],
    9: [
      { id: 901, label: 'Smart Contracts' },
      { id: 902, label: 'dApp Frontend' },
      { id: 903, label: 'Blockchain Backend / Indexing' },
      { id: 904, label: 'Security Audit' },
      { id: 905, label: 'Tokenomics' },
      { id: 906, label: 'NFT / Marketplace' },
      { id: 907, label: 'DeFi' },
      { id: 908, label: 'DAO / Governance' },
      { id: 909, label: 'On-chain Messaging / Social' },
    ],
    10: [
      { id: 1001, label: 'Game Account Boosting' },
      { id: 1002, label: 'Game Coaching' },
      { id: 1003, label: 'Rank / MMR Boost' },
      { id: 1004, label: 'In-game Currency / Items Farming' },
      { id: 1005, label: 'Game Testing (QA)' },
      { id: 1006, label: 'Game Community / Guild Management' },
    ],
  };

  function populateRoleCategorySelect(serviceId, keepValue = true) {
    if (!roleCatEl) return;

    const prev = (roleCatEl.value || '0').toString();

    roleCatEl.innerHTML = '';
    const head = document.createElement('option');
    head.value = '0';
    head.textContent = serviceId ? 'None' : 'Select a service category first';
    roleCatEl.appendChild(head);

    const list = ROLE_CATEGORY_MAP[serviceId] || [];
    if (!serviceId || !list.length) {
      roleCatEl.disabled = true;
      return;
    }

    list.forEach((item) => {
      const opt = document.createElement('option');
      opt.value = String(item.id);
      opt.textContent = item.label;
      roleCatEl.appendChild(opt);
    });

    roleCatEl.disabled = false;

    if (keepValue && prev && Array.from(roleCatEl.options).some(o => o.value === prev)) {
      roleCatEl.value = prev;
    } else {
      roleCatEl.value = '0';
    }
  }

  function filterSelectOptions(selectEl, query) {
    if (!selectEl) return;
    const q = (query || '').toString().trim().toLowerCase();
    const opts = Array.from(selectEl.options || []);

    // Never hide the first option (None / Select...)
    opts.forEach((opt, idx) => {
      if (idx === 0) {
        opt.hidden = false;
        return;
      }
      if (!q) {
        opt.hidden = false;
        return;
      }
      const t = (opt.textContent || '').toString().toLowerCase();
      opt.hidden = !t.includes(q);
    });
  }

  function updateCategories() {
    const q = (categorySearchEl?.value || '').toString();

    // Categories are always shown (web3 toggle removed)
    if (web3CatsWrap) web3CatsWrap.style.display = 'block';

    const serviceId = parseInt((serviceCatEl?.value || '0').toString(), 10) || 0;

    // Populate roles based on selected main service category
    populateRoleCategorySelect(serviceId, true);

    // Apply search filter to both selects
    filterSelectOptions(serviceCatEl, q);
    filterSelectOptions(roleCatEl, q);
  }

  // ---------------- API ----------------
  async function saveProjectToDB(projectMeta) {
    const res = await fetch(`${API_URL}/api/post-project`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(projectMeta)
    });

    return await res.json().catch(() => null);
  }

  // ---------------- Projects ----------------
  async function loadMyPostedProjects() {
    if (!myProjectsList) return;
    try {
      const res = await fetch(`${API_URL}/api/client-projects/${userWallet}`);
      const data = await res.json().catch(() => null);
      const arr = Array.isArray(data?.projects) ? data.projects : [];

      myProjectsList.innerHTML = '';

      const posted = arr.length;
      const open = arr.filter(x => (x.status || '') === 'Open').length;
      const inProgress = arr.filter(x => (x.status || '') === 'In Progress').length;
      setStats({ posted, open, inProgress });

      if (!arr.length) {
        myProjectsList.innerHTML = '<p style="color:#666">No projects yet.</p>';
        return;
      }

      arr.forEach(p => myProjectsList.appendChild(createProjectCard(p, { showCancel: true })));
    } catch (err) {
      console.error(err);
    }
  }

  async function loadActiveProjects() {
    if (!activeProjectsList) return;
    try {
      const res = await fetch(`${API_URL}/api/freelancer-active/${userWallet}`);
      const data = await res.json().catch(() => null);
      const arr = Array.isArray(data?.projects) ? data.projects : [];

      activeProjectsList.innerHTML = '';
      setStats({ posted: 0, open: 0, inProgress: arr.length });

      if (!arr.length) {
        activeProjectsList.innerHTML = '<p style="color:#666">No active projects.</p>';
        return;
      }

      arr.forEach(p => activeProjectsList.appendChild(createProjectCard(p)));
    } catch (err) {
      console.error(err);
    }
  }

  function createProjectCard(p, opts = {}) {
    const div = document.createElement('div');
    div.className = 'project-card';

    const tokenSym = (p?.tokenSymbol || p?.token_symbol || p?.currency || 'USDT').toString();
    const statusText = (p?.status || 'Open').toString();
    const statusClass = statusToClass(statusText);

    div.innerHTML = `
      <div class="project-header">
        <span class="project-title">${(p?.title || 'Untitled').toString()}</span>
        <span class="project-budget">${(p?.budget || '0').toString()} ${tokenSym}</span>
      </div>
      <span class="status-badge ${statusClass}">${statusText}</span>
    `;

    if (opts?.showCancel) {
      const actions = document.createElement('div');
      actions.className = 'project-actions-row';

      const cancelBtn = document.createElement('button');
      cancelBtn.className = 'btn btn-danger';
      cancelBtn.textContent = 'Cancel Project';
      setSafeButtonType(cancelBtn);

      cancelBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        if ((p?.status || '').toString() !== 'Open') return alert('Only Open projects can be cancelled.');
        const ok = confirm('Are you sure you want to cancel this project?');
        if (!ok) return;

        try {
          cancelBtn.disabled = true;
          cancelBtn.textContent = 'Cancelling...';

          const resp = await fetch(`${API_URL}/api/cancel-project`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ wallet: userWallet, projectId: p?.id })
          });

          const out = await resp.json().catch(() => null);
          if (!out?.success) throw new Error(out?.message || 'Cancel failed');

          alert('Project cancelled');
          await loadMyPostedProjects();
        } catch (err) {
          console.error(err);
          alert(err?.message || 'Cancel failed');
        } finally {
          cancelBtn.disabled = false;
          cancelBtn.textContent = 'Cancel Project';
        }
      });

      actions.appendChild(cancelBtn);
      div.appendChild(actions);
    }

    return div;
  }

  // ---------------- Profile ----------------
  async function fetchProfile() {
    try {
      const res = await fetch(`${API_URL}/api/profile/${userWallet}`);
      const data = await res.json().catch(() => null);
      if (!data?.success) return;

      currentData = data.user || null;
      if (!currentData) return;

      if (dashShell) dashShell.style.display = 'block';

      const role = normalizeRole(currentData.role);

      // Header + profile info
      if (displayName) displayName.textContent = currentData.username || 'User';
      if (displayWallet) displayWallet.innerText = userWallet.slice(0, 6) + '...' + userWallet.slice(-4);

      if (headerAvatar) headerAvatar.src = walletAvatarDataUrl(userWallet);
      if (profileAvatar) profileAvatar.src = headerAvatar ? headerAvatar.src : walletAvatarDataUrl(userWallet);

      // Bio (pill)
      if (displayBio) {
        const b = (currentData.bio || '').toString().trim();
        displayBio.textContent = b;
      }

      if (dashSubtitle) {
        dashSubtitle.textContent = `Role: ${role} • Wallet: ${displayWallet ? displayWallet.innerText : ''}`;
      }

      renderProfileLinks(currentData.socials);

      // Role switch
      if (roleSelect) roleSelect.value = role;
      if (roleSwitchPanel) roleSwitchPanel.style.display = 'block';

      // Sections
      if (role === 'freelancer') {
        if (freelancerSec) freelancerSec.style.display = 'block';
        if (clientSec) clientSec.style.display = 'none';
        await loadActiveProjects();
      } else {
        if (clientSec) clientSec.style.display = 'block';
        if (freelancerSec) freelancerSec.style.display = 'none';
        await loadMyPostedProjects();
      }

      // Safety: allow posting for client role
      if (openPostJobBtn) {
        openPostJobBtn.disabled = false;
        openPostJobBtn.style.opacity = '';
        openPostJobBtn.style.cursor = '';
        openPostJobBtn.innerText = 'Post a Job';
      }
    } catch (err) {
      console.error(err);
    }
  }

  async function handleRoleSwitch() {
    try {
      const newRole = normalizeRole(roleSelect?.value);
      if (!newRole) return;

      if (applyRoleBtn) {
        applyRoleBtn.disabled = true;
        applyRoleBtn.innerText = 'Applying...';
      }

      try {
        await fetch(`${API_URL}/api/set-role`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ wallet: userWallet, role: newRole })
        });
      } catch {
        console.log('Role saved locally only (Server offline)');
      }

      await fetchProfile();
      alert(`✅ Role changed to ${newRole.toUpperCase()}`);
    } catch (err) {
      console.error(err);
      alert(err?.message || 'Failed to change role');
    } finally {
      if (applyRoleBtn) {
        applyRoleBtn.disabled = false;
        applyRoleBtn.innerText = 'Apply Role';
      }
    }
  }

  // ---------------- Post job ----------------
  async function handleSubmitJob() {
    // Re-validate all steps (prevents bypass + keeps UX consistent)
    if (!validateStep(0)) { showStep(0); return; }
    if (!validateStep(1)) { showStep(1); return; }
    if (!validateStep(2)) { showStep(2); return; }

    try {
      const paymentType = parseInt((paymentTypeEl?.value || '0').toString(), 10);
      const tokenSymbol = (tokenEl?.value || '').toString().trim().toUpperCase();
      const tokenAddr = TOKEN_ADDRESSES[tokenSymbol];
      if (!tokenAddr) return alert('Invalid token');

      const budget = (budgetEl?.value || '0').toString();

      const serviceCategory = parseInt((serviceCatEl?.value || '0').toString(), 10);
      const roleCategory = parseInt((roleCatEl?.value || '0').toString(), 10);

      let milestoneDescriptions = [];
      let milestoneAmountsHuman = [];
      if (paymentType === 1) {
        milestoneDescriptions = milestones.map(x => x.desc);
        milestoneAmountsHuman = milestones.map(x => String(x.amount));
      }

      if (submitJobBtn) {
        submitJobBtn.disabled = true;
        submitJobBtn.innerText = 'Processing...';
      }

      const meta = {
        owner: userWallet,
        title: (jobTitleEl?.value || '').toString(),
        desc: (jobDescEl?.value || '').toString(),
        budget,
        tags: [],
        status: 'Open',
        token: tokenAddr,
        tokenSymbol,
        totalCommitment: budget,
        paymentType,
        milestoneDescriptions,
        milestoneAmounts: milestoneAmountsHuman,

        // removed UI toggles -> always false
        isWeb3Service: false,

        // required
        serviceCategory: serviceCategory,
        roleCategory: roleCategory,

        // removed feature -> always false (prevents ReferenceError)
        issueCertificate: false,
      };

      const out = await saveProjectToDB(meta);
      if (!out?.success) throw new Error(out?.message || 'Create project failed');

      alert('✅ Project created successfully!');
      if (postJobModal) postJobModal.classList.remove('active');

      // Reset wizard state
      milestones = [];
      renderMilestones();
      showStep(0);

      // Reload list
      await loadMyPostedProjects();
    } catch (err) {
      console.error(err);
      alert(err?.reason || err?.message || 'Create project failed');
    } finally {
      if (submitJobBtn) {
        submitJobBtn.disabled = false;
        submitJobBtn.innerText = 'Submit Job';
      }
    }
  }

  // ---------------- Edit profile ----------------
  function openEditModal() {
    if (!editModal) return;
    if (inputUsername) inputUsername.value = currentData?.username || '';
    if (inputBio) inputBio.value = currentData?.bio || '';
    tempLinks = normalizeLinks(currentData?.socials);
    renderTempLinks();
    editModal.classList.add('active');
  }

  function closeEditModalFn() {
    if (!editModal) return;
    editModal.classList.remove('active');
  }

  async function saveProfile() {
    const username = normalizeUsername(inputUsername?.value);
    if (username && !isValidUsername(username)) return alert('Username invalid (a-z0-9, min 4).');
    const bio = (inputBio?.value || '').toString();

    if (saveProfileBtn) {
      saveProfileBtn.disabled = true;
      saveProfileBtn.innerText = 'Saving...';
    }

    try {
      const res = await fetch(`${API_URL}/api/update-profile`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet: userWallet,
          username: username || (currentData?.username || ''),
          bio,
          socials: tempLinks.slice(),
        })
      });

      const data = await res.json().catch(() => null);
      if (!data?.success) throw new Error(data?.message || 'Save failed');

      await fetchProfile();
      closeEditModalFn();
      alert('✅ Profile updated');
    } catch (err) {
      console.error(err);
      alert(err?.message || 'Save failed');
    } finally {
      if (saveProfileBtn) {
        saveProfileBtn.disabled = false;
        saveProfileBtn.innerText = 'Save';
      }
    }
  }

  // ---------------- Events wiring ----------------
  // Navigate
  if (findProjectBtn) {
    setSafeButtonType(findProjectBtn);
    findProjectBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'market.html';
    });
  }

  // Open post modal
  if (openPostJobBtn) {
    setSafeButtonType(openPostJobBtn);
    openPostJobBtn.addEventListener('click', (e) => {
      e.preventDefault();
      showStep(0);
      updateCategories();
      updatePaymentUi();
      if (postJobModal) postJobModal.classList.add('active');
    });
  }

  if (closePostJobBtn) {
    setSafeButtonType(closePostJobBtn);
    closePostJobBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (postJobModal) postJobModal.classList.remove('active');
    });
  }

  // Wizard navigation
  if (nextBtn) {
    setSafeButtonType(nextBtn);
    nextBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (!validateStep(currentStep)) return;
      showStep(Math.min(currentStep + 1, 2));
    });
  }

  if (prevBtn) {
    setSafeButtonType(prevBtn);
    prevBtn.addEventListener('click', (e) => {
      e.preventDefault();
      showStep(Math.max(currentStep - 1, 0));
    });
  }

  // Milestones
  if (addMsBtn) {
    setSafeButtonType(addMsBtn);
    addMsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const d = (document.getElementById('ms-desc')?.value || '').trim();
      const a = (document.getElementById('ms-amount')?.value || '').trim();
      if (!d) return alert('Milestone desc required');
      if (!a || isNaN(parseFloat(a)) || parseFloat(a) <= 0) return alert('Milestone amount invalid');
      milestones.push({ desc: d, amount: a });
      if (document.getElementById('ms-desc')) document.getElementById('ms-desc').value = '';
      if (document.getElementById('ms-amount')) document.getElementById('ms-amount').value = '';
      renderMilestones();
    });
  }

  if (paymentTypeEl) paymentTypeEl.addEventListener('change', updatePaymentUi);

  // Categories wiring
  if (serviceCatEl) serviceCatEl.addEventListener('change', updateCategories);
  if (categorySearchEl) categorySearchEl.addEventListener('input', updateCategories);

  // Submit
  if (submitJobBtn) {
    setSafeButtonType(submitJobBtn);
    submitJobBtn.addEventListener('click', handleSubmitJob);
  }

  // Edit profile
  if (editBtn) {
    setSafeButtonType(editBtn);
    editBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openEditModal();
    });
  }

  if (closeEditBtn) {
    setSafeButtonType(closeEditBtn);
    closeEditBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeEditModalFn();
    });
  }

  if (addLinkBtn) {
    addLinkBtn.type = 'button';
    addLinkBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const url = safeUrl(linkUrl?.value);
      if (!url) return alert('Enter a valid URL (https://example.com)');
      if (!tempLinks.includes(url)) tempLinks.push(url);
      if (linkUrl) linkUrl.value = '';
      renderTempLinks();
    });
  }

  if (saveProfileBtn) {
    saveProfileBtn.type = 'button';
    saveProfileBtn.addEventListener('click', (e) => {
      e.preventDefault();
      saveProfile();
    });
  }

  // Role switch
  if (applyRoleBtn) {
    setSafeButtonType(applyRoleBtn);
    applyRoleBtn.addEventListener('click', handleRoleSwitch);
  }

  // Logout
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem('userWallet');
      window.location.href = 'index.html';
    });
  }

  // Background glow parallax
  document.addEventListener('mousemove', (e) => {
    const glow = document.querySelector('.bg-glow');
    if (glow) glow.style.transform = `translate(-${e.clientX / 50}px, -${e.clientY / 50}px)`;
  });

  // Init
  showStep(0);
  updateCategories();
  updatePaymentUi();
  fetchProfile();
});
