document.addEventListener("DOMContentLoaded", async () => {
  const API_URL = `http://${window.location.hostname}:5000`;
  const marketGrid = document.getElementById("marketGrid");
  const searchInput = document.getElementById("searchInput");
  const resultCount = document.getElementById("resultCount");
  const sortSelect = document.getElementById("sortSelect");
  const tagButtons = document.querySelectorAll(".tag-filter");

  const userWallet = localStorage.getItem("userWallet");
  const connectBtn = document.getElementById("connectWalletBtn");
  const profileIcon = document.getElementById("userProfileIcon");

  let allProjects = [];

  let timersInterval = null;

function formatRemaining(ms) {
    if (!Number.isFinite(ms) || ms <= 0) return "0h 0m";
    const totalMin = Math.floor(ms / 60000);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return `${h}h ${m}m`;
  }

  function sortPinnedFirst(list) {

  const arr = Array.isArray(list) ? list.slice() : [];

  arr.sort((a, b) => {

    const ap = a && a.pinned ? 1 : 0;

    const bp = b && b.pinned ? 1 : 0;

    if (bp !== ap) return bp - ap;

    return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);

  });

  return arr;

}

  let myProfile = null;
  let currentApplyProjectId = null;

  function short(a) {
    return a ? a.slice(0, 6) + "..." + a.slice(-4) : "";
  }

  async function apiGet(url) {
    const res = await fetch(url, { cache: "no-store" });
    const data = await res.json().catch(() => ({}));
    return data;
  }

  async function apiPost(url, body) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    const data = await res.json().catch(() => ({}));
    return data;
  }

  // Header UI
  if (userWallet) {
    connectBtn.innerText = short(userWallet);
    connectBtn.style.border = "1px solid #00f0ff";
    connectBtn.style.color = "#00f0ff";
    connectBtn.style.background = "rgba(0,240,255,0.1)";

    if (profileIcon) {
      profileIcon.style.display = "block";
      const img = profileIcon.querySelector("img");
      if (img) img.src = `https://api.dicebear.com/9.x/identicon/svg?seed=${encodeURIComponent(userWallet)}`;
      profileIcon.onclick = () => (window.location.href = "dashboard.html");
    }
  } else {
    connectBtn.onclick = () => (window.location.href = "index.html");
  }

  async function loadMyProfile() {
    if (!userWallet) return null;
    const data = await apiGet(`${API_URL}/api/profile/${userWallet}`);
    myProfile = data?.user || null;
    return myProfile;
  }

  // Fetch projects
  async function fetchProjects() {
    try {
      const res = await fetch(`${API_URL}/api/all-open-projects`, { cache: "no-store" });
      const data = await res.json().catch(() => ({}));
      if (data.success) {
        allProjects = Array.isArray(data.projects) ? data.projects : [];
        renderProjects(allProjects);
      }
    } catch (err) {
      console.error(err);
      if (resultCount) resultCount.innerText = "Error loading projects.";
    }
  }

  function updateTimersForMarket() {
    try {
      const now = Date.now();

      document.querySelectorAll(".expiry-timer").forEach((el) => {
        const exp = (el.getAttribute("data-exp") || "").toString();
        const t = Date.parse(exp);
        if (!t) { el.textContent = "—"; return; }
        const left = t - now;
      el.textContent = left <= 0 ? 'Expired' : formatRemaining(left);
      });

      document.querySelectorAll(".pinned-timer").forEach((el) => {
        const pu = (el.getAttribute("data-pin-until") || "").toString();
        const t = Date.parse(pu);
        if (!t) { el.textContent = ""; return; }
        const left = t - now;
        el.textContent = left > 0 ? `(${formatRemaining(left)})` : "";
      });
    } catch {}
  }

  function renderProjects(projects) {
    if (!marketGrid) return;
    marketGrid.innerHTML = "";
    if (resultCount) resultCount.innerText = `Showing ${projects.length} Active Jobs`;

    if (projects.length === 0) {
      marketGrid.innerHTML =
        '<p style="color:#666; grid-column: 1/-1; text-align:center;">No projects found matching your search.</p>';
      return;
    }

    projects.forEach((p) => {
      const card = document.createElement("div");
      card.className = "project-card";

      if (p && p.pinned) card.classList.add('pinned');
      if (p && p.premiumOwner) card.classList.add('premium-owner');
      const tags = Array.isArray(p.tags) ? p.tags : [];
      const tagsHtml = tags.map((t) => `<span class="tag">${t}</span>`).join("");

      const isOwner = userWallet && p.owner && p.owner.toLowerCase() === userWallet.toLowerCase();
      const canApply = !!userWallet && !isOwner && myProfile && myProfile.role === "freelancer";

      card.innerHTML = `
        ${p && p.pinned ? `<div class="pinned-badge">Pinned <span class="pinned-timer" data-pin-until="${p.pinnedUntil || ""}"></span></div>` : ``}


      ${p && p.pinned ? '<div class=\"premium-corner\">PREMIUM</div>' : ''}
        <div class="project-header">
          <span class="project-title">${(p.title || "").toString()}</span>
          <span class="project-budget">${(p.budget || "0").toString()} ${(p.tokenSymbol || "USDT").toString()}</span>
        </div>
        <div class="project-tags">${tagsHtml}</div>
        <p class="project-desc">${(p.desc || "").toString()}</p>
          <div class="project-timer">Remaining: <span class="expiry-timer" data-exp="${p.expiresAt || ''}"></span></div>
        <div class="project-footer">
          <div class="client-info">
            <span>👤 ${short(p.owner)}</span>
            <span>📅 ${p.createdAt ? new Date(p.createdAt).toLocaleDateString() : ""}</span>
          </div>
          <button class="apply-btn" ${canApply ? "" : "disabled"} data-proj="${p.id}">
            ${!userWallet ? "Login first" : isOwner ? "Your project" : (myProfile && myProfile.role !== "freelancer") ? "Only freelancer" : "Apply Now"}
          </button>
        </div>
      `;

      const btn = card.querySelector(".apply-btn");
      if (btn && canApply) {
        btn.addEventListener("click", () => openApplyModal(p.id, p.title));
      }

      marketGrid.appendChild(card);
    });

    updateTimersForMarket();
    if (timersInterval) clearInterval(timersInterval);
    timersInterval = setInterval(updateTimersForMarket, 60000);
  }

  function filterProjects(keyword, tag = "all") {
    let filtered = allProjects;

    if (keyword) {
      const lowerK = keyword.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          (p.title || "").toLowerCase().includes(lowerK) ||
          (p.desc || "").toLowerCase().includes(lowerK) ||
          (Array.isArray(p.tags) ? p.tags : []).some((t) => (t || "").toLowerCase().includes(lowerK))
      );
    }

    if (tag !== "all") {
      filtered = filtered.filter((p) => (Array.isArray(p.tags) ? p.tags : []).some((t) => (t || "").toLowerCase() === tag));
    }

    const sortType = sortSelect ? sortSelect.value : "latest";

    // Kryls Premium (Added): pinned projects always stay on top

    filtered = sortPinnedFirst(filtered);
    if (sortType === "price-high") {
      filtered.sort((a, b) => parseFloat(b.budget || "0") - parseFloat(a.budget || "0"));
    } else {
      filtered.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    }

    renderProjects(filtered);
  }

  // Apply Modal (uses existing modal in market.html)
  const applyModal = document.getElementById("applyModal");
  const closeApply = document.getElementById("closeApply");
  const sendProposalBtn = document.getElementById("sendProposalBtn");
  const proposalPrice = document.getElementById("proposalPrice");
  const proposalDuration = document.getElementById("proposalDuration");
  const coverLetter = document.getElementById("coverLetter");

  function openApplyModal(projectId, title) {
    if (!userWallet) return alert("Please login first!");
    if (!myProfile) return alert("Please select role first (Dashboard).");
    if (myProfile.role !== "freelancer") return alert("Only freelancers can request projects.");

    currentApplyProjectId = projectId;

    if (applyModal) {
      const h = applyModal.querySelector("h3");
      if (h) h.innerText = `Apply: ${title}`;
      applyModal.classList.add("active");
    }
  }

  if (closeApply) {
    closeApply.addEventListener("click", () => {
      if (applyModal) applyModal.classList.remove("active");
    });
  }

  if (sendProposalBtn) {
    sendProposalBtn.addEventListener("click", async () => {
      try {
        if (!currentApplyProjectId) return alert("No project selected.");
        if (!userWallet) return alert("Please login first!");
        if (!myProfile || myProfile.role !== "freelancer") return alert("Only freelancers can request projects.");

        const body = {
          projectId: currentApplyProjectId,
          freelancer: userWallet,
          price: (proposalPrice?.value || "").toString(),
          duration: (proposalDuration?.value || "").toString(),
          coverLetter: (coverLetter?.value || "").toString(),
        };

        const data = await apiPost(`${API_URL}/api/request-project`, body);
        if (!data?.success) throw new Error(data?.message || "Request failed");

        alert("✅ Request sent! Now you can chat with the project owner.");
        if (applyModal) applyModal.classList.remove("active");

        window.location.href = `chat.html?projectId=${encodeURIComponent(currentApplyProjectId)}`;
      } catch (e) {
        console.error(e);
        alert(e?.message || "Failed to send request");
      }
    });
  }

  // Search / filter events
  if (searchInput) searchInput.addEventListener("input", (e) => filterProjects(e.target.value));
  if (tagButtons) {
    tagButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        tagButtons.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        const tag = btn.getAttribute("data-tag");
        filterProjects(searchInput ? searchInput.value : "", tag || "all");
      });
    });
  }
  if (sortSelect) sortSelect.addEventListener("change", () => filterProjects(searchInput ? searchInput.value : ""));

  // Boot
  await loadMyProfile();
  await fetchProjects();
});